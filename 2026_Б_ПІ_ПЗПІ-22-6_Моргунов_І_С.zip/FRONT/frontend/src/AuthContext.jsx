import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";
import client from "./api";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const saveTokens = (data) => {
  const accessToken =
    data?.accessToken ||
    data?.access_token ||
    data?.token ||
    data?.jwt;

  const refreshToken =
    data?.refreshToken ||
    data?.refresh_token;

  if (accessToken) {
    localStorage.setItem("wt_access_token", accessToken);
  }

  if (refreshToken) {
    localStorage.setItem("wt_refresh_token", refreshToken);
  }
};

  const clearTokens = () => {
    localStorage.removeItem("wt_access_token");
    localStorage.removeItem("wt_refresh_token");
  };

  const fetchMe = useCallback(async () => {
    const token = localStorage.getItem("wt_access_token");

    if (!token) {
      setUser(false);
      setLoading(false);
      return null;
    }

    try {
      const { data } = await client.get("/auth/me");
      setUser(data);
      return data;
    } catch (error) {
      setUser(false);
      clearTokens();
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchMe();
  }, [fetchMe]);

  const login = async (loginValue, password) => {
  const { data } = await client.post("/auth/login", {
    login: loginValue,
    password,
  });

  if (data?.requiresTwoFactor) {
    return data;
  }

  saveTokens(data);

  try {
    const me = await client.get("/auth/me");
    setUser(me.data);
  } catch (error) {
    const isEmail = loginValue.includes("@");

    setUser({
      authenticated: true,
      username: isEmail ? loginValue.split("@")[0] : loginValue,
      email: isEmail ? loginValue : "",
      displayName: isEmail ? loginValue.split("@")[0] : loginValue,
    });
  }

  return data;
};

  const verifyTwoFactor = async (tempToken, code, loginValue = "") => {
  const { data } = await client.post("/auth/login/2fa", {
    tempToken,
    code,
  });

  saveTokens(data);

  try {
    const me = await client.get("/auth/me");
    setUser(me.data);
  } catch (error) {
    const isEmail = loginValue.includes("@");

    setUser({
      authenticated: true,
      username: isEmail ? loginValue.split("@")[0] : loginValue,
      email: isEmail ? loginValue : "",
      displayName: isEmail ? loginValue.split("@")[0] : loginValue,
    });
  }

  return data;
};

  const register = async (payload) => {
    const { data } = await client.post("/auth/register", payload);

    saveTokens(data);

    try {
      const me = await client.get("/auth/me");
      setUser(me.data);
    } catch (error) {
      setUser({
        authenticated: true,
        username: payload.username,
        email: payload.email,
        displayName: payload.displayName || payload.username,
      });
    }

    return data;
  };

  const updateUser = (patch) => {
    setUser((currentUser) => {
      if (!currentUser) return currentUser;
      return {
        ...currentUser,
        ...patch,
      };
    });
  };

  const logout = async () => {
    const refresh = localStorage.getItem("wt_refresh_token");

    try {
      if (refresh) {
        await client.post("/auth/logout", {
          refreshToken: refresh,
        });
      }
    } catch (error) {
      // ignore logout errors
    }

    clearTokens();
    setUser(false);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        login,
        verifyTwoFactor,
        register,
        logout,
        refresh: fetchMe,
        updateUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}