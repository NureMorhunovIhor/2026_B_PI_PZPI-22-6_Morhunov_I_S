import React from "react";
import { Tv } from "lucide-react";

export default function Logo({ size = 40, withText = false, textSize = "text-xl" }) {
  return (
    <div className="flex items-center gap-3" data-testid="brand-logo">
      <div
        className="brand-logo"
        style={{ width: size, height: size }}
      >
        <Tv size={Math.round(size * 0.55)} color="#fff" strokeWidth={2.2} />
      </div>
      {withText && (
        <span className={`font-serif font-bold ${textSize} tracking-wider text-white`}>
          WatchTogether
        </span>
      )}
    </div>
  );
}
