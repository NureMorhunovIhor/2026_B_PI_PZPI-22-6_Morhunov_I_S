import React, { useEffect, useMemo, useState } from "react";
import { Check, Copy, Search, Send, UserPlus, X } from "lucide-react";
import client, { formatApiError } from "../api";

export default function InviteFriendsDialog({ roomCode, roomName, onClose }) {
  const [friends, setFriends] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState(new Set());
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [copied, setCopied] = useState(false);

  const getFriendId = (f) =>
  f.userId ??
  f.friendId ??
  f.friendUserId ??
  f.id ??
  f.user?.id ??
  f.friend?.id;

  useEffect(() => {
    (async () => {
      try {
        const { data } = await client.get("/friends");
        setFriends(data);
      } catch (err) {
        setError(formatApiError(err));
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return friends;
    return friends.filter(
      (f) =>
        f.username?.toLowerCase().includes(q) ||
        f.displayName?.toLowerCase().includes(q),
    );
  }, [friends, query]);

  const toggle = (friend) => {
  const id = getFriendId(friend);

  if (!id) {
    console.warn("Friend has no id:", friend);
    return;
  }

  setSelected((cur) => {
    const next = new Set(cur);

    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }

    return next;
  });
};

  const send = async () => {
  if (selected.size === 0) return;

  setSending(true);
  setError("");
  setSuccess("");

  try {
    const ids = Array.from(selected)
      .map((id) => Number(id))
      .filter((id) => Number.isFinite(id));

    console.log("INVITE IDS:", ids);

    await Promise.all(
      ids.map((id) =>
        client.post(`/rooms/${roomCode}/invite`, {
          userId: id,
        }),
      ),
    );

    setSuccess(`Sent ${ids.length} invite${ids.length > 1 ? "s" : ""}!`);
    setSelected(new Set());

    setTimeout(onClose, 1200);
  } catch (err) {
    console.error("INVITE ERROR:", err?.response?.data || err);
    setError(formatApiError(err));
  } finally {
    setSending(false);
  }
};

  const copyLink = () => {
    const link = `${window.location.origin}/rooms/${roomCode}`;
    navigator.clipboard.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="glass-card w-full max-w-xl max-h-[80vh] overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
        data-testid="invite-dialog"
      >
        <div className="flex items-center justify-between p-5 border-b border-violet-500/15">
          <div>
            <h2 className="font-serif text-xl tracking-wide">INVITE FRIENDS</h2>
            <p className="text-xs text-[var(--text-muted)] mt-0.5">to {roomName}</p>
          </div>
          <button
            onClick={onClose}
            className="text-[var(--text-secondary)] hover:text-white"
            data-testid="invite-close"
          >
            <X size={20} />
          </button>
        </div>

        <div className="px-5 pt-4">
          <button
            onClick={copyLink}
            className="w-full glass-card glass-card-hover p-3 flex items-center gap-3 text-left mb-4"
            data-testid="invite-copy-link"
          >
            <div className="w-10 h-10 rounded-xl bg-violet-500/15 border border-violet-500/30 flex items-center justify-center">
              <Copy size={16} className="text-[var(--violet-soft)]" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold">
                {copied ? "Link copied!" : "Copy invite link"}
              </div>
              <div className="text-xs text-[var(--text-muted)] truncate">
                {window.location.origin}/rooms/{roomCode}
              </div>
            </div>
          </button>

          <div className="relative">
            <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
            <input
              className="input-field-dark pl-10 !py-2.5"
              placeholder="Search friends..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              data-testid="invite-search"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-3">
          {loading ? (
            <div className="text-center text-sm text-[var(--text-secondary)] py-10">
              Loading friends...
            </div>
          ) : friends.length === 0 ? (
            <div className="text-center text-sm text-[var(--text-secondary)] py-10">
              <UserPlus size={28} className="mx-auto mb-3 opacity-50" />
              You haven't added any friends yet. Use the link above to share the room.
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center text-sm text-[var(--text-secondary)] py-10">
              No matching friends.
            </div>
          ) : (
            <div className="space-y-1.5">
              {filtered.map((f) => {
  const friendId = getFriendId(f);
  const sel = selected.has(friendId);

  return (
    <button
      key={friendId}
      onClick={() => toggle(f)}
      className={`w-full flex items-center gap-3 p-2.5 rounded-xl border transition text-left ${
        sel
          ? "border-violet-500 bg-violet-500/20"
          : "border-violet-500/10 bg-violet-500/5 hover:border-violet-500/30"
      }`}
      data-testid={`invite-friend-${friendId}`}
    >
      {f.avatarUrl ? (
        <img src={f.avatarUrl} alt="" className="avatar object-cover" />
      ) : (
        <span className="avatar">
          {(f.displayName || f.username || "?")[0]?.toUpperCase()}
        </span>
      )}

      <div className="flex-1 min-w-0">
        <div className="text-sm font-semibold truncate">
          {f.displayName || f.username}
        </div>
        <div className="text-xs text-[var(--text-muted)] truncate">
          @{f.username}
        </div>
      </div>

      <div
        className={`w-5 h-5 rounded-md flex items-center justify-center border-2 transition ${
          sel ? "bg-violet-500 border-violet-500" : "border-violet-500/40"
        }`}
      >
        {sel && <Check size={12} strokeWidth={3} className="text-white" />}
      </div>
    </button>
  );
})}
            </div>
          )}
        </div>

        <div className="p-5 border-t border-violet-500/15 space-y-3">
          {error && (
            <div className="text-sm text-pink-300 bg-pink-500/10 border border-pink-500/30 rounded-xl px-4 py-2" data-testid="invite-error">
              {error}
            </div>
          )}
          {success && (
            <div className="text-sm text-emerald-300 bg-emerald-500/10 border border-emerald-500/30 rounded-xl px-4 py-2" data-testid="invite-success">
              {success}
            </div>
          )}
          <button
            onClick={send}
            disabled={sending || selected.size === 0}
            className="btn-primary w-full inline-flex items-center justify-center gap-2"
            data-testid="invite-send-btn"
          >
            <Send size={15} />
            {sending
              ? "Sending..."
              : selected.size === 0
              ? "Select friends to invite"
              : `Send ${selected.size} invite${selected.size > 1 ? "s" : ""}`}
          </button>
        </div>
      </div>
    </div>
  );
}
