import React, { useCallback, useEffect, useRef, useState } from "react";
import { getYouTubeId, isDirectVideo } from "../utils/media";

let ytApiPromise = null;

function loadYouTubeAPI() {
  if (ytApiPromise) return ytApiPromise;

  ytApiPromise = new Promise((resolve) => {
    if (window.YT && window.YT.Player) {
      resolve(window.YT);
      return;
    }

    const tag = document.createElement("script");
    tag.src = "https://www.youtube.com/iframe_api";

    window.onYouTubeIframeAPIReady = () => {
      resolve(window.YT);
    };

    document.head.appendChild(tag);
  });

  return ytApiPromise;
}

function normalizeStatus(status) {
  const value = String(status || "").toUpperCase();

  if (value === "PLAY" || value === "PLAYING") return "PLAYING";
  if (value === "PAUSE" || value === "PAUSED") return "PAUSED";
  if (value === "STOP" || value === "STOPPED") return "STOPPED";
  if (value === "END" || value === "ENDED") return "ENDED";
  if (value === "SEEK" || value === "SYNC") return "SYNC";

  return "PAUSED";
}

function getSafeNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

export default function SyncedPlayer({ playbackState, onLocalCommand, canControl }) {
  const containerRef = useRef(null);
  const playerRef = useRef(null);
  const videoRef = useRef(null);

  const suppressEventRef = useRef(false);
  const lastMediaKeyRef = useRef(null);
  const lastSyncKeyRef = useRef(null);
  const pendingPlaybackRef = useRef(null);
  const lastAppliedYoutubeStateRef = useRef({
  mediaKey: null,
  status: null,
  position: null,
});

  const lastYoutubeTimeRef = useRef(0);
  const lastSentYoutubeSeekRef = useRef(0);
  const lastSentDirectSeekRef = useRef(0);

  const [youtubeReady, setYoutubeReady] = useState(false);

  const url = playbackState?.sourceUrl;
  const ytId = getYouTubeId(url);

  const mediaKey = playbackState?.mediaId || url || null;
  const status = normalizeStatus(playbackState?.playbackStatus);

  const positionSeconds = getSafeNumber(playbackState?.currentPositionSeconds, 0);
  const playbackSpeed = getSafeNumber(playbackState?.playbackSpeed, 1);

  const syncKey =
    playbackState?.forceSyncKey ||
    playbackState?.clientSyncedAt ||
    playbackState?.lastSyncedAt ||
    playbackState?.updatedAt ||
    playbackState?.eventId ||
    `${mediaKey}:${status}:${positionSeconds}`;

  const runSuppressed = useCallback((fn, timeout = 700) => {
    suppressEventRef.current = true;

    try {
      fn();
    } finally {
      setTimeout(() => {
        suppressEventRef.current = false;
      }, timeout);
    }
  }, []);

  const sendCommand = useCallback(
    (action, position, extra = {}) => {
      if (!canControl) return;
      if (suppressEventRef.current) return;

      const safePosition = getSafeNumber(position, 0);

      onLocalCommand?.(action, {
        positionSeconds: safePosition,
        currentPositionSeconds: safePosition,
        playbackSpeed,
        ...extra,
      });
    },
    [canControl, onLocalCommand, playbackSpeed],
  );

  const applyYoutubePlayback = useCallback(
  (state) => {
    const player = playerRef.current;

    if (!state) return;

    if (!player || typeof player.seekTo !== "function") {
      pendingPlaybackRef.current = state;
      return;
    }

    const nextStatus = normalizeStatus(state.playbackStatus);
    const nextPosition = getSafeNumber(state.currentPositionSeconds, 0);
    const nextSpeed = getSafeNumber(state.playbackSpeed, 1);

    const incomingAction = String(state.action || "").toUpperCase();

    const isHardSync =
      nextStatus === "SYNC" ||
      incomingAction === "SEEK";

    const previous = lastAppliedYoutubeStateRef.current;

    const isRepeatedState =
      String(previous.mediaKey || "") === String(mediaKey || "") &&
      previous.status === nextStatus &&
      Math.abs(Number(previous.position || 0) - nextPosition) < 0.25;

    const shouldIgnoreRepeatedPlayingPosition =
      nextStatus === "PLAYING" &&
      isRepeatedState &&
      !isHardSync;

    runSuppressed(() => {
      const current = getSafeNumber(player.getCurrentTime?.(), 0);
      const diff = Math.abs(current - nextPosition);

      if (
        !shouldIgnoreRepeatedPlayingPosition &&
        (diff > 1.2 || isHardSync)
      ) {
        console.log("SEEK TO:", nextPosition);
        player.seekTo(nextPosition, true);
      }

      if (typeof player.setPlaybackRate === "function") {
        try {
          player.setPlaybackRate(nextSpeed);
        } catch {
          // unsupported playback rate
        }
      }

      setTimeout(() => {
        const YT = window.YT;

        if (!YT || !player.getPlayerState) return;

        const playerState = player.getPlayerState();

        if (nextStatus === "PLAYING") {
          if (
            playerState !== YT.PlayerState.PLAYING &&
            playerState !== YT.PlayerState.BUFFERING
          ) {
            player.playVideo();
          }
        } else if (
          nextStatus === "PAUSED" ||
          nextStatus === "STOPPED" ||
          nextStatus === "ENDED" ||
          nextStatus === "SYNC"
        ) {
          if (
            playerState === YT.PlayerState.PLAYING ||
            playerState === YT.PlayerState.BUFFERING
          ) {
            player.pauseVideo();
          }
        }
      }, 120);
    }, 900);

    lastAppliedYoutubeStateRef.current = {
      mediaKey,
      status: nextStatus,
      position: nextPosition,
    };
  },
  [runSuppressed, mediaKey],
);

  const applyDirectPlayback = useCallback(
    (state) => {
      const video = videoRef.current;

      if (!video || !state) return;

      const nextStatus = normalizeStatus(state.playbackStatus);
      const nextPosition = getSafeNumber(state.currentPositionSeconds, 0);
      const nextSpeed = getSafeNumber(state.playbackSpeed, 1);

      runSuppressed(() => {
        const diff = Math.abs(video.currentTime - nextPosition);

        if (diff > 0.25 || state.forceSyncKey) {
          video.currentTime = nextPosition;
        }

        if (Number.isFinite(nextSpeed) && nextSpeed > 0) {
          video.playbackRate = nextSpeed;
        }

        if (nextStatus === "PLAYING") {
          if (video.paused) {
            video.play().catch(() => {});
          }
        } else {
          if (!video.paused) {
            video.pause();
          }
        }
      }, 700);
    },
    [runSuppressed],
  );

  useEffect(() => {
  if (!url || !ytId) {
    setYoutubeReady(false);
    return;
  }

  let destroyed = false;

  setYoutubeReady(false);
  pendingPlaybackRef.current = playbackState || null;

  (async () => {
    const YT = await loadYouTubeAPI();

    if (destroyed) return;
    if (!containerRef.current) return;

    // ВАЖНО:
    // не пересоздаём плеер, если он уже есть для этого же видео
    if (playerRef.current && playerRef.current.__videoId === ytId) {
      setYoutubeReady(true);

      if (pendingPlaybackRef.current) {
        applyYoutubePlayback(pendingPlaybackRef.current);
        pendingPlaybackRef.current = null;
      }

      return;
    }

    // Если был старый YouTube-плеер от другого видео — удаляем аккуратно
    if (playerRef.current && playerRef.current.destroy) {
      try {
        playerRef.current.destroy();
      } catch {
        // ignore
      }

      playerRef.current = null;
    }

    playerRef.current = new YT.Player(containerRef.current, {
      videoId: ytId,
      playerVars: {
        rel: 0,
        modestbranding: 1,
        playsinline: 1,
        enablejsapi: 1,
        autoplay: 0,
      },
      events: {
        onReady: () => {
          if (destroyed) return;

          if (playerRef.current) {
            playerRef.current.__videoId = ytId;
          }

          setYoutubeReady(true);

          const initialState = pendingPlaybackRef.current || playbackState;

          if (initialState) {
            setTimeout(() => {
              applyYoutubePlayback(initialState);
              pendingPlaybackRef.current = null;
            }, 150);
          }
        },

        onStateChange: (e) => {
          if (suppressEventRef.current) return;
          if (!canControl) return;
          if (!playerRef.current) return;

          const currentTime = getSafeNumber(
            playerRef.current.getCurrentTime?.(),
            0
          );

          if (e.data === YT.PlayerState.PLAYING) {
            sendCommand("PLAY", currentTime);
          }

          if (e.data === YT.PlayerState.PAUSED) {
            sendCommand("PAUSE", currentTime);
          }

          if (e.data === YT.PlayerState.ENDED) {
            const endPosition = getSafeNumber(
              playerRef.current.getDuration?.() ||
                playerRef.current.getCurrentTime?.() ||
                0,
              0
            );

            sendCommand("ENDED", endPosition);
          }
        },
      },
    });
  })();

  return () => {
    destroyed = true;
  };
}, [
  url,
  ytId,
  canControl,
  playbackState,
  applyYoutubePlayback,
  sendCommand,
]);

  useEffect(() => {
    if (!url || !playbackState) return;

    const isNewMedia = lastMediaKeyRef.current !== mediaKey;
    const isNewSync = lastSyncKeyRef.current !== syncKey;

    if (!isNewMedia && !isNewSync) return;

    lastMediaKeyRef.current = mediaKey;
    lastSyncKeyRef.current = syncKey;

    if (ytId) {
      if (!youtubeReady) {
        pendingPlaybackRef.current = playbackState;
        return;
      }

      applyYoutubePlayback(playbackState);
      return;
    }

    applyDirectPlayback(playbackState);
  }, [
    url,
    ytId,
    youtubeReady,
    mediaKey,
    syncKey,
    playbackState,
    applyYoutubePlayback,
    applyDirectPlayback,
  ]);

  useEffect(() => {
    if (!ytId || !canControl || !youtubeReady) return;

    const id = setInterval(() => {
      if (suppressEventRef.current) return;

      const player = playerRef.current;

      if (!player || typeof player.getCurrentTime !== "function") return;

      const currentTime = getSafeNumber(player.getCurrentTime(), 0);
      const prevTime = lastYoutubeTimeRef.current;
      const diff = Math.abs(currentTime - prevTime);

      lastYoutubeTimeRef.current = currentTime;

      const now = Date.now();

      if (diff > 2.5 && now - lastSentYoutubeSeekRef.current > 800) {
        lastSentYoutubeSeekRef.current = now;

        sendCommand("SEEK", currentTime);
      }
    }, 500);

    return () => clearInterval(id);
  }, [ytId, canControl, youtubeReady, sendCommand]);

  if (!url) {
    return (
      <div className="video-wrapper flex items-center justify-center text-[var(--text-secondary)] min-h-[280px]">
        <div className="text-center">
          <div className="font-serif text-2xl mb-2 tracking-wide">
            NO VIDEO PLAYING
          </div>
          <p className="text-sm">Queue a video or pick one from the catalog.</p>
        </div>
      </div>
    );
  }

  if (ytId) {
    return (
      <div className="video-wrapper" data-testid="video-player-youtube">
        <div ref={containerRef} />
      </div>
    );
  }

  if (isDirectVideo(url)) {
    return (
      <div className="video-wrapper" data-testid="video-player-direct">
        <video
          ref={videoRef}
          src={url}
          controls
          onPlay={() => {
            if (suppressEventRef.current) return;

            const current = getSafeNumber(videoRef.current?.currentTime, 0);
            sendCommand("PLAY", current);
          }}
          onPause={() => {
            if (suppressEventRef.current) return;

            const current = getSafeNumber(videoRef.current?.currentTime, 0);
            sendCommand("PAUSE", current);
          }}
          onSeeked={() => {
            if (suppressEventRef.current) return;

            const now = Date.now();

            if (now - lastSentDirectSeekRef.current < 400) return;

            lastSentDirectSeekRef.current = now;

            const current = getSafeNumber(videoRef.current?.currentTime, 0);
            sendCommand("SEEK", current);
          }}
          onEnded={() => {
            if (suppressEventRef.current) return;

            const endPosition = getSafeNumber(
              videoRef.current?.duration || videoRef.current?.currentTime || 0,
              0,
            );

            sendCommand("ENDED", endPosition);
          }}
        />
      </div>
    );
  }

  return (
    <div className="video-wrapper flex items-center justify-center text-[var(--text-secondary)] min-h-[280px] p-6 text-center">
      <div>
        <div className="font-serif text-xl mb-2">Unsupported source</div>
        <a
          href={url}
          target="_blank"
          rel="noreferrer"
          className="text-[var(--violet-bright)] underline break-all"
        >
          {url}
        </a>
      </div>
    </div>
  );
}