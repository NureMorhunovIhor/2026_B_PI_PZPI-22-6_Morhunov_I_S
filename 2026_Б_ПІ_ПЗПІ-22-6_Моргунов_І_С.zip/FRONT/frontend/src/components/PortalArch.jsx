import React from "react";

export default function PortalArch() {
  return (
    <div className="portal-arch" aria-hidden="true">
      <svg viewBox="0 0 320 480" fill="none" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <radialGradient id="pg" cx="50%" cy="75%" r="55%">
            <stop offset="0%" stopColor="#a855f7" stopOpacity="0.5" />
            <stop offset="70%" stopColor="#4c1d95" stopOpacity="0.1" />
            <stop offset="100%" stopColor="#4c1d95" stopOpacity="0" />
          </radialGradient>
          <linearGradient id="ring" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#fde68a" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.3" />
          </linearGradient>
        </defs>
        {/* Fill */}
        <path d="M20 460 L20 180 Q20 20 160 20 Q300 20 300 180 L300 460 Z" fill="url(#pg)" />
        {/* Concentric arches */}
        {[0, 1, 2, 3, 4, 5].map((i) => {
          const inset = 20 + i * 18;
          return (
            <path
              key={i}
              d={`M${inset} 460 L${inset} ${180 + i * 4} Q${inset} ${20 + i * 18} 160 ${20 + i * 18} Q${320 - inset} ${20 + i * 18} ${320 - inset} ${180 + i * 4} L${320 - inset} 460`}
              stroke="url(#ring)"
              strokeWidth="1"
              fill="none"
              opacity={0.5 - i * 0.05}
            />
          );
        })}
        {/* TV icon at the bottom */}
        <g transform="translate(130 280)">
          <rect x="0" y="0" width="60" height="48" rx="8" stroke="#c4b5fd" strokeWidth="1.5" fill="rgba(139,92,246,0.15)" />
          <line x1="20" y1="-12" x2="30" y2="0" stroke="#c4b5fd" strokeWidth="1.5" />
          <line x1="40" y1="-12" x2="30" y2="0" stroke="#c4b5fd" strokeWidth="1.5" />
        </g>
        {/* Stars */}
        {[
          [160, 120],
          [100, 220],
          [220, 200],
          [140, 340],
          [200, 400],
          [120, 380],
        ].map(([cx, cy], i) => (
          <g key={`s${i}`} transform={`translate(${cx} ${cy})`}>
            <path
              d="M0 -6 L1.5 -1.5 L6 0 L1.5 1.5 L0 6 L-1.5 1.5 L-6 0 L-1.5 -1.5 Z"
              fill="#fde68a"
              opacity="0.9"
            >
              <animate
                attributeName="opacity"
                values="0.3;1;0.3"
                dur={`${2 + (i % 3)}s`}
                repeatCount="indefinite"
              />
            </path>
          </g>
        ))}
      </svg>
    </div>
  );
}
