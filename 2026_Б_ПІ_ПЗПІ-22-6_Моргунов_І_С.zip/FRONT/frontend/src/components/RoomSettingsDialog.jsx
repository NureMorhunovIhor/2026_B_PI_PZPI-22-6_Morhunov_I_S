import React, { useState } from "react";
import {
  AlertTriangle,
  Globe,
  Image as ImageIcon,
  Lock,
  Paintbrush,
  RefreshCcw,
  Save,
  Sparkles,
  Trash2,
  Users,
  X,
  BarChart3,
} from "lucide-react";

import { Link } from "react-router-dom";
import client, { formatApiError } from "../api";
import { useAuth } from "../AuthContext";

const THEME_PRESETS = [
  { id: null, label: "Default", color: "#8b5cf6" },
  { id: "#ec4899", label: "Pink", color: "#ec4899" },
  { id: "#f59e0b", label: "Amber", color: "#f59e0b" },
  { id: "#10b981", label: "Emerald", color: "#10b981" },
  { id: "#3b82f6", label: "Blue", color: "#3b82f6" },
  { id: "#ef4444", label: "Red", color: "#ef4444" },
  { id: "#06b6d4", label: "Cyan", color: "#06b6d4" },
  { id: "#a855f7", label: "Purple", color: "#a855f7" },
];
export default function RoomSettingsDialog({ room, billing, onClose, onUpdated, onClosed, onCodeRegenerated }) {
  const roomCode = room?.roomCode || room?.code;
  const { user } = useAuth();
  const currentPlanId = String(
  billing?.currentPlan?.id ||
  billing?.plan?.id ||
  billing?.planId ||
  billing?.currentPlanId ||
  billing?.id ||
  user?.planId ||
  "FREE"
).toUpperCase();

const canCustomize = currentPlanId !== "FREE";
console.log("ROOM SETTINGS BILLING:", billing);
console.log("ROOM SETTINGS PLAN:", currentPlanId);
console.log("ROOM SETTINGS CAN CUSTOMIZE:", canCustomize);

const canViewStats =
  Boolean(billing?.allowRoomStatistics) ||
  Boolean(billing?.currentPlan?.allowRoomStatistics) ||
  Boolean(billing?.plan?.allowRoomStatistics) ||
  currentPlanId === "PRO";

  const [tab, setTab] = useState("general");

  const [form, setForm] = useState({
  name: room?.name || "",
  description: room?.description || "",
  roomType: room?.roomType || "PUBLIC",
  accessMode: room?.accessMode || "OPEN",
  maxParticipants: room?.maxParticipants || 10,
  themeColor: room?.themeColor || null,
  coverImageUrl: room?.coverImageUrl || "",
  backgroundUrl: room?.backgroundUrl || "",
});
  const accentColor = form.themeColor || "#8b5cf6";
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [confirmClose, setConfirmClose] = useState(false);
  const [confirmRegen, setConfirmRegen] = useState(false);
  const [stats, setStats] = useState(null);
  const [statsLoading, setStatsLoading] = useState(false);

  const handle = (field) => (e) =>
    setForm((f) => ({
      ...f,
      [field]: field === "maxParticipants" ? Number(e.target.value) : e.target.value,
    }));

  const save = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError("");
    setSuccess("");
    try {
      const payload = { ...form };
      if (!canCustomize) {
        delete payload.themeColor;
        delete payload.coverImageUrl;
        delete payload.backgroundUrl;
      }
      const { data } = await client.put(`/rooms/${roomCode}`, payload);
      onUpdated?.(data);
      setSuccess("Saved");
      setTimeout(() => setSuccess(""), 1500);
    } catch (err) {
      setError(formatApiError(err));
    } finally {
      setSaving(false);
    }
  };

  const loadStats = async () => {
  setStatsLoading(true);
  setError("");

  try {
    const { data } = await client.get(`/rooms/${roomCode}/stats`);
    setStats(data);
  } catch (err) {
    setError(formatApiError(err));
  } finally {
    setStatsLoading(false);
  }
};
  const regenerate = async () => {
  setSaving(true);
  setError("");

  try {
    const { data } = await client.post(`/rooms/${roomCode}/regenerate-code`);

    const newCode =
      typeof data === "string"
        ? data
        : data?.newCode || data?.roomCode || data?.code;

    if (newCode) {
      onCodeRegenerated?.(newCode);
    }

    setConfirmRegen(false);
  } catch (err) {
    setError(formatApiError(err));
  } finally {
    setSaving(false);
  }
};

  const closeRoom = async () => {
    setSaving(true);
    setError("");
    try {
      await client.delete(`/rooms/${roomCode}`);
      onClosed?.();
    } catch (err) {
      setError(formatApiError(err));
      setSaving(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="glass-card w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
        data-testid="room-settings-dialog"
      >
        <div className="flex items-center justify-between p-5 border-b border-violet-500/15">
          <h2 className="font-serif text-xl tracking-wide">ROOM SETTINGS</h2>
          <button
            onClick={onClose}
            className="text-[var(--text-secondary)] hover:text-white"
            data-testid="close-room-settings"
          >
            <X size={20} />
          </button>
        </div>
        <div className="flex p-1 mx-5 mt-4 bg-violet-500/10 rounded-full">
          {[
            { id: "general", label: "General", icon: Save },
            { id: "appearance", label: "Appearance", icon: Paintbrush, premium: true },
            { id: "stats", label: "Stats", icon: BarChart3, pro: true },
          ].map((t) => {
            const Icon = t.icon;

            return (
              <button
                key={t.id}
                onClick={() => {
                  setTab(t.id);

                  if (t.id === "stats" && canViewStats && !stats) {
                    loadStats();
                  }
                }}
                className={`flex-1 inline-flex items-center justify-center gap-1.5 py-2 rounded-full text-sm font-semibold transition ${
                  tab === t.id
                    ? "text-white"
                    : "text-[var(--text-secondary)] hover:text-white"
                }`}
                style={
                  tab === t.id
                    ? {
                        background: `linear-gradient(135deg, ${accentColor}, ${accentColor}cc)`,
                      }
                    : undefined
                }
                data-testid={`room-settings-tab-${t.id}`}
              >
                <Icon size={14} /> {t.label}
                {t.premium && !canCustomize && (
                  <span className="text-[9px] tracking-wider font-bold uppercase bg-amber-500/30 text-amber-200 px-1.5 py-0.5 rounded-full ml-1">
                    Pro
                  </span>
                )}
                {t.pro && !canViewStats && (
                  <span className="text-[9px] tracking-wider font-bold uppercase bg-cyan-500/30 text-cyan-200 px-1.5 py-0.5 rounded-full ml-1">
                    Pro
                  </span>
                )}
              </button>
            );
          })}
        </div>
        <div className="flex-1 overflow-y-auto p-5 space-y-6">
          {tab === "general" && (
          <form onSubmit={save} className="space-y-5">
            <div>
              <label className="label">Room Name</label>
              <input
                className="input-field-dark"
                value={form.name}
                onChange={handle("name")}
                required
                minLength={1}
                data-testid="settings-room-name"
              />
            </div>

            <div>
              <label className="label">Description</label>
              <textarea
                className="input-field-dark min-h-[90px] resize-y"
                value={form.description}
                onChange={handle("description")}
                data-testid="settings-room-description"
              />
            </div>

            <div>
              <label className="label">Room Type</label>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { id: "PUBLIC", label: "Public", icon: Globe, desc: "Anyone can find & join", access: "OPEN" },
                  { id: "FRIENDS_ONLY", label: "Friends", icon: Users, desc: "Only your friends", access: "INVITE_ONLY" },
                  { id: "PRIVATE", label: "Private", icon: Lock, desc: "Code / invite only", access: "LINK_ONLY" },
                ].map((t) => {
                  const Icon = t.icon;
                  const active = form.roomType === t.id;
                  return (
                    <button
                      type="button"
                      key={t.id}
                      onClick={() =>
                        setForm((f) => ({ ...f, roomType: t.id, accessMode: t.access }))
                      }
                      className={`p-4 rounded-2xl border text-left transition-all ${
                        active
                          ? "border-violet-500 bg-violet-500/15"
                          : "border-violet-500/15 bg-violet-500/5 hover:border-violet-500/40"
                      }`}
                      data-testid={`settings-type-${t.id}`}
                    >
                      <Icon size={18} className="mb-2 text-[var(--violet-soft)]" />
                      <div className="font-semibold text-white text-sm">{t.label}</div>
                      <div className="text-xs text-[var(--text-secondary)] mt-0.5">{t.desc}</div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="label">Max Participants ({form.maxParticipants})</label>
              <input
                type="range"
                min="2"
                max="100"
                value={form.maxParticipants}
                onChange={handle("maxParticipants")}
                className="w-full accent-violet-500"
                data-testid="settings-max"
              />
              <div className="flex justify-between text-xs text-[var(--text-muted)] mt-1">
                <span>2</span>
                <span>100</span>
              </div>
            </div>

            {error && (
              <div className="text-sm text-pink-300 bg-pink-500/10 border border-pink-500/30 rounded-xl px-4 py-3" data-testid="settings-error">
                {error}
              </div>
            )}
            {success && (
              <div className="text-sm text-emerald-300 bg-emerald-500/10 border border-emerald-500/30 rounded-xl px-4 py-3" data-testid="settings-success">
                {success}
              </div>
            )}

            <button
              type="submit"
              className="btn-primary inline-flex items-center gap-2"
              disabled={saving}
              data-testid="settings-save-btn"
            >
              <Save size={15} /> {saving ? "Saving..." : "Save changes"}
            </button>
          </form>
          )}
          {tab === "appearance" && (
  <div className="space-y-5">
    {!canCustomize ? (
      <div className="text-center py-10">
        <div className="w-14 h-14 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-amber-400 to-pink-500 flex items-center justify-center">
          <Sparkles size={22} className="text-white" />
        </div>
        <h3 className="font-serif text-xl tracking-wide mb-2">Premium feature</h3>
        <p className="text-sm text-[var(--text-secondary)] mb-5 max-w-sm mx-auto">
          Customize your room with a theme color, cover image and immersive background.
          Upgrade to Premium to unlock.
        </p>
        <Link
          to="/pricing"
          onClick={onClose}
          className="btn-primary inline-flex items-center gap-2"
          data-testid="appearance-upgrade-cta"
        >
          <Sparkles size={14} /> See pricing
        </Link>
      </div>
    ) : (
      <form onSubmit={save} className="space-y-5">
        <div>
          <label className="label">Theme color</label>
          <p className="text-xs text-[var(--text-muted)] mb-3">
            Accent for room highlights — buttons, dividers and badges.
          </p>

          <div className="grid grid-cols-8 gap-2">
            {THEME_PRESETS.map((t) => {
              const active = (form.themeColor || null) === t.id;

              return (
                <button
                  key={t.label}
                  type="button"
                  onClick={() => setForm((f) => ({ ...f, themeColor: t.id }))}
                  className={`relative aspect-square rounded-xl transition ${
                    active
                      ? "ring-2 ring-white scale-105"
                      : "ring-1 ring-violet-500/20 hover:ring-violet-500/60"
                  }`}
                  style={{ backgroundColor: t.color }}
                  title={t.label}
                  data-testid={`theme-${t.label.toLowerCase()}`}
                >
                  {active && (
                    <span className="absolute inset-0 flex items-center justify-center">
                      <span className="w-2 h-2 bg-white rounded-full" />
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        <div>
          <label className="label">Cover image URL</label>
          <input
            className="input-field-dark"
            placeholder="https://images.unsplash.com/photo-..."
            value={form.coverImageUrl}
            onChange={(e) =>
              setForm((f) => ({ ...f, coverImageUrl: e.target.value }))
            }
            data-testid="cover-url-input"
          />

          {form.coverImageUrl && (
            <div className="mt-3 relative rounded-xl overflow-hidden border border-violet-500/20">
              <img
                src={form.coverImageUrl}
                alt=""
                className="w-full h-28 object-cover"
                onError={(e) => {
                  e.currentTarget.style.display = "none";
                }}
              />
              <button
                type="button"
                onClick={() => setForm((f) => ({ ...f, coverImageUrl: "" }))}
                className="absolute top-2 right-2 bg-black/60 rounded-full p-1 hover:bg-black/80"
              >
                <X size={14} />
              </button>
            </div>
          )}
        </div>

        <div>
          <label className="label">Background image URL</label>
          <input
            className="input-field-dark"
            placeholder="https://images.unsplash.com/photo-..."
            value={form.backgroundUrl}
            onChange={(e) =>
              setForm((f) => ({ ...f, backgroundUrl: e.target.value }))
            }
            data-testid="background-url-input"
          />

          {form.backgroundUrl && (
            <div className="mt-3 relative rounded-xl overflow-hidden border border-violet-500/20">
              <img
                src={form.backgroundUrl}
                alt=""
                className="w-full h-28 object-cover"
                onError={(e) => {
                  e.currentTarget.style.display = "none";
                }}
              />
              <button
                type="button"
                onClick={() => setForm((f) => ({ ...f, backgroundUrl: "" }))}
                className="absolute top-2 right-2 bg-black/60 rounded-full p-1 hover:bg-black/80"
              >
                <X size={14} />
              </button>
            </div>
          )}
        </div>

        {error && (
          <div className="text-sm text-pink-300 bg-pink-500/10 border border-pink-500/30 rounded-xl px-4 py-3">
            {error}
          </div>
        )}

        {success && (
          <div className="text-sm text-emerald-300 bg-emerald-500/10 border border-emerald-500/30 rounded-xl px-4 py-3">
            {success}
          </div>
        )}

        <button
          type="submit"
          className="inline-flex items-center gap-2 px-5 py-3 rounded-xl font-semibold text-white transition disabled:opacity-60"
          style={{
            background: `linear-gradient(135deg, ${accentColor}, ${accentColor}cc)`,
            boxShadow: `0 12px 30px ${accentColor}40`,
          }}
          disabled={saving}
        >
          <Save size={15} /> {saving ? "Saving..." : "Save appearance"}
        </button>
      </form>
    )}
  </div>
)}
{tab === "stats" && (
  <div className="space-y-5">
    {!canViewStats ? (
      <div className="text-center py-10">
        <div className="w-14 h-14 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center">
          <BarChart3 size={22} className="text-white" />
        </div>

        <h3 className="font-serif text-xl tracking-wide mb-2">
          Pro statistics
        </h3>

        <p className="text-sm text-[var(--text-secondary)] mb-5 max-w-sm mx-auto">
          Room statistics are available only for Pro users.
          Upgrade to unlock analytics for your watch parties.
        </p>

        <Link
          to="/pricing"
          onClick={onClose}
          className="btn-primary inline-flex items-center gap-2"
        >
          <Sparkles size={14} /> See pricing
        </Link>
      </div>
    ) : (
      <>
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-serif text-xl tracking-wide">Room statistics</h3>
            <p className="text-xs text-[var(--text-muted)]">
              Analytics for this watch room.
            </p>
          </div>

          <button
            type="button"
            onClick={loadStats}
            className="btn-ghost !py-2 !px-3 text-xs inline-flex items-center gap-1.5"
            disabled={statsLoading}
          >
            <RefreshCcw size={13} />
            {statsLoading ? "Loading..." : "Refresh"}
          </button>
        </div>

        {!stats ? (
          <div className="text-sm text-[var(--text-secondary)] py-8 text-center">
            {statsLoading ? "Loading statistics..." : "No statistics loaded yet."}
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 gap-3">
            <StatCard label="Messages" value={stats.messagesCount} />
            <StatCard label="Reactions" value={stats.reactionsCount} />
            <StatCard label="Participants online" value={stats.currentParticipantsCount} />
            <StatCard label="Queue items" value={stats.queueItemsCount} />
            <StatCard label="Played items" value={stats.playedItemsCount} />
            <StatCard label="Removed items" value={stats.removedItemsCount} />

            <div className="sm:col-span-2 rounded-2xl border border-violet-500/20 bg-violet-500/5 p-4">
              <div className="text-xs uppercase tracking-widest text-[var(--violet-soft)] mb-1">
                Now playing
              </div>
              <div className="font-semibold text-white truncate">
                {stats.currentMediaTitle || "Nothing is playing"}
              </div>
            </div>
          </div>
        )}
      </>
    )}
  </div>
)}
          {/* Danger zone */}
          <div className="pt-5 border-t border-violet-500/15">
            <h3 className="font-serif text-sm tracking-widest text-pink-300 mb-3">DANGER ZONE</h3>

            <div className="space-y-3">
              {/* Regenerate code */}
              <div className="flex items-center justify-between gap-3 p-3 rounded-xl border border-violet-500/20 bg-violet-500/5">
                <div className="min-w-0">
                  <div className="font-semibold text-sm">Regenerate room code</div>
                  <div className="text-xs text-[var(--text-secondary)]">
                    Existing share links will stop working.
                  </div>
                </div>
                {!confirmRegen ? (
                  <button
                    onClick={() => setConfirmRegen(true)}
                    className="btn-ghost !py-2 inline-flex items-center gap-2 text-xs whitespace-nowrap"
                    data-testid="settings-regen-btn"
                  >
                    <RefreshCcw size={14} /> Regenerate
                  </button>
                ) : (
                  <div className="flex gap-2">
                    <button
                      onClick={regenerate}
                      className="btn-primary !py-2 text-xs whitespace-nowrap"
                      disabled={saving}
                      data-testid="settings-regen-confirm"
                    >
                      Confirm
                    </button>
                    <button
                      onClick={() => setConfirmRegen(false)}
                      className="btn-ghost !py-2 text-xs"
                      data-testid="settings-regen-cancel"
                    >
                      Cancel
                    </button>
                  </div>
                )}
              </div>

              {/* Close room */}
              <div className="flex items-center justify-between gap-3 p-3 rounded-xl border border-pink-500/30 bg-pink-500/5">
                <div className="min-w-0">
                  <div className="font-semibold text-sm text-pink-200 inline-flex items-center gap-1.5">
                    <AlertTriangle size={14} /> Close room
                  </div>
                  <div className="text-xs text-[var(--text-secondary)]">
                    Permanently end this watch party. Cannot be undone.
                  </div>
                </div>
                {!confirmClose ? (
                  <button
                    onClick={() => setConfirmClose(true)}
                    className="btn-ghost !py-2 inline-flex items-center gap-2 text-xs !text-pink-300 whitespace-nowrap"
                    data-testid="settings-close-btn"
                  >
                    <Trash2 size={14} /> Close
                  </button>
                ) : (
                  <div className="flex gap-2">
                    <button
                      onClick={closeRoom}
                      className="btn-primary !py-2 text-xs whitespace-nowrap !bg-gradient-to-r !from-pink-500 !to-rose-500"
                      disabled={saving}
                      data-testid="settings-close-confirm"
                    >
                      Yes, close it
                    </button>
                    <button
                      onClick={() => setConfirmClose(false)}
                      className="btn-ghost !py-2 text-xs"
                      data-testid="settings-close-cancel"
                    >
                      Cancel
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
function StatCard({ label, value }) {
  return (
    <div className="rounded-2xl border border-violet-500/20 bg-violet-500/5 p-4">
      <div className="text-xs uppercase tracking-widest text-[var(--violet-soft)] mb-1">
        {label}
      </div>
      <div className="font-serif text-3xl text-white">
        {value ?? 0}
      </div>
    </div>
  );
}