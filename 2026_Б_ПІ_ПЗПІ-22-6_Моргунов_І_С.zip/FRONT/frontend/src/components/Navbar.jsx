import React, { useEffect, useState, useRef } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import {
  Bell,
  Check,
  ChevronDown,
  Crown,
  Home,
  LogIn,
  LogOut,
  Settings,
  Sparkles,
  Tv,
  UserPlus,
  Users,
  X,
} from "lucide-react";
import Logo from "./Logo";
import { useAuth } from "../AuthContext";
import client from "../api";
import { resolveAvatarUrl } from "../utils/avatar";
import SockJS from "sockjs-client";
import { Client } from "@stomp/stompjs";

export default function Navbar() {
  const { user, logout } = useAuth();
  const nav = useNavigate();

  const [unread, setUnread] = useState(0);
  const [notifs, setNotifs] = useState([]);
  const [toastNotifications, setToastNotifications] = useState([]);

  const [bellOpen, setBellOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [avatarBroken, setAvatarBroken] = useState(false);

  const bellRef = useRef(null);
  const menuRef = useRef(null);
  const stompRef = useRef(null);
  const seenNotifIdsRef = useRef(new Set());
  const notificationsInitializedRef = useRef(false);

  const loadNotifs = async () => {
  try {
    const [c, l] = await Promise.all([
      client.get("/notifications/unread-count"),
      client.get("/notifications"),
    ]);

    const list = l.data || [];

    setUnread(c.data.count || 0);
    setNotifs(list.slice(0, 8));

    const unreadList = list.filter((n) => !n.isRead);

    if (!notificationsInitializedRef.current) {
      unreadList.forEach((n) => seenNotifIdsRef.current.add(n.id));
      notificationsInitializedRef.current = true;
      return;
    }

    const fresh = unreadList.filter((n) => !seenNotifIdsRef.current.has(n.id));

    if (fresh.length > 0) {
      fresh.forEach((n) => seenNotifIdsRef.current.add(n.id));

      setToastNotifications((cur) => {
        const merged = [...fresh, ...cur];

        const unique = [];
        const ids = new Set();

        for (const item of merged) {
          if (!ids.has(item.id)) {
            unique.push(item);
            ids.add(item.id);
          }
        }

        return unique.slice(0, 4);
      });

      fresh.forEach((n) => {
        setTimeout(() => {
          closeToast(n.id);
        }, 6000);
      });
    }
  } catch {
  }
};

const closeToast = (id) => {
  setToastNotifications((cur) => cur.filter((n) => n.id !== id));
};

const showToast = (notification) => {
  if (!notification?.id) return;

  setToastNotifications((cur) => {
    const exists = cur.some((n) => n.id === notification.id);

    if (exists) return cur;

    return [notification, ...cur].slice(0, 4);
  });

  setTimeout(() => {
    closeToast(notification.id);
  }, 6000);
};

  useEffect(() => {
  if (!user?.username) return;

  loadNotifs();

  const stompClient = new Client({
    webSocketFactory: () => new SockJS("http://localhost:8080/ws"),
    reconnectDelay: 5000,
    onConnect: () => {
      stompRef.current = stompClient;

      stompClient.subscribe(`/topic/notifications/${user.username}`, (message) => {
        try {
          const notification = JSON.parse(message.body);

          setUnread((cur) => cur + 1);

          setNotifs((cur) => {
            const exists = cur.some((n) => n.id === notification.id);
            if (exists) return cur;

            return [notification, ...cur].slice(0, 8);
          });

          showToast(notification);
        } catch (e) {
          console.error("Failed to parse notification WS:", e);
        }
      });
    },
    onStompError: (frame) => {
      console.error("Notification STOMP error:", frame);
    },
    onWebSocketError: (error) => {
      console.error("Notification WS error:", error);
    },
  });

  stompClient.activate();

  const id = setInterval(loadNotifs, 30000);

  return () => {
    clearInterval(id);
    stompClient.deactivate();
    stompRef.current = null;
  };
}, [user?.username]);

  useEffect(() => {
    const onClick = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) setMenuOpen(false);
      if (bellRef.current && !bellRef.current.contains(e.target)) setBellOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const acceptInvite = async (n, e) => {
  e?.stopPropagation();

  const roomCode = n.roomCode;

  if (!roomCode) return;

  try {
    await client.post(`/rooms/${roomCode}/accept-invite`);

    setNotifs((cur) => cur.filter((x) => x.id !== n.id));
    setBellOpen(false);

    try {
      await client.delete(`/notifications/${n.id}`);
    } catch (deleteErr) {
      console.warn("Notification delete failed:", deleteErr?.response?.data || deleteErr);
    }

    loadNotifs();
    nav(`/rooms/${roomCode}`);
  } catch (err) {
    console.error("Accept invite failed:", err?.response?.data || err);
  }
};

  const dismissNotif = async (n, e) => {
    e?.stopPropagation();
    try {
      await client.delete(`/notifications/${n.id}`);
      setNotifs((cur) => cur.filter((x) => x.id !== n.id));
      loadNotifs();
    } catch {
      // ignore
    }
  };

  const initial = (user?.displayName || user?.username || "?")[0]?.toUpperCase();
  const avatarUrl = user?.avatarUrl;

  return (
    <div className="nav-wrapper">
      {toastNotifications.length > 0 && (
  <div className="fixed top-20 right-5 z-[9999] flex flex-col gap-3 w-[340px] max-w-[calc(100vw-24px)]">
    {toastNotifications.map((n) => {
      const isInvite = n.type === "ROOM_INVITE" && n.roomCode;
      const isFriendReq = n.type === "FRIEND_REQUEST";

      return (
        <div
          key={n.id}
          className="glass-card p-4 border border-violet-500/30 shadow-2xl shadow-violet-900/30 animate-[fadeIn_0.2s_ease-out]"
          data-testid={`toast-notif-${n.id}`}
        >
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-violet-500/15 border border-violet-500/30 flex items-center justify-center flex-shrink-0">
              {isInvite ? (
                <LogIn size={16} className="text-[var(--violet-soft)]" />
              ) : isFriendReq ? (
                <UserPlus size={16} className="text-pink-300" />
              ) : (
                <Bell size={16} className="text-[var(--violet-soft)]" />
              )}
            </div>

            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold text-white leading-tight">
                {n.title}
              </div>

              <div className="text-xs text-[var(--text-secondary)] mt-1 line-clamp-2">
                {isInvite ? (
                  <>
                    Room code{" "}
                    <code className="text-[var(--violet-soft)] font-mono">
                      {n.roomCode}
                    </code>
                  </>
                ) : (
                  n.content || "You have a new notification."
                )}
              </div>

              {isInvite && (
                <div className="flex gap-2 mt-3">
                  <button
                    onClick={(e) => {
                      acceptInvite(n, e);
                      closeToast(n.id);
                    }}
                    className="btn-primary !py-1.5 !px-3 text-xs inline-flex items-center gap-1"
                  >
                    <Check size={12} /> Accept
                  </button>

                  <button
                    onClick={(e) => {
                      dismissNotif(n, e);
                      closeToast(n.id);
                    }}
                    className="btn-ghost !py-1.5 !px-3 text-xs inline-flex items-center gap-1"
                  >
                    <X size={12} /> Decline
                  </button>
                </div>
              )}
            </div>

            <button
              onClick={() => closeToast(n.id)}
              className="text-[var(--text-muted)] hover:text-pink-300 flex-shrink-0"
              title="Close"
            >
              <X size={15} />
            </button>
          </div>
        </div>
      );
    })}
  </div>
)}
      <div className="max-w-7xl mx-auto px-6 py-3 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3" data-testid="nav-home-link">
          <Logo size={36} withText textSize="text-lg" />
        </Link>
        <Link to="/messages" className="nav-link">
          Messages
        </Link>
        <nav className="hidden md:flex items-center gap-2">
          <NavLink to="/" end className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`} data-testid="nav-home">
            <Home size={16} /> Home
          </NavLink>
          <NavLink to="/rooms" className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`} data-testid="nav-rooms">
            <Tv size={16} /> Rooms
          </NavLink>
          <NavLink
            to="/pricing"
            className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`}
            data-testid="nav-pricing"
          >
            <Sparkles size={16} /> Pricing
          </NavLink>
          <NavLink to="/friends" className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`} data-testid="nav-friends">
            <Users size={16} /> Friends
          </NavLink>
        </nav>

        <div className="flex items-center gap-3">
          <div className="relative" ref={bellRef}>
            <button
              onClick={() => setBellOpen((v) => !v)}
              className="relative nav-link"
              data-testid="nav-notifications"
              aria-label="Notifications"
            >
              <Bell size={18} />
              {unread > 0 && (
                <span className="absolute -top-0.5 -right-0.5 bg-pink-500 text-white text-[10px] font-bold rounded-full min-w-[16px] h-4 px-1 flex items-center justify-center">
                  {unread > 9 ? "9+" : unread}
                </span>
              )}
            </button>

            {bellOpen && (
              <div
                className="absolute right-0 top-[calc(100%+8px)] w-[360px] max-h-[460px] glass-card overflow-hidden flex flex-col"
                data-testid="notif-dropdown"
              >
                <div className="flex items-center justify-between p-3 border-b border-violet-500/15">
                  <div className="font-serif tracking-wider text-sm">NOTIFICATIONS</div>
                  <Link
                    to="/notifications"
                    onClick={() => setBellOpen(false)}
                    className="text-xs text-[var(--violet-bright)] hover:text-pink-400"
                  >
                    View all
                  </Link>
                </div>

                <div className="flex-1 overflow-y-auto">
                  {notifs.length === 0 ? (
                    <div className="text-center text-sm text-[var(--text-secondary)] py-10 px-4">
                      <Bell size={22} className="mx-auto mb-2 opacity-60" />
                      You're all caught up!
                    </div>
                  ) : (
                    notifs.map((n) => {
                      const isInvite = n.type === "ROOM_INVITE" && n.roomCode;
                      const isFriendReq = n.type === "FRIEND_REQUEST";
                      return (
                        <div
                          key={n.id}
                          className={`px-3 py-2.5 border-b border-violet-500/10 ${
                            n.isRead ? "opacity-70" : "bg-violet-500/5"
                          }`}
                          data-testid={`bell-notif-${n.id}`}
                        >
                          <div className="flex items-start gap-2.5">
                            <div className="w-8 h-8 rounded-lg bg-violet-500/15 border border-violet-500/30 flex items-center justify-center flex-shrink-0">
                              {isInvite ? (
                                <LogIn size={14} className="text-[var(--violet-soft)]" />
                              ) : isFriendReq ? (
                                <UserPlus size={14} className="text-pink-300" />
                              ) : (
                                <Bell size={14} className="text-[var(--violet-soft)]" />
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="text-xs font-semibold leading-tight">{n.title}</div>
                              {isInvite ? (
                                <div className="text-[10px] text-[var(--text-muted)] mt-0.5">
                                  Code <code className="text-[var(--violet-soft)] font-mono">{n.roomCode}</code>
                                </div>
                              ) : (
                                <div className="text-[10px] text-[var(--text-muted)] mt-0.5 truncate">
                                  {n.content}
                                </div>
                              )}
                              {isInvite && (
                                <div className="flex gap-1.5 mt-2">
                                  <button
                                    onClick={(e) => acceptInvite(n, e)}
                                    className="btn-primary !py-1 !px-3 text-[11px] inline-flex items-center gap-1"
                                    data-testid={`bell-accept-${n.id}`}
                                  >
                                    <Check size={11} /> Accept
                                  </button>
                                  <button
                                    onClick={(e) => dismissNotif(n, e)}
                                    className="btn-ghost !py-1 !px-3 text-[11px] inline-flex items-center gap-1"
                                    data-testid={`bell-decline-${n.id}`}
                                  >
                                    <X size={11} /> Decline
                                  </button>
                                </div>
                              )}
                            </div>
                            {!isInvite && (
                              <button
                                onClick={(e) => dismissNotif(n, e)}
                                className="text-[var(--text-muted)] hover:text-pink-300 flex-shrink-0"
                                data-testid={`bell-dismiss-${n.id}`}
                                title="Dismiss"
                              >
                                <X size={13} />
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            )}
          </div>

          <div className="relative" ref={menuRef}>
            <button
              onClick={() => setMenuOpen((v) => !v)}
              className="flex items-center gap-2 nav-link"
              data-testid="user-menu-trigger"
            >
              <div className="relative">
                {avatarUrl ? (
                  <img
                    src={resolveAvatarUrl(avatarUrl)}
                    alt=""
                    className="w-7 h-7 rounded-full object-cover border border-violet-500/30 bg-violet-500/10"
                    onError={(e) => {
                      e.currentTarget.style.display = "none";
                    }}
                  />
                ) : (
                  <span className="avatar avatar-sm">{initial}</span>
                )}

                {user?.planId && user.planId !== "FREE" && (
                  <span
                    className={`absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full flex items-center justify-center bg-gradient-to-br ${
                      user.planId === "PRO"
                        ? "from-amber-400 to-pink-500"
                        : "from-violet-500 to-purple-500"
                    } border border-[#100b24]`}
                    title={user.planId}
                  >
                    <Crown size={9} className="text-white" />
                  </span>
                )}
              </div>

              <span className="hidden sm:inline max-w-[100px] truncate">
                {user?.displayName || user?.username}
              </span>

              <ChevronDown size={14} />
            </button>

            {menuOpen && (
              <div
                className="absolute right-0 top-[calc(100%+8px)] min-w-[200px] glass-card py-2"
                data-testid="user-menu"
              >
                <div className="px-4 py-2 border-b border-purple-500/10 mb-1">
                  <div className="text-sm font-semibold truncate">
                    {user?.displayName}
                  </div>

                  <div className="text-xs text-[var(--text-muted)] truncate">
                    @{user?.username}
                  </div>

                  {user?.planId && (
                    <div className="mt-1 inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-violet-500/15 border border-violet-500/30 text-[var(--violet-soft)]">
                      {user.planId === "PRO" ? (
                        <Crown size={10} />
                      ) : (
                        <Sparkles size={10} />
                      )}
                      {user.planId}
                    </div>
                  )}
                </div>

                <button
                  className="w-full text-left px-4 py-2 text-sm hover:bg-purple-500/10 flex items-center gap-2"
                  onClick={() => {
                    setMenuOpen(false);
                    nav("/settings");
                  }}
                  data-testid="menu-settings"
                >
                  <Settings size={14} /> Settings
                </button>

                <button
                  className="w-full text-left px-4 py-2 text-sm hover:bg-purple-500/10 flex items-center gap-2"
                  onClick={() => {
                    setMenuOpen(false);
                    nav("/pricing");
                  }}
                  data-testid="menu-pricing"
                >
                  <Sparkles size={14} /> Pricing & plans
                </button>

                <button
                  className="w-full text-left px-4 py-2 text-sm hover:bg-purple-500/10 flex items-center gap-2 text-pink-300"
                  onClick={async () => {
                    setMenuOpen(false);
                    await logout();
                    nav("/login");
                  }}
                  data-testid="menu-logout"
                >
                  <LogOut size={14} /> Sign out
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
