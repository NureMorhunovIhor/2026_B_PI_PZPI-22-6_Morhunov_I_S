import React, { useEffect, useRef, useState } from "react";
import { Mic, MicOff, PhoneOff } from "lucide-react";
import { Client } from "@stomp/stompjs";
import SockJS from "sockjs-client";
import { useAuth } from "../AuthContext";

const API_ORIGIN = "http://localhost:8080";

const ICE_SERVERS = {
  iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
};

export default function VoiceChat({ roomCode }) {
  const { user } = useAuth();

  const [joined, setJoined] = useState(false);
  const [muted, setMuted] = useState(false);
  const [connected, setConnected] = useState(false);
  const [error, setError] = useState("");

  const stompRef = useRef(null);
  const localStreamRef = useRef(null);
  const peersRef = useRef({});
  const audioRefs = useRef({});
  const joinedRef = useRef(false);

  useEffect(() => {
    if (!roomCode || !user?.id) return;

    const socket = new SockJS(`${API_ORIGIN}/ws`);

    const stomp = new Client({
      webSocketFactory: () => socket,
      reconnectDelay: 3000,
      connectHeaders: {
        Authorization: `Bearer ${localStorage.getItem("accessToken") || ""}`,
      },
      onConnect: () => {
        console.log("VOICE WS CONNECTED");
        setConnected(true);

        stomp.subscribe(`/topic/rooms/${roomCode}/voice`, async (frame) => {
          const payload = JSON.parse(frame.body);

          console.log("VOICE RAW EVENT:", payload);

          if (String(payload.senderUserId) === String(user.id)) return;

          if (
            payload.targetUserId &&
            String(payload.targetUserId) !== String(user.id)
          ) {
            return;
          }

          await handleVoiceEvent(payload);
        });
      },
      onDisconnect: () => {
        console.log("VOICE WS DISCONNECTED");
        setConnected(false);
      },
      onStompError: (frame) => {
        console.error("VOICE STOMP ERROR:", frame);
        setConnected(false);
      },
      onWebSocketError: (err) => {
        console.error("VOICE WS ERROR:", err);
        setConnected(false);
      },
    });

    stomp.activate();
    stompRef.current = stomp;

    return () => {
      leaveVoice(false);
      stomp.deactivate();
      stompRef.current = null;
      setConnected(false);
    };
  }, [roomCode, user?.id]);

  const sendSignal = (type, data = null, targetUserId = null) => {
    const stomp = stompRef.current;

    if (!stomp || !stomp.connected) {
      console.warn("VOICE SIGNAL NOT SENT, WS NOT CONNECTED:", type);
      setError("Voice WebSocket is not connected.");
      return;
    }

    
    const body = {
      roomCode,
      targetUserId,
      senderUserId: user?.id || user?.userId,
      type,
      data,
    };

    console.log("VOICE SEND:", body);

    stomp.publish({
      destination: "/app/voice.signal",
      body: JSON.stringify(body),
    });
  };

  const joinVoice = async () => {
    try {
      setError("");

      const stream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: false,
      });

      localStreamRef.current = stream;
      joinedRef.current = true;
      setJoined(true);

      console.log("VOICE JOINED:", user?.id);

      sendSignal("voice.user-joined", null);
    } catch (err) {
      console.error("MIC ERROR:", err);
      setError("Microphone access denied or unavailable.");
    }
  };

  const leaveVoice = (notify = true) => {
    Object.values(peersRef.current).forEach((pc) => pc.close());
    peersRef.current = {};

    Object.values(audioRefs.current).forEach((audio) => {
      if (audio) audio.srcObject = null;
    });
    audioRefs.current = {};

    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => track.stop());
      localStreamRef.current = null;
    }

    joinedRef.current = false;
    setJoined(false);
    setMuted(false);

    if (notify) {
      sendSignal("voice.user-left", null);
    }
  };

  const toggleMute = () => {
    if (!localStreamRef.current) return;

    const nextMuted = !muted;

    localStreamRef.current.getAudioTracks().forEach((track) => {
      track.enabled = !nextMuted;
    });

    setMuted(nextMuted);
  };

  const getOrCreatePeer = async (remoteUserId) => {
    if (peersRef.current[remoteUserId]) {
      return peersRef.current[remoteUserId];
    }

    const pc = new RTCPeerConnection(ICE_SERVERS);

    pc.onconnectionstatechange = () => {
      console.log("VOICE CONNECTION STATE with", remoteUserId, pc.connectionState);
    };

    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => {
        pc.addTrack(track, localStreamRef.current);
      });
    }

    pc.onicecandidate = (event) => {
      if (event.candidate) {
        sendSignal("voice.ice-candidate", event.candidate, remoteUserId);
      }
    };

    pc.ontrack = (event) => {
      console.log("REMOTE AUDIO TRACK RECEIVED FROM:", remoteUserId, event.streams);

      let audio = audioRefs.current[remoteUserId];

      if (!audio) {
        audio = new Audio();
        audio.autoplay = true;
        audio.playsInline = true;
        audioRefs.current[remoteUserId] = audio;
      }

      audio.srcObject = event.streams[0];

      audio.play().catch((err) => {
        console.warn("Audio autoplay blocked:", err);
      });
    };

    peersRef.current[remoteUserId] = pc;

    return pc;
  };

  const handleVoiceEvent = async (payload) => {
    console.log("VOICE EVENT RECEIVED:", payload, "joined:", joinedRef.current);

    const remoteUserId = payload.senderUserId;

    if (!remoteUserId) return;

    if (payload.type === "voice.user-joined") {
      if (!joinedRef.current) return;

      const pc = await getOrCreatePeer(remoteUserId);

      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);

      sendSignal("voice.offer", offer, remoteUserId);
      return;
    }

    if (!joinedRef.current) return;

    if (payload.type === "voice.offer") {
      const pc = await getOrCreatePeer(remoteUserId);

      await pc.setRemoteDescription(new RTCSessionDescription(payload.data));

      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);

      sendSignal("voice.answer", answer, remoteUserId);
      return;
    }

    if (payload.type === "voice.answer") {
      const pc = await getOrCreatePeer(remoteUserId);

      await pc.setRemoteDescription(new RTCSessionDescription(payload.data));
      return;
    }

    if (payload.type === "voice.ice-candidate") {
      const pc = await getOrCreatePeer(remoteUserId);

      await pc.addIceCandidate(new RTCIceCandidate(payload.data));
      return;
    }

    if (payload.type === "voice.user-left") {
      const pc = peersRef.current[remoteUserId];

      if (pc) {
        pc.close();
        delete peersRef.current[remoteUserId];
      }

      const audio = audioRefs.current[remoteUserId];

      if (audio) {
        audio.srcObject = null;
        delete audioRefs.current[remoteUserId];
      }
    }
  };

  return (
    <div className="glass-card p-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h3 className="font-serif text-lg text-white">Voice chat</h3>
          <p className="text-xs text-[var(--text-muted)]">
            {connected
              ? joined
                ? "Voice chat connected."
                : "Talk with people in this room."
              : "Connecting voice service..."}
          </p>
        </div>

        {!joined ? (
          <button
            type="button"
            onClick={joinVoice}
            disabled={!connected}
            className="btn-primary inline-flex items-center gap-2 !py-2 !px-3 text-sm disabled:opacity-60"
          >
            <Mic size={15} /> Join
          </button>
        ) : (
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={toggleMute}
              className="btn-ghost !py-2 !px-3"
              title={muted ? "Unmute" : "Mute"}
            >
              {muted ? <MicOff size={15} /> : <Mic size={15} />}
            </button>

            <button
              type="button"
              onClick={() => leaveVoice(true)}
              className="btn-ghost !py-2 !px-3 text-pink-200"
              title="Leave voice chat"
            >
              <PhoneOff size={15} />
            </button>
          </div>
        )}
      </div>

      {joined && (
        <div className="mt-3 text-xs text-emerald-300">
          Voice chat connected
        </div>
      )}

      {error && (
        <div className="mt-3 text-xs text-pink-300">
          {error}
        </div>
      )}
    </div>
  );
}