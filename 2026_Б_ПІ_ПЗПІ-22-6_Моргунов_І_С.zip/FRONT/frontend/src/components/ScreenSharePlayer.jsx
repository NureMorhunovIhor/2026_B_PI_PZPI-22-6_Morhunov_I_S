import React, { useEffect, useRef, useState } from "react";
import { MonitorUp, MonitorX, Radio } from "lucide-react";
import { Client } from "@stomp/stompjs";
import SockJS from "sockjs-client";
import { useAuth } from "../AuthContext";

const API_ORIGIN = "http://localhost:8080";

const ICE_SERVERS = {
  iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
};

export default function ScreenSharePlayer({
  roomCode,
  startSignal = 0,
  onActiveChange,
}) {
  const { user } = useAuth();

  const [connected, setConnected] = useState(false);
  const [active, setActive] = useState(false);
  const [sharing, setSharing] = useState(false);
  const [screenOwnerUserId, setScreenOwnerUserId] = useState(null);
  const [screenOwnerName, setScreenOwnerName] = useState("");
  const [error, setError] = useState("");

  const stompRef = useRef(null);
  const screenStreamRef = useRef(null);
  const peersRef = useRef({});
  const remoteVideoRef = useRef(null);
  const localVideoRef = useRef(null);

  const sharingRef = useRef(false);
  const ownerUserIdRef = useRef(null);

  const myUserId = user?.id || user?.userId;

  const isScreenOwner =
    String(screenOwnerUserId || "") === String(myUserId || "");

  const setScreenActive = (value) => {
    setActive(value);
    onActiveChange?.(value);
  };

  useEffect(() => {
    if (!roomCode || !myUserId) return;

    const socket = new SockJS(`${API_ORIGIN}/ws`);

    const stomp = new Client({
      webSocketFactory: () => socket,
      reconnectDelay: 3000,
      connectHeaders: {
        Authorization: `Bearer ${localStorage.getItem("accessToken") || ""}`,
      },
      onConnect: () => {
        console.log("SCREEN WS CONNECTED");
        setConnected(true);

        stomp.subscribe(`/topic/rooms/${roomCode}/screen`, async (frame) => {
          const payload = JSON.parse(frame.body);

          console.log("SCREEN RAW EVENT:", payload);

          if (String(payload.senderUserId) === String(myUserId)) {
            return;
          }

          if (
            payload.targetUserId &&
            String(payload.targetUserId) !== String(myUserId)
          ) {
            return;
          }

          await handleScreenEvent(payload);
        });

        setTimeout(() => {
          sendSignal("screen.viewer-ready", null);
        }, 300);
      },
      onDisconnect: () => {
        console.log("SCREEN WS DISCONNECTED");
        setConnected(false);
      },
      onStompError: (frame) => {
        console.error("SCREEN STOMP ERROR:", frame);
        setConnected(false);
      },
      onWebSocketError: (err) => {
        console.error("SCREEN WS ERROR:", err);
        setConnected(false);
      },
    });

    stomp.activate();
    stompRef.current = stomp;

    return () => {
      stopScreenShare(false);
      closeAllPeers();

      stomp.deactivate();
      stompRef.current = null;
      setConnected(false);
    };
  }, [roomCode, myUserId]);

  useEffect(() => {
    if (startSignal > 0) {
      startScreenShare();
    }
  }, [startSignal]);

  const sendSignal = (type, data = null, targetUserId = null) => {
    const stomp = stompRef.current;

    if (!stomp || !stomp.connected) {
      console.warn("SCREEN SIGNAL NOT SENT, WS NOT CONNECTED:", type);
      setError("Screen WebSocket is not connected.");
      return;
    }

    const body = {
      roomCode,
      senderUserId: myUserId,
      targetUserId,
      type,
      data,
    };

    console.log("SCREEN SEND:", body);

    stomp.publish({
      destination: "/app/screen.signal",
      body: JSON.stringify(body),
    });
  };

  const startScreenShare = async () => {
    if (!connected) {
      setError("Screen service is not connected yet.");
      return;
    }

    if (active && !isScreenOwner) {
      setError("Another user is already sharing their screen.");
      return;
    }

    try {
      setError("");

      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: true,
      });

      screenStreamRef.current = stream;
      sharingRef.current = true;
      ownerUserIdRef.current = myUserId;

      setSharing(true);
      setScreenOwnerUserId(myUserId);
      setScreenOwnerName(user?.username || user?.displayName || user?.email || "me");
      setScreenActive(true);

      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream;
      }

      const videoTrack = stream.getVideoTracks()[0];

      if (videoTrack) {
        videoTrack.onended = () => {
          stopScreenShare(true);
        };
      }

      sendSignal("screen.share-started", {
        ownerUserId: myUserId,
        ownerUsername: user?.username || user?.displayName || user?.email,
      });
    } catch (err) {
      console.error("SCREEN SHARE ERROR:", err);
      setError("Screen sharing was cancelled or unavailable.");
    }
  };

  const stopScreenShare = (notify = true) => {
    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach((track) => track.stop());
      screenStreamRef.current = null;
    }

    if (localVideoRef.current) {
      localVideoRef.current.srcObject = null;
    }

    closeAllPeers();

    sharingRef.current = false;
    ownerUserIdRef.current = null;

    setSharing(false);
    setScreenOwnerUserId(null);
    setScreenOwnerName("");
    setScreenActive(false);

    if (notify) {
      sendSignal("screen.share-stopped", null);
    }
  };

  const closeAllPeers = () => {
    Object.values(peersRef.current).forEach((pc) => pc.close());
    peersRef.current = {};

    if (remoteVideoRef.current) {
      remoteVideoRef.current.srcObject = null;
    }
  };

  const getOrCreatePeer = async (remoteUserId) => {
    if (peersRef.current[remoteUserId]) {
      return peersRef.current[remoteUserId];
    }

    const pc = new RTCPeerConnection(ICE_SERVERS);

    pc.onconnectionstatechange = () => {
      console.log(
        "SCREEN CONNECTION STATE with",
        remoteUserId,
        pc.connectionState
      );
    };

    pc.onicecandidate = (event) => {
      if (event.candidate) {
        sendSignal("screen.ice-candidate", event.candidate, Number(remoteUserId));
      }
    };

    pc.ontrack = (event) => {
      console.log(
        "REMOTE SCREEN TRACK RECEIVED FROM:",
        remoteUserId,
        event.track.kind,
        event.streams
      );

      const stream = event.streams[0];

      setScreenOwnerUserId(remoteUserId);
      ownerUserIdRef.current = remoteUserId;
      setScreenActive(true);

      if (remoteVideoRef.current) {
        remoteVideoRef.current.srcObject = stream;

        remoteVideoRef.current.play().catch((err) => {
          console.warn("Remote screen autoplay blocked:", err);
        });
      }
    };

    if (sharingRef.current && screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach((track) => {
        pc.addTrack(track, screenStreamRef.current);
      });
    }

    peersRef.current[remoteUserId] = pc;

    return pc;
  };

  const createOfferForViewer = async (viewerUserId) => {
    if (!sharingRef.current || !screenStreamRef.current) return;

    const pc = await getOrCreatePeer(viewerUserId);

    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);

    sendSignal("screen.offer", offer, Number(viewerUserId));
  };

  const handleScreenEvent = async (payload) => {
    console.log("SCREEN EVENT RECEIVED:", payload);

    const remoteUserId = payload.senderUserId;

    if (!remoteUserId) return;

    if (payload.type === "screen.viewer-ready") {
      if (sharingRef.current) {
        await createOfferForViewer(remoteUserId);
      }

      return;
    }

    if (payload.type === "screen.share-started") {
      const ownerUserId = payload.data?.ownerUserId || remoteUserId;
      const ownerUsername =
        payload.data?.ownerUsername || `user ${ownerUserId}`;

      setScreenOwnerUserId(ownerUserId);
      ownerUserIdRef.current = ownerUserId;
      setScreenOwnerName(ownerUsername);
      setScreenActive(true);

      sendSignal("screen.viewer-ready", null, Number(ownerUserId));

      return;
    }

    if (payload.type === "screen.offer") {
      const pc = await getOrCreatePeer(remoteUserId);

      setScreenOwnerUserId(remoteUserId);
      ownerUserIdRef.current = remoteUserId;
      setScreenActive(true);

      await pc.setRemoteDescription(new RTCSessionDescription(payload.data));

      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);

      sendSignal("screen.answer", answer, Number(remoteUserId));

      return;
    }

    if (payload.type === "screen.answer") {
      const pc = await getOrCreatePeer(remoteUserId);

      await pc.setRemoteDescription(new RTCSessionDescription(payload.data));

      return;
    }

    if (payload.type === "screen.ice-candidate") {
      const pc = await getOrCreatePeer(remoteUserId);

      await pc.addIceCandidate(new RTCIceCandidate(payload.data));

      return;
    }

    if (payload.type === "screen.share-stopped") {
      const ownerId = ownerUserIdRef.current;

      if (String(ownerId || "") === String(remoteUserId || "")) {
        closeAllPeers();

        ownerUserIdRef.current = null;

        setScreenOwnerUserId(null);
        setScreenOwnerName("");
        setScreenActive(false);
      }
    }
  };

  if (!active) {
    return null;
  }

  return (
    <div className="glass-card overflow-hidden">
      <div className="flex items-center justify-between gap-3 p-4 border-b border-violet-500/15">
        <div>
          <h3 className="font-serif text-xl text-white flex items-center gap-2">
            <Radio size={17} className="text-[var(--violet-soft)]" />
            Screen sharing
          </h3>

          <p className="text-xs text-[var(--text-muted)]">
            {isScreenOwner
              ? "You are sharing your screen."
              : screenOwnerName
                ? `Live screen from @${screenOwnerName}`
                : "Live screen sharing is active."}
          </p>

          {error && (
            <p className="text-xs text-pink-300 mt-1">
              {error}
            </p>
          )}
        </div>

        {isScreenOwner && (
          <button
            type="button"
            onClick={() => stopScreenShare(true)}
            className="btn-ghost !py-2 !px-3 text-pink-200 inline-flex items-center gap-2"
          >
            <MonitorX size={15} />
            Stop sharing
          </button>
        )}

        {!isScreenOwner && (
          <div className="text-[11px] text-[var(--text-muted)] max-w-[180px] text-right">
            Only the broadcaster can stop this stream.
          </div>
        )}
      </div>

      <div className="bg-black">
        {isScreenOwner ? (
          <video
            ref={localVideoRef}
            autoPlay
            muted
            playsInline
            className="w-full max-h-[620px] bg-black"
          />
        ) : (
          <video
            ref={remoteVideoRef}
            autoPlay
            playsInline
            controls
            className="w-full max-h-[620px] bg-black"
          />
        )}
      </div>
    </div>
  );
}