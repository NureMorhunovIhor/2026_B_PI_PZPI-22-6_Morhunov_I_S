import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./AuthContext";
import Login from "./pages/Login";
import Register from "./pages/Register";
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";
import Home from "./pages/Home";
import Rooms from "./pages/Rooms";
import CreateRoom from "./pages/CreateRoom";
import Room from "./pages/Room";
import Friends from "./pages/Friends";
import Notifications from "./pages/Notifications";
import Settings from "./pages/Settings";
import OAuthSuccess from "./pages/OAuthSuccess";
import Pricing from "./pages/Pricing";
import PricingSuccess from "./pages/PricingSuccess";
import Messages from "./pages/Messages";
import "./App.css";

function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) {
    return (
      <div className="relative min-h-screen flex items-center justify-center">
        <div className="starfield" />
        <div className="relative text-[var(--text-secondary)] font-serif tracking-widest">Loading...</div>
      </div>
    );
  }
  if (!user) return <Navigate to="/login" replace />;
  return children;
}

function PublicOnly({ children }) {
  const { user, loading } = useAuth();
  if (loading) return null;
  if (user) return <Navigate to="/" replace />;
  return children;
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<PublicOnly><Login /></PublicOnly>} />
      <Route path="/register" element={<PublicOnly><Register /></PublicOnly>} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/" element={<ProtectedRoute><Home /></ProtectedRoute>} />
      <Route path="/rooms" element={<ProtectedRoute><Rooms /></ProtectedRoute>} />
      <Route path="/rooms/create" element={<ProtectedRoute><CreateRoom /></ProtectedRoute>} />
      <Route path="/rooms/:code" element={<ProtectedRoute><Room /></ProtectedRoute>} />
      <Route path="/friends" element={<ProtectedRoute><Friends /></ProtectedRoute>} />
      <Route path="/notifications" element={<ProtectedRoute><Notifications /></ProtectedRoute>} />
      <Route path="/settings" element={<ProtectedRoute><Settings /></ProtectedRoute>} />
      <Route path="/oauth/success" element={<OAuthSuccess />} />
      <Route path="/pricing" element={<Pricing />} />
      <Route path="/pricing/success" element={<PricingSuccess />} />
      <Route path="/pricing/cancel" element={<Pricing />} />
      <Route path="/messages" element={<Messages />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
