import axios from "axios";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

const client = axios.create({ baseURL: API });

client.interceptors.request.use((config) => {
  const token = localStorage.getItem("wt_access_token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

let isRefreshing = false;
let pendingQueue = [];

client.interceptors.response.use(
  (res) => res,
  async (error) => {
    const original = error.config;
    if (error.response?.status === 401 && !original._retry) {
      const refresh = localStorage.getItem("wt_refresh_token");
      if (!refresh) {
        localStorage.removeItem("wt_access_token");
        localStorage.removeItem("wt_refresh_token");
        return Promise.reject(error);
      }
      if (isRefreshing) {
        return new Promise((resolve, reject) => {
          pendingQueue.push({ resolve, reject, original });
        });
      }
      original._retry = true;
      isRefreshing = true;
      try {
        const { data } = await axios.post(`${API}/auth/refresh`, { refreshToken: refresh });
        localStorage.setItem("wt_access_token", data.accessToken);
        localStorage.setItem("wt_refresh_token", data.refreshToken);
        pendingQueue.forEach((p) => {
          p.original.headers.Authorization = `Bearer ${data.accessToken}`;
          p.resolve(client(p.original));
        });
        pendingQueue = [];
        original.headers.Authorization = `Bearer ${data.accessToken}`;
        return client(original);
      } catch (err) {
        pendingQueue.forEach((p) => p.reject(err));
        pendingQueue = [];
        localStorage.removeItem("wt_access_token");
        localStorage.removeItem("wt_refresh_token");
        window.location.href = "/login";
        return Promise.reject(err);
      } finally {
        isRefreshing = false;
      }
    }
    return Promise.reject(error);
  }
);

export function formatApiError(err) {
  const d = err?.response?.data?.detail;
  if (d == null) return err?.message || "Something went wrong";
  if (typeof d === "string") return d;
  if (Array.isArray(d)) return d.map((e) => (e?.msg ? e.msg : JSON.stringify(e))).join(" ");
  if (d?.msg) return d.msg;
  return String(d);
}

export default client;
