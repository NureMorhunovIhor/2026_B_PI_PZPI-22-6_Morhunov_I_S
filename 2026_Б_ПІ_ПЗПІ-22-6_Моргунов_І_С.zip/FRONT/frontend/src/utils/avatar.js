const API_ORIGIN =
  process.env.REACT_APP_API_ORIGIN || "http://localhost:8080";

export const resolveAvatarUrl = (url) => {
  if (!url) return "";

  if (url.startsWith("http://") || url.startsWith("https://")) {
    return url;
  }

  if (url.startsWith("/")) {
    return `${API_ORIGIN}${url}`;
  }

  return `${API_ORIGIN}/${url}`;
};