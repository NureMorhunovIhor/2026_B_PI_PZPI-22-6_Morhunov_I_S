import { useEffect, useRef, useState, useCallback } from "react";
import SockJS from "sockjs-client";
import { Client } from "@stomp/stompjs";

export default function useRoomSocket(roomCode, onMessage) {
  const stompRef = useRef(null);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    if (!roomCode) return;

    const token = localStorage.getItem("wt_access_token");
    const baseUrl = process.env.REACT_APP_BACKEND_URL || "http://localhost:8080";

    const stompClient = new Client({
      webSocketFactory: () => new SockJS(`${baseUrl}/ws`),
      reconnectDelay: 5000,
      connectHeaders: token
        ? {
            Authorization: `Bearer ${token}`,
          }
        : {},
      debug: () => {},

      onConnect: () => {
        setConnected(true);

        onMessage?.({
          type: "hello",
        });

        stompClient.subscribe(`/topic/rooms/${roomCode}/chat`, (message) => {
  try {
    const data = JSON.parse(message.body);

    onMessage?.({
      type: data.type || data.eventType || "chat.new",
      data,
    });
  } catch (e) {
    console.error("Failed to parse chat message", e);
  }
});

        stompClient.subscribe(`/topic/rooms/${roomCode}/playback`, (message) => {
          try {
            const data = JSON.parse(message.body);

            onMessage?.({
              type: "playback",
              data,
            });
          } catch (e) {
            console.error("Failed to parse playback message", e);
          }
        });
        stompClient.subscribe(`/topic/rooms/${roomCode}/events`, (message) => {
  try {
    const data = JSON.parse(message.body);

    onMessage?.({
      type: data.type,
      data: data.data || {},
    });
  } catch (e) {
    console.error("Failed to parse room event", e);
  }
});
      },

      onDisconnect: () => {
        setConnected(false);
      },

      onWebSocketClose: () => {
        setConnected(false);
      },

      onStompError: (frame) => {
        console.error("STOMP error:", frame.headers?.message, frame.body);
      },

      onWebSocketError: (error) => {
        console.error("WebSocket error:", error);
      },
    });

    stompClient.activate();
    stompRef.current = stompClient;

    return () => {
      setConnected(false);
      stompClient.deactivate();
      stompRef.current = null;
    };
  }, [roomCode, onMessage]);

  const sendChatMessage = useCallback(
    (content, replyToMessageId = null) => {
      if (!stompRef.current?.connected) {
        console.warn("STOMP is not connected");
        return false;
      }

      stompRef.current.publish({
        destination: "/app/chat.send",
        body: JSON.stringify({
          roomCode,
          content,
          replyToMessageId,
        }),
      });

      return true;
    },
    [roomCode],
  );

  const sendPlaybackCommand = useCallback(
    (payload) => {
      if (!stompRef.current?.connected) {
        console.warn("STOMP is not connected");
        return false;
      }

      stompRef.current.publish({
        destination: "/app/playback.command",
        body: JSON.stringify({
          roomCode,
          ...payload,
        }),
      });

      return true;
    },
    [roomCode],
  );

  return {
    connected,
    sendChatMessage,
    sendPlaybackCommand,
  };
}