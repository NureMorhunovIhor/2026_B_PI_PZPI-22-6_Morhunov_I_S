import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowRight, Globe, Lock, Plus, Search, Users } from "lucide-react";
import Navbar from "../components/Navbar";
import client, { formatApiError } from "../api";

export default function Rooms() {
  const nav = useNavigate();
  const [tab, setTab] = useState("public");
  const [rooms, setRooms] = useState([]);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [joinCode, setJoinCode] = useState("");
  const [joinError, setJoinError] = useState("");

  const load = async () => {
  setLoading(true);
  try {
    const url = tab === "public" ? "/rooms/public" : "/rooms/my";
    console.log("Loading rooms:", url);

    const { data } = await client.get(url);

    console.log("Rooms response:", data);
    setRooms(data);
  } catch (err) {
    console.error("Rooms load failed:", err?.response?.status, err?.response?.data || err);
    setRooms([]);
  } finally {
    setLoading(false);
  }
};

  useEffect(() => {
    load();
  }, [tab]);

  const doSearch = async (e) => {
    e.preventDefault();
    if (!query.trim()) {
      load();
      return;
    }
    setLoading(true);
    try {
      const { data } = await client.get(`/rooms/search?query=${encodeURIComponent(query)}`);
      setRooms(data);
    } finally {
      setLoading(false);
    }
  };

  const joinByCode = async (e) => {
    e.preventDefault();
    const code = joinCode.trim().toUpperCase();
    if (!code) return;
    setJoinError("");
    try {
      await client.post(`/rooms/${code}/join`);
      nav(`/rooms/${code}`);
    } catch (err) {
      setJoinError(formatApiError(err));
    }
  };

  return (
    <div className="relative min-h-screen">
      <div className="starfield" />
      <div className="relative z-10">
        <Navbar />
        <div className="max-w-7xl mx-auto px-6 py-10">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10 fade-up">
            <div>
              <h1 className="font-serif text-4xl md:text-5xl tracking-wide text-white mb-2">ROOMS</h1>
              <p className="text-[var(--text-secondary)]">Browse public rooms, or hop back into yours.</p>
            </div>
            <Link to="/rooms/create" className="btn-primary inline-flex items-center gap-2 self-start" data-testid="rooms-create-btn">
              <Plus size={18} /> Create Room
            </Link>
          </div>

          {/* Join by code */}
          <div className="glass-card p-5 mb-8 flex flex-col md:flex-row items-start md:items-center gap-3 fade-up delay-1">
            <div className="font-serif text-sm tracking-widest text-[var(--text-secondary)] whitespace-nowrap">
              JOIN BY CODE
            </div>
            <form onSubmit={joinByCode} className="flex-1 flex flex-col sm:flex-row gap-3 w-full">
              <input
                className="input-field-dark flex-1"
                placeholder="e.g. AB12CD34"
                value={joinCode}
                onChange={(e) => setJoinCode(e.target.value)}
                data-testid="rooms-join-code-input"
              />
              <button className="btn-primary whitespace-nowrap" type="submit" data-testid="rooms-join-code-btn">
                Join Room
              </button>
            </form>
          </div>
          {joinError && <p className="text-sm text-pink-300 mb-4">{joinError}</p>}

          {/* Tabs + search */}
          <div className="flex flex-col md:flex-row gap-4 items-stretch md:items-center justify-between mb-6">
            <div className="inline-flex p-1 glass-card rounded-full self-start">
              {[
                { id: "public", label: "Public" },
                { id: "my", label: "My Rooms" },
              ].map((t) => (
                <button
                  key={t.id}
                  onClick={() => {
                    setTab(t.id);
                    setQuery("");
                  }}
                  className={`px-6 py-2 rounded-full text-sm font-semibold transition-all ${
                    tab === t.id
                      ? "bg-gradient-to-r from-violet-500 to-purple-500 text-white shadow-lg shadow-violet-500/30"
                      : "text-[var(--text-secondary)] hover:text-white"
                  }`}
                  data-testid={`tab-${t.id}`}
                >
                  {t.label}
                </button>
              ))}
            </div>

            {tab === "public" && (
              <form onSubmit={doSearch} className="flex gap-2 w-full md:w-auto">
                <div className="relative flex-1">
                  <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
                  <input
                    className="input-field-dark pl-11"
                    placeholder="Search rooms..."
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    data-testid="rooms-search-input"
                  />
                </div>
                <button type="submit" className="btn-ghost" data-testid="rooms-search-btn">Search</button>
              </form>
            )}
          </div>

          {loading ? (
            <div className="text-center text-[var(--text-secondary)] py-20">Loading rooms...</div>
          ) : rooms.length === 0 ? (
            <div className="glass-card p-12 text-center text-[var(--text-secondary)]" data-testid="rooms-empty">
              {tab === "public" ? "No public rooms yet." : "You haven't joined any rooms yet."}
              <div className="mt-4">
                <Link to="/rooms/create" className="text-[var(--violet-bright)] font-semibold">Create your first room</Link>
              </div>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
              {rooms.map((r) => (
                <div key={r.roomCode} className="glass-card glass-card-hover p-5" data-testid={`room-card-${r.roomCode}`}>
                  <div className="flex items-center justify-between mb-4">
                    <span className={`badge ${r.roomType === "PUBLIC" ? "badge-public" : r.roomType === "FRIENDS_ONLY" ? "badge-friends" : "badge-private"}`}>
                      {r.roomType === "PUBLIC" ? <Globe size={13} /> : <Lock size={13} />}
                      {r.roomType}
                    </span>
                    <span className="flex items-center gap-1.5 text-xs text-[var(--text-secondary)]">
                      <Users size={13} /> {r.participantsCount || 0}/{r.maxParticipants}
                    </span>
                  </div>
                  <h3 className="font-serif text-xl tracking-wide text-white mb-1 line-clamp-1">{r.name}</h3>
                  <p className="text-sm text-[var(--text-secondary)] line-clamp-2 min-h-[40px]">
                    {r.description || "A room to watch together."}
                  </p>
                  <div className="shimmer-divider my-4" />
                  <div className="flex items-center justify-between">
                    <code className="text-xs text-[var(--text-muted)] tracking-widest">{r.roomCode}</code>
                    <Link
                      to={`/rooms/${r.roomCode}`}
                      className="inline-flex items-center gap-1 text-[var(--violet-bright)] font-semibold text-sm hover:text-pink-400"
                    >
                      Join <ArrowRight size={14} />
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
