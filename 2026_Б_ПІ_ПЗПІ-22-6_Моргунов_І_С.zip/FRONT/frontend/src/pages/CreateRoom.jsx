import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Globe, Lock, Sparkles, Users } from "lucide-react";
import Navbar from "../components/Navbar";
import client, { formatApiError } from "../api";

export default function CreateRoom() {
  const nav = useNavigate();
  const [form, setForm] = useState({
    name: "",
    description: "",
    roomType: "PUBLIC",
    accessMode: "OPEN",
    maxParticipants: 10,
  });
  const [error, setError] = useState("");
  const [planLimitHit, setPlanLimitHit] = useState(false);
  const [loading, setLoading] = useState(false);

  const handle = (field) => (e) =>
    setForm((f) => ({ ...f, [field]: field === "maxParticipants" ? Number(e.target.value) : e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    setPlanLimitHit(false);
    setLoading(true);
    try {
      const { data } = await client.post("/rooms", form);
      nav(`/rooms/${data.roomCode}`);
    } catch (err) {
      setError(formatApiError(err));
      if (err?.response?.status === 402) {
        setPlanLimitHit(true);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative min-h-screen">
      <div className="starfield" />
      <div className="relative z-10">
        <Navbar />
        <div className="max-w-3xl mx-auto px-6 py-10">
          <div className="fade-up mb-8">
            <h1 className="font-serif text-4xl md:text-5xl tracking-wide text-white mb-2">CREATE ROOM</h1>
            <p className="text-[var(--text-secondary)]">Set up a cinema for your friends.</p>
          </div>

          <form onSubmit={submit} className="glass-card p-8 space-y-6 fade-up delay-1">
            <div>
              <label className="label">Room Name</label>
              <input
                className="input-field-dark"
                placeholder="Movie Night"
                value={form.name}
                onChange={handle("name")}
                required
                minLength={1}
                data-testid="create-room-name"
              />
            </div>
            <div>
              <label className="label">Description</label>
              <textarea
                className="input-field-dark min-h-[100px] resize-y"
                placeholder="What are we watching tonight?"
                value={form.description}
                onChange={handle("description")}
                data-testid="create-room-description"
              />
            </div>

            <div>
              <label className="label">Room Type</label>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { id: "PUBLIC", label: "Public", icon: Globe, desc: "Anyone can find & join" },
                  { id: "FRIENDS_ONLY", label: "Friends", icon: Users, desc: "Only your friends" },
                  { id: "PRIVATE", label: "Private", icon: Lock, desc: "Code / invite only" },
                ].map((t) => {
                  const Icon = t.icon;
                  const active = form.roomType === t.id;
                  return (
                    <button
                      type="button"
                      key={t.id}
                      onClick={() => setForm((f) => ({ ...f, roomType: t.id, accessMode: t.id === "PUBLIC" ? "OPEN" : t.id === "PRIVATE" ? "LINK_ONLY" : "INVITE_ONLY" }))}
                      className={`p-4 rounded-2xl border text-left transition-all ${
                        active
                          ? "border-violet-500 bg-violet-500/15"
                          : "border-violet-500/15 bg-violet-500/5 hover:border-violet-500/40"
                      }`}
                      data-testid={`type-${t.id}`}
                    >
                      <Icon size={18} className="mb-2 text-[var(--violet-soft)]" />
                      <div className="font-semibold text-white text-sm">{t.label}</div>
                      <div className="text-xs text-[var(--text-secondary)] mt-0.5">{t.desc}</div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="label">Max Participants ({form.maxParticipants})</label>
              <input
                type="range"
                min="2"
                max="100"
                value={form.maxParticipants}
                onChange={handle("maxParticipants")}
                className="w-full accent-violet-500"
                data-testid="create-room-max"
              />
              <div className="flex justify-between text-xs text-[var(--text-muted)] mt-1">
                <span>2</span>
                <span>100</span>
              </div>
            </div>

            {error && (
              <div
                className="text-sm text-pink-300 bg-pink-500/10 border border-pink-500/30 rounded-xl px-4 py-3"
                data-testid="create-error"
              >
                <div>{error}</div>

                {planLimitHit && (
                  <Link
                    to="/pricing"
                    className="mt-2 inline-flex items-center gap-1.5 text-[var(--violet-bright)] hover:text-pink-400 font-semibold"
                    data-testid="create-upgrade-cta"
                  >
                    <Sparkles size={13} /> See pricing & upgrade
                  </Link>
                )}
              </div>
            )}

            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => nav(-1)}
                className="btn-ghost flex-1"
                data-testid="create-cancel"
              >
                Cancel
              </button>
              <button type="submit" className="btn-primary flex-1" disabled={loading} data-testid="create-submit">
                {loading ? "Creating..." : "Create Room"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
