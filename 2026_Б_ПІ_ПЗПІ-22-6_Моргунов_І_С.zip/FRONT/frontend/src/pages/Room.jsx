import React, { useCallback, useEffect, useRef, useState } from "react";
import VoiceChat from "../components/VoiceChat";
import ScreenSharePlayer from "../components/ScreenSharePlayer";
import { useParams, useNavigate, Link } from "react-router-dom";
import {
  ArrowLeft,
  Copy,
  Crown,
  ListVideo,
  LogOut,
  MessageCircle,
  MoreVertical,
  MonitorUp,
  Plus,
  Send,
  Settings as SettingsIcon,
  Smile,
  Trash2,
  UserMinus,
  UserX,
  Users,
  VolumeX,
  Volume2,
  X,
  Youtube,
  Play as PlayIcon,
  Wifi,
  WifiOff,
} from "lucide-react";
import Navbar from "../components/Navbar";
import SyncedPlayer from "../components/SyncedPlayer";
import client, { formatApiError } from "../api";
import { useAuth } from "../AuthContext";
import { getYouTubeThumbnail } from "../utils/media";
import useRoomSocket from "../hooks/useRoomSocket";
import RoomSettingsDialog from "../components/RoomSettingsDialog";
import InviteFriendsDialog from "../components/InviteFriendsDialog";
import { resolveAvatarUrl } from "../utils/avatar";




const REACTION_EMOJIS = ["❤️", "😂", "😮", "🔥", "👍", "🎉"];

const PREMIUM_STICKERS = [
  { id: "premium_fire", label: "Fire", emoji: "🔥" },
  { id: "premium_popcorn", label: "Popcorn", emoji: "🍿" },
  { id: "premium_crown", label: "Crown", emoji: "👑" },
  { id: "premium_star", label: "Star", emoji: "⭐" },
  { id: "premium_rocket", label: "Rocket", emoji: "🚀" },
  { id: "premium_heart", label: "Heart", emoji: "💜" },
];

export default function Room() {
  const { code } = useParams();
  const nav = useNavigate();
  const { user } = useAuth();
  const [room, setRoom] = useState(null);
  const [participants, setParticipants] = useState([]);
  const [messages, setMessages] = useState([]);
  const [queue, setQueue] = useState([]);
  const [playback, setPlayback] = useState(null);
  const [chatInput, setChatInput] = useState("");
  const [sidebarTab, setSidebarTab] = useState("chat");
  const [addMediaOpen, setAddMediaOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [inviteOpen, setInviteOpen] = useState(false);
  const [copyMsg, setCopyMsg] = useState("");
  const [error, setError] = useState("");
  const [wsConnected, setWsConnected] = useState(false);
  const [reactionPickerFor, setReactionPickerFor] = useState(null);
  const [moderationFor, setModerationFor] = useState(null);
  const [billing, setBilling] = useState(null);
  const [stickerPickerOpen, setStickerPickerOpen] = useState(false);
  const [screenShareActive, setScreenShareActive] = useState(false);
  const [screenShareStartSignal, setScreenShareStartSignal] = useState(0);

  const chatEndRef = useRef(null);

  const normalizeIdentity = (value) =>
    String(value || "")
      .trim()
      .toLowerCase();

  const userEmailLocalPart = normalizeIdentity(user?.email).split("@")[0];

  const isSameUser = (p) => {
    if (!p || !user) return false;

    const participantValues = [
      p.userId,
      p.id,
      p.username,
      p.email,
      p.displayName,
    ].map(normalizeIdentity);

    const userValues = [
      user.id,
      user.userId,
      user.username,
      user.email,
      user.displayName,
      userEmailLocalPart,
    ].map(normalizeIdentity);

    return participantValues.some((value) => value && userValues.includes(value));
  };

const me = participants.find((p) => isSameUser(p));

const roomOwnerMatchesMe =
  String(room?.ownerId || "") === String(user?.id || "") ||
  String(room?.hostUserId || "") === String(user?.id || "") ||
  String(room?.createdByUserId || "") === String(user?.id || "") ||
  normalizeIdentity(room?.ownerUsername) === normalizeIdentity(user?.username) ||
  normalizeIdentity(room?.hostUsername) === normalizeIdentity(user?.username) ||
  normalizeIdentity(room?.createdByUsername) === normalizeIdentity(user?.username);

const isHost =
  String(me?.role || "").toUpperCase() === "HOST" ||
  roomOwnerMatchesMe;

const canControl = isHost || Boolean(me?.canControlPlayback);
const currentPlanId = String(
  billing?.currentPlan?.id ||
  billing?.plan?.id ||
  billing?.planId ||
  billing?.currentPlanId ||
  user?.planId ||
  "FREE"
).toUpperCase();

const hasPremium = currentPlanId !== "FREE";

const normalizePlaybackStatus = (value, fallback = "PAUSED") => {
  const v = String(value || "").toUpperCase();

  if (v === "PLAY" || v === "PLAYING") return "PLAYING";
  if (v === "PAUSE" || v === "PAUSED") return "PAUSED";
  if (v === "STOP" || v === "STOPPED") return "STOPPED";
  if (v === "END" || v === "ENDED") return "ENDED";
  if (v === "SEEK" || v === "SYNC") return fallback;

  return fallback;
};

const isActiveQueueItem = (item) => {
  const status = String(item?.status || "").toUpperCase();
  return status !== "REMOVED" && status !== "DELETED";
};

const makePlaybackFromQueueItem = (item, status = "PAUSED", current = null) => {
  if (!item) return null;

  const isSameMedia = current?.mediaId === item.mediaId;

  return {
    roomCode: code,
    mediaId: item.mediaId,
    title: item.mediaTitle || item.title || "Untitled video",
    sourceUrl: item.sourceUrl,
    playbackStatus: isSameMedia
      ? current?.playbackStatus || status
      : status,
    currentPositionSeconds: isSameMedia
      ? current?.currentPositionSeconds ?? 0
      : 0,
    playbackSpeed: isSameMedia
      ? current?.playbackSpeed ?? 1.0
      : 1.0,
    lastSyncedAt: isSameMedia
      ? current?.lastSyncedAt || new Date().toISOString()
      : new Date().toISOString(),
  };
};

  const loadAll = async () => {
  try {
    const [r, p] = await Promise.all([
  client.get(`/rooms/${code}`),
  client.get(`/rooms/${code}/participants`),
]);

let q = { data: [] };

try {
  q = await client.get(`/rooms/${code}/queue`);
} catch (e) {
  console.warn("Queue not loaded:", e);
}

    setRoom(r.data);
    setParticipants(p.data);
    const activeQueue = Array.isArray(q.data)
      ? q.data.filter(isActiveQueueItem)
      : [];

    setQueue(activeQueue);

    const playingItem = activeQueue.find(
      (item) => String(item.status || "").toUpperCase() === "PLAYING"
    );

    if (!playingItem) {
      setPlayback(null);
      return;
    }

    try {
      const pb = await client.get(`/playback/rooms/${code}/state`);

      setPlayback({
        ...pb.data,
        title: playingItem.mediaTitle || playingItem.title,
        sourceUrl: playingItem.sourceUrl,
        mediaId: playingItem.mediaId,
      });
    } catch {
  setPlayback((current) => {
    if (current?.mediaId === playingItem.mediaId) {
      return {
        ...current,
        title: current.title || playingItem.mediaTitle || playingItem.title,
        sourceUrl: current.sourceUrl || playingItem.sourceUrl,
      };
    }

    return makePlaybackFromQueueItem(playingItem, "PAUSED", current);
  });
}
  }  catch (err) {
  console.error("SEND STICKER ERROR STATUS:", err?.response?.status);
  console.error("SEND STICKER ERROR DATA:", err?.response?.data);
  console.error("SEND STICKER ERROR FULL:", err);

  setError(formatApiError(err));
}
};

  const loadMessages = async () => {
    try {
      const { data } = await client.get(`/chat/rooms/${code}/messages`);
      setMessages(data);
    } catch {
    }
  };

  const loadParticipants = useCallback(async () => {
  try {
    const { data } = await client.get(`/rooms/${code}/participants`);
    setParticipants(data);
  } catch {
  }
}, [code]);

  const loadQueue = useCallback(async () => {
  try {
    const { data } = await client.get(`/rooms/${code}/queue`);

    const activeQueue = Array.isArray(data)
      ? data.filter(isActiveQueueItem)
      : [];

    setQueue(activeQueue);
  } catch {
  }
}, [code]);
  const loadBilling = useCallback(async () => {
  try {
    const { data } = await client.get("/billing/me");
    console.log("BILLING ME:", data);
    setBilling(data);
  } catch (err) {
    console.warn("Billing not loaded:", err?.response?.data || err);
    setBilling(null);
  }
}, []);

  const loadPlayback = useCallback(async () => {
  try {
    const { data } = await client.get(`/playback/rooms/${code}/state`);

    setPlayback((current) => {
      const activeQueue = queue.filter(isActiveQueueItem);

      const playingItem =
        activeQueue.find(
          (item) => String(item.status || "").toUpperCase() === "PLAYING"
        ) ||
        activeQueue.find((item) => item.mediaId === data?.mediaId);

      if (playingItem) {
        return {
          ...current,
          ...data,
          title: playingItem.mediaTitle || playingItem.title,
          sourceUrl: playingItem.sourceUrl,
          mediaId: playingItem.mediaId,
          playbackStatus: data?.playbackStatus || current?.playbackStatus || "PAUSED",
        };
      }

      return {
        ...current,
        ...data,
      };
    });
  } catch {
    const playingItem = queue
      .filter(isActiveQueueItem)
      .find((item) => String(item.status || "").toUpperCase() === "PLAYING");
    if (playingItem) {
      setPlayback((current) => {
        if (current?.mediaId === playingItem.mediaId) {
          return {
            ...current,
            title: current.title || playingItem.mediaTitle || playingItem.title,
            sourceUrl: current.sourceUrl || playingItem.sourceUrl,
          };
        }

        return makePlaybackFromQueueItem(playingItem, "PAUSED", current);
      });
    }
  }
}, [code, queue]);
  useEffect(() => {
  (async () => {
    try {
      await client.post(`/rooms/${code}/join`);
    } catch {
    }

    await loadAll();
    await loadMessages();
    await loadBilling();
  })();
}, [code, loadBilling]);

const onWsMessage = useCallback((msg) => {
  if (msg.type === "hello") {
    setWsConnected(true);
    return;
  }

  if (msg.type === "chat.new") {
    setMessages((cur) => {
      const exists = cur.some((m) => m.id === msg.data.id);

      if (exists) {
        return cur.map((m) => (m.id === msg.data.id ? msg.data : m));
      }

      return [...cur, msg.data];
    });

  } else if (msg.type === "chat.edit" || msg.type === "chat.reaction") {
    setMessages((cur) =>
      cur.map((m) => (m.id === msg.data.id ? msg.data : m))
    );

  } else if (msg.type === "chat.delete") {
    setMessages((cur) =>
      cur.map((m) =>
        m.id === msg.data.id ? { ...m, deleted: true, content: "" } : m
      )
    );

  } else if (msg.type === "playback") {
    console.log("PLAYBACK EVENT:", {
  action: msg.data?.action,
  status: msg.data?.playbackStatus,
  position: msg.data?.currentPositionSeconds,
  syncedAt: msg.data?.clientSyncedAt,
});
  const incomingStatus = normalizePlaybackStatus(
  msg.data?.playbackStatus || msg.data?.eventType || msg.data?.action,
  playback?.playbackStatus || "PAUSED"
);


  const incomingMediaId = msg.data?.mediaId || playback?.mediaId;

  const playingItem =
    queue.find((item) => item.mediaId === incomingMediaId) ||
    queue.find((item) => String(item.status || "").toUpperCase() === "PLAYING");

  const rawPosition =
    msg.data?.currentPositionSeconds ??
    msg.data?.toPositionSeconds ??
    msg.data?.positionSeconds ??
    0;


  const speed = msg.data?.playbackSpeed ?? playback?.playbackSpeed ?? 1.0;

  const clientSyncedAt = msg.data?.clientSyncedAt || null;

  let correctedPosition = Number(rawPosition) || 0;

  if (incomingStatus === "PLAYING" && clientSyncedAt) {
    const delaySeconds = Math.max(0, (Date.now() - Number(clientSyncedAt)) / 1000);
    correctedPosition += 0.8 * speed;
  }

  setPlayback((current) => {
    const base = playingItem
      ? {
          title: playingItem.mediaTitle || playingItem.title,
          sourceUrl: playingItem.sourceUrl,
          mediaId: playingItem.mediaId,
        }
      : {};

    return {
      ...current,
      ...msg.data,
      ...base,
      playbackStatus: incomingStatus,
      currentPositionSeconds: correctedPosition,
      playbackSpeed: speed,
      lastSyncedAt:
        msg.data?.createdAt ||
        msg.data?.lastSyncedAt ||
        new Date().toISOString(),
      clientSyncedAt,
      forceSyncKey:
        String(msg.data?.action || "").toUpperCase() === "SEEK"
          ? `SEEK-${incomingMediaId}-${correctedPosition}-${Date.now()}`
          : msg.data?.forceSyncKey,
    };
  });

  } else if (msg.type === "queue.changed") {
    loadQueue();

  } else if (
    msg.type === "room.participants-changed" ||
    msg.type === "room.host-transferred" ||
    msg.type === "room.control" ||
    msg.type === "room.mute"
  ) {
    loadParticipants();

  } else if (msg.type === "room.code-regenerated") {
  const newCode = msg.data?.newCode;

  if (newCode) {
    setRoom((cur) => ({
      ...cur,
      code: newCode,
      roomCode: newCode,
    }));

    nav(`/rooms/${newCode}`, { replace: true });
  }
} else if (msg.type === "room.kick") {
  const kickedUserId = String(
    msg.data?.userId ||
    msg.data?.targetUserId ||
    msg.data?.kickedUserId ||
    ""
  );

  const currentUserId = String(user?.id || user?.userId || "");

  const currentParticipant = participants.find((p) => isSameUser(p));

  const currentParticipantUserId = String(
    currentParticipant?.userId ||
    currentParticipant?.id ||
    ""
  );

  const isKickedUser =
    kickedUserId &&
    (
      kickedUserId === currentUserId ||
      kickedUserId === currentParticipantUserId
    );

  if (isKickedUser) {
    nav("/rooms", { replace: true });
    return;
  }

  loadParticipants();
}
}, [
  loadQueue,
  loadParticipants,
  user?.id,
  nav,
  queue,
  participants,
  playback?.playbackStatus,
  playback?.mediaId,
]);

  const {
  connected: socketConnected,
  sendChatMessage,
  sendPlaybackCommand,
} = useRoomSocket(code, onWsMessage);

useEffect(() => {
  setWsConnected(socketConnected);
}, [socketConnected]);

 useEffect(() => {
  const id = setInterval(() => {
    loadQueue();

    if (!wsConnected) {
      loadMessages();
      loadParticipants();
    }
  }, 3000);

  return () => clearInterval(id);
}, [wsConnected, loadParticipants, loadQueue]);

useEffect(() => {
  const playingItem = queue
    .filter(isActiveQueueItem)
    .find((item) => String(item.status || "").toUpperCase() === "PLAYING");

  if (!playingItem) return;

  setPlayback((current) => {
    // Если видео то же самое — не трогаем статус PLAYING/PAUSED.
    if (current?.mediaId === playingItem.mediaId) {
      return {
        ...current,
        title: current.title || playingItem.mediaTitle || playingItem.title,
        sourceUrl: current.sourceUrl || playingItem.sourceUrl,
      };
    }

    // Если сменилось видео — подставляем новое.
    // Но сам факт статуса QUEUE PLAYING не должен бесконечно форсить video.play().
    return makePlaybackFromQueueItem(playingItem, "PAUSED", current);
  });
}, [queue]);
  // Auto scroll chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length]);

  const sendMessage = async (e) => {
  e.preventDefault();

  if (!chatInput.trim()) return;

  const content = chatInput.trim();
  setChatInput("");

  const sent = sendChatMessage(content);

  if (!sent) {
    setError("WebSocket is not connected. Message was not sent.");
    setChatInput(content);
  }
}

const sendSticker = async (stickerId) => {
  if (!hasPremium) {
    setError("Premium stickers are available only for Premium and Pro users.");
    return;
  }

  try {
    await client.post(`/chat/rooms/${code}/messages`, {
      roomCode: code,
      content: stickerId,
      messageType: "STICKER",
    });

    await loadMessages();
  } catch (err) {
    setError(formatApiError(err));
  }

  setStickerPickerOpen(false);
};

  const handlePlayerCommand = async (action, extra = {}) => {
  const normalizedAction = String(action).toUpperCase();

  const nextStatus = normalizePlaybackStatus(
    normalizedAction,
    playback?.playbackStatus || "PAUSED"
  );

  const nextPosition =
    extra.positionSeconds ??
    extra.currentPositionSeconds ??
    playback?.currentPositionSeconds ??
    0;

  const syncedAt = Date.now();

  console.log("LOCAL PLAYER COMMAND:", normalizedAction, nextPosition);

  setPlayback((current) => {
    if (!current) return current;

    return {
      ...current,
      playbackStatus: nextStatus,
      currentPositionSeconds: nextPosition,
      playbackSpeed: extra.playbackSpeed ?? current.playbackSpeed ?? 1.0,
      lastSyncedAt: new Date(syncedAt).toISOString(),
      clientSyncedAt: syncedAt,
    };
  });

  const sent = sendPlaybackCommand({
    mediaId: extra.mediaId || playback?.mediaId || null,
    action: normalizedAction,
    playbackStatus: nextStatus,
    positionSeconds: nextPosition,
    currentPositionSeconds: nextPosition,
    playbackSpeed: extra.playbackSpeed ?? playback?.playbackSpeed ?? 1.0,
    clientSyncedAt: syncedAt,
  });

  console.log("WS SENT:", sent);

  if (!sent) {
    setError("WebSocket is not connected. Playback command was not sent.");
  }
};

  const leaveRoom = async () => {
    try {
      await client.post(`/rooms/${code}/leave`);
    } catch {
      // ignore
    }
    nav("/rooms");
  };

  const copyCode = () => {
    navigator.clipboard.writeText(code);
    setCopyMsg("Copied!");
    setTimeout(() => setCopyMsg(""), 1500);
  };

  const playQueueItem = async (itemId) => {
  try {
    const { data } = await client.post(`/rooms/${code}/queue/${itemId}/play`);

    const nextPlayback = {
      roomCode: code,
      mediaId: data.mediaId,
      title: data.mediaTitle,
      sourceUrl: data.sourceUrl,
      playbackStatus: "PAUSED",
      currentPositionSeconds: 0,
      playbackSpeed: 1.0,
      lastActionByUserId: data.addedByUserId,
      lastActionByUsername: data.addedByUsername,
      lastSyncedAt: new Date().toISOString(),
    };

    setPlayback(nextPlayback);

    sendPlaybackCommand({
      mediaId: data.mediaId,
      action: "PLAY",
      positionSeconds: 0,
      playbackSpeed: 1.0,
    });

    await loadQueue();
  } catch (err) {
    setError(formatApiError(err));
  }
};
  const removeQueueItem = async (itemId) => {
    try {
      await client.delete(`/rooms/${code}/queue/${itemId}`);
      loadAll();
    } catch (err) {
      setError(formatApiError(err));
    }
  };

  const toggleReaction = async (msg, emoji) => {
  const myReact = (msg.reactions || []).find(
    (r) => r.userId === user?.id && r.reactionType === emoji,
  );

  const optimisticReaction = {
    userId: user?.id,
    username: user?.username || user?.email || "me",
    reactionType: emoji,
  };

  // 1. Мгновенно обновляем UI
  setMessages((current) =>
    current.map((message) => {
      if (message.id !== msg.id) return message;

      const oldReactions = message.reactions || [];

      const nextReactions = myReact
        ? oldReactions.filter(
            (r) => !(r.userId === user?.id && r.reactionType === emoji),
          )
        : [...oldReactions, optimisticReaction];

      return {
        ...message,
        reactions: nextReactions,
      };
    }),
  );

  try {
    let response;

    if (myReact) {
      response = await client.delete(`/chat/messages/${msg.id}/reactions`, {
        data: {
          reactionType: emoji,
        },
      });
    } else {
      response = await client.post(`/chat/messages/${msg.id}/reactions`, {
        reactionType: emoji,
      });
    }

    if (response?.data?.id) {
      setMessages((current) =>
        current.map((message) =>
          message.id === response.data.id ? response.data : message,
        ),
      );
    }
  } catch (err) {
    // 3. Если запрос упал — откатываем и показываем ошибку
    setMessages((current) =>
      current.map((message) => (message.id === msg.id ? msg : message)),
    );

    setError(formatApiError(err));
  }

  setReactionPickerFor(null);
};

  const deleteMessage = async (msg) => {
    try {
      await client.delete(`/chat/messages/${msg.id}`);
    } catch (err) {
      setError(formatApiError(err));
    }
  };

  const moderate = async (action, p, extra = "") => {
    try {
      if (action === "kick") await client.post(`/rooms/${code}/kick/${p.userId}`);
      if (action === "transfer") await client.post(`/rooms/${code}/transfer-host/${p.userId}`);
      if (action === "grant") await client.post(`/rooms/${code}/grant-control/${p.userId}`);
      if (action === "revoke") await client.post(`/rooms/${code}/revoke-control/${p.userId}`);
      if (action === "mute") await client.post(`/rooms/${code}/mute/${p.userId}?muted=true`);
      if (action === "unmute") await client.post(`/rooms/${code}/mute/${p.userId}?muted=false`);
      setModerationFor(null);
      loadParticipants();
    } catch (err) {
      setError(formatApiError(err));
    }
  };

  if (!room) {
    return (
      <div className="relative min-h-screen">
        <div className="starfield" />
        <div className="relative z-10">
          <Navbar />
          <div className="max-w-7xl mx-auto px-6 py-20 text-center text-[var(--text-secondary)]">
            {error ? error : "Loading room..."}
          </div>
        </div>
      </div>
    );
  }

  return (
  <div
  className="relative min-h-screen themed-room"
  style={{
    "--room-accent": room?.themeColor || "#8b5cf6",
    "--violet": room?.themeColor || "#8b5cf6",
    "--violet-bright": room?.themeColor || "#a855f7",
    "--violet-soft": room?.themeColor || "#c4b5fd",
  }}
  data-testid="room-root"
>
    <div className="starfield" />

    {room?.backgroundUrl && (
      <div
        className="fixed inset-0 z-0 pointer-events-none"
        style={{
          backgroundImage: `url(${room.backgroundUrl})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          opacity: 0.25,
          filter: "blur(2px)",
        }}
        data-testid="room-background"
      />
    )}

    <div className="relative z-10">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 md:px-6 py-6">
        {room?.coverImageUrl && (
          <div
            className="relative w-full rounded-2xl overflow-hidden mb-5 border border-violet-500/20"
            style={{ aspectRatio: "5 / 1", minHeight: 140 }}
            data-testid="room-cover"
          >
            <img
              src={room.coverImageUrl}
              alt={room.name}
              className="absolute inset-0 w-full h-full object-cover"
            />

            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />

            <div className="absolute bottom-0 left-0 right-0 p-5">
              <h2 className="font-serif text-3xl md:text-4xl tracking-wide text-white drop-shadow-lg">
                {room.name}
              </h2>

              {room.description && (
                <p className="text-sm text-white/80 mt-1 line-clamp-2 max-w-2xl">
                  {room.description}
                </p>
              )}
            </div>
          </div>
        )}

        {/* Room header */}
          <div className="flex flex-wrap items-center gap-3 mb-4">
            <Link to="/rooms" className="btn-ghost !py-2 !px-3 inline-flex items-center gap-1.5" data-testid="room-back">
              <ArrowLeft size={16} />
            </Link>
            <div className="flex-1 min-w-0">
              <h1 className="font-serif text-2xl md:text-3xl tracking-wide text-white truncate" data-testid="room-name">
                {room.name}
              </h1>
              {room?.themeColor && (
                <div
                  className="mt-2 h-1 w-32 rounded-full"
                  style={{
                    background: `linear-gradient(90deg, ${room.themeColor}, transparent)`,
                  }}
                />
              )}
              {room.description && (
                <p className="text-sm text-[var(--text-secondary)] truncate">{room.description}</p>
              )}
            </div>
            <button
              onClick={copyCode}
              className="inline-flex items-center gap-2 glass-card px-4 py-2 text-sm font-mono hover:bg-violet-500/10 transition"
              data-testid="room-copy-code"
              title="Copy room code"
            >
              <Copy size={14} /> {code} {copyMsg && <span className="text-emerald-400 text-xs">{copyMsg}</span>}
            </button>
            <span
              className={`inline-flex items-center gap-1 text-[11px] px-2.5 py-1 rounded-full border ${
                wsConnected
                  ? "bg-emerald-500/10 text-emerald-300 border-emerald-500/30"
                  : "bg-violet-500/10 text-[var(--violet-soft)] border-violet-500/30"
              }`}
              title={wsConnected ? "Live updates active" : "Reconnecting..."}
              data-testid="ws-status"
            >
              {wsConnected ? <Wifi size={12} /> : <WifiOff size={12} />}
              {wsConnected ? "LIVE" : "POLLING"}
            </span>
            <button onClick={leaveRoom} className="btn-ghost !py-2 inline-flex items-center gap-1.5" data-testid="room-leave">
              <LogOut size={15} /> Leave
            </button>
            {isHost && (
  <button
    onClick={() => setSettingsOpen(true)}
    className="btn-ghost !py-2 !px-3 inline-flex items-center gap-1.5"
    title="Room settings"
    data-testid="room-settings-btn"
  >
    <SettingsIcon size={15} />
  </button>
)}
          </div>

          <div className="grid lg:grid-cols-[1fr_360px] gap-5">
            {/* Main col */}
            <div>
              {!screenShareActive && (
                <SyncedPlayer
                  playbackState={playback}
                  onLocalCommand={handlePlayerCommand}
                  canControl={canControl}
                />
              )}

              <ScreenSharePlayer
                roomCode={code}
                startSignal={screenShareStartSignal}
                onActiveChange={setScreenShareActive}
              />

              <div className="mt-4">
                <VoiceChat roomCode={code} />
              </div>
              {playback?.title && (
                <div className="mt-4 glass-card p-4 flex items-center gap-3">
                  <PlayIcon size={18} className="text-[var(--violet-soft)]" />
                  <div className="flex-1 min-w-0">
                    <div className="font-serif text-lg truncate">{playback.title}</div>
                    <div className="text-xs text-[var(--text-muted)]">
                      {playback.playbackStatus}
                      {playback.lastActionByUsername && ` · by @${playback.lastActionByUsername}`}
                    </div>
                  </div>
                </div>
              )}

              {/* Queue */}
              <div className="mt-5 glass-card p-5">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-serif text-xl tracking-wide flex items-center gap-2">
                    <ListVideo size={18} className="text-[var(--violet-soft)]" /> QUEUE ({queue.length})
                  </h3>
                  <button
                    className="btn-primary !py-2 !px-3 text-sm inline-flex items-center gap-1.5"
                    onClick={() => setAddMediaOpen(true)}
                    data-testid="room-add-media-btn"
                  >
                    <Plus size={14} /> Add
                  </button>
                </div>

                {queue.length === 0 ? (
                  <p className="text-sm text-[var(--text-secondary)] py-6 text-center">
                    Queue is empty. Add a video from catalog or paste a YouTube URL.
                  </p>
                ) : (
                  <div className="space-y-2">
                    {queue.map((q) => {
                      const thumb = q.thumbnailUrl || getYouTubeThumbnail(q.sourceUrl);
                      return (
                        <div
                          key={q.queueItemId}
                          className="flex items-center gap-3 p-2 rounded-xl bg-violet-500/5 border border-violet-500/10"
                          data-testid={`queue-item-${q.queueItemId}`}
                        >
                          {thumb ? (
                            <img src={thumb} alt="" className="w-20 h-12 object-cover rounded-md flex-shrink-0" />
                          ) : (
                            <div className="w-20 h-12 rounded-md bg-violet-500/20 flex-shrink-0" />
                          )}
                          <div className="flex-1 min-w-0">
                            <div className="text-sm font-semibold truncate">{q.mediaTitle}</div>
                            <div className="text-xs text-[var(--text-muted)]">
                              {q.status} · added by @{q.addedByUsername}
                            </div>
                          </div>
                          {canControl && (
                            <>
                              <button
                                onClick={() => playQueueItem(q.queueItemId)}
                                className="btn-primary !py-1.5 !px-3 text-xs"
                                data-testid={`play-queue-${q.queueItemId}`}
                              >
                                <PlayIcon size={12} />
                              </button>
                              <button
                                onClick={() => removeQueueItem(q.queueItemId)}
                                className="btn-ghost !py-1.5 !px-2 text-xs"
                                data-testid={`remove-queue-${q.queueItemId}`}
                              >
                                <Trash2 size={12} />
                              </button>
                            </>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            {/* Sidebar */}
            <div className="lg:sticky lg:top-20 h-fit">
              <div className="glass-card p-4 h-[620px] flex flex-col">
                <div className="flex p-1 bg-violet-500/10 rounded-full mb-4">
                  {[
                    { id: "chat", label: "Chat", icon: MessageCircle, count: messages.length },
                    { id: "people", label: "People", icon: Users, count: participants.length },
                  ].map((t) => {
                    const Icon = t.icon;
                    return (
                      <button
                        key={t.id}
                        onClick={() => setSidebarTab(t.id)}
                        className={`flex-1 inline-flex items-center justify-center gap-1.5 py-2 rounded-full text-sm font-semibold transition ${
                          sidebarTab === t.id
                            ? "room-active-tab text-white"
                            : "text-[var(--text-secondary)]"
                        }`}
                        data-testid={`sidebar-tab-${t.id}`}
                      >
                        <Icon size={14} /> {t.label} ({t.count})
                      </button>
                    );
                  })}
                </div>

                {sidebarTab === "chat" ? (
                  <>
                    <div className="flex-1 overflow-y-auto pr-1">
                      {messages.length === 0 ? (
                        <p className="text-center text-sm text-[var(--text-secondary)] py-10">Say hi to start the conversation!</p>
                      ) : (
                        messages.map((m) => {
                          const mine = m.senderId === user?.id;
                          // Aggregate reactions by emoji
                          const grouped = {};
                          (m.reactions || []).forEach((r) => {
                            if (!grouped[r.reactionType]) grouped[r.reactionType] = [];
                            grouped[r.reactionType].push(r);
                          });
                          return (
                            <div
                              key={m.id}
                              className={`chat-message group relative ${mine ? "chat-message-mine" : ""}`}
                              data-testid={`chat-msg-${m.id}`}
                            >
                              <div className="flex items-center gap-2 mb-0.5">
                                <span className="avatar avatar-sm">
                                  {(m.senderDisplayName || m.senderUsername || "?")[0]?.toUpperCase()}
                                </span>
                                <span className="text-xs font-semibold">{m.senderDisplayName || m.senderUsername}</span>
                                <span className="text-[10px] text-[var(--text-muted)]">
                                  {m.sentAt ? new Date(m.sentAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : ""}
                                </span>
                                {m.edited && <span className="text-[10px] text-[var(--text-muted)] italic">(edited)</span>}
                              </div>
                              <div className="text-sm break-words">
                              {m.deleted ? (
                                <em className="text-[var(--text-muted)]">deleted</em>
                              ) : m.messageType === "STICKER" ? (
                                <div className="inline-flex flex-col items-center gap-1 px-4 py-3 rounded-2xl bg-violet-500/10 border border-violet-500/20">
                                  <div className="text-5xl">
                                    {PREMIUM_STICKERS.find((s) => s.id === m.content)?.emoji || "⭐"}
                                  </div>
                                  <div className="text-[10px] text-[var(--violet-soft)] uppercase tracking-widest">
                                    premium
                                  </div>
                                </div>
                              ) : (
                                m.content
                              )}
                            </div>

                              {/* Reactions row */}
                              {Object.keys(grouped).length > 0 && (
                                <div className="flex flex-wrap gap-1 mt-1.5">
                                  {Object.entries(grouped).map(([emoji, list]) => {
                                    const mineReact = list.some((r) => r.userId === user?.id);
                                    return (
                                      <button
                                        key={emoji}
                                        onClick={() => toggleReaction(m, emoji)}
                                        className={`text-xs px-2 py-0.5 rounded-full border transition ${
                                          mineReact
                                            ? "bg-violet-500/30 border-violet-400/60 text-white"
                                            : "bg-violet-500/10 border-violet-500/20 text-[var(--violet-soft)] hover:bg-violet-500/20"
                                        }`}
                                        title={list.map((r) => r.username).join(", ")}
                                        data-testid={`msg-reaction-${m.id}-${emoji}`}
                                      >
                                        {emoji} {list.length}
                                      </button>
                                    );
                                  })}
                                </div>
                              )}

                              {/* Action buttons (visible on hover) */}
                              {!m.deleted && (
                                <div className="absolute top-1 right-1 hidden group-hover:flex gap-1 bg-[#1a1538]/95 rounded-lg p-0.5 border border-violet-500/30 shadow-lg">
                                  <button
                                    onClick={() => setReactionPickerFor(reactionPickerFor === m.id ? null : m.id)}
                                    className="p-1 rounded hover:bg-violet-500/20 text-[var(--text-secondary)]"
                                    data-testid={`msg-react-btn-${m.id}`}
                                    title="React"
                                  >
                                    <Smile size={13} />
                                  </button>
                                  {mine && (
                                    <button
                                      onClick={() => deleteMessage(m)}
                                      className="p-1 rounded hover:bg-pink-500/20 text-pink-300"
                                      data-testid={`msg-delete-btn-${m.id}`}
                                      title="Delete"
                                    >
                                      <Trash2 size={13} />
                                    </button>
                                  )}
                                </div>
                              )}

                              {/* Reaction picker */}
                              {reactionPickerFor === m.id && (
                                <div className="absolute top-8 right-1 z-10 bg-[#1a1538] border border-violet-500/30 rounded-xl p-1 flex gap-0.5 shadow-2xl" data-testid={`reaction-picker-${m.id}`}>
                                  {REACTION_EMOJIS.map((emoji) => (
                                    <button
                                      key={emoji}
                                      onClick={() => toggleReaction(m, emoji)}
                                      className="text-lg w-8 h-8 rounded-lg hover:bg-violet-500/30 transition"
                                      data-testid={`pick-${emoji}-${m.id}`}
                                    >
                                      {emoji}
                                    </button>
                                  ))}
                                </div>
                              )}
                            </div>
                          );
                        })
                      )}
                      <div ref={chatEndRef} />
                    </div>
                    <form onSubmit={sendMessage} className="mt-3 flex gap-2 relative">
                    <input
                      className="input-field-dark flex-1 !py-3"
                      placeholder="Type a message..."
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      data-testid="chat-input"
                    />

                    <button
                      type="button"
                      onClick={() => setStickerPickerOpen((v) => !v)}
                      className={`btn-ghost !py-3 !px-3 ${hasPremium ? "" : "opacity-60"}`}
                      title={hasPremium ? "Premium stickers" : "Premium stickers require Premium"}
                      data-testid="sticker-btn"
                    >
                      <Crown size={16} />
                    </button>

                    {stickerPickerOpen && (
                      <div className="absolute bottom-14 right-12 z-30 glass-card p-3 w-64">
                        <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-[var(--violet-soft)] mb-2">
                          <Crown size={12} className="text-yellow-400" />
                          Premium stickers
                        </div>

                        {!hasPremium ? (
                          <div className="text-xs text-[var(--text-secondary)]">
                            Upgrade to Premium to use stickers.
                          </div>
                        ) : (
                          <div className="grid grid-cols-3 gap-2">
                            {PREMIUM_STICKERS.map((s) => (
                              <button
                                key={s.id}
                                type="button"
                                onClick={() => sendSticker(s.id)}
                                className="rounded-xl bg-violet-500/10 border border-violet-500/20 hover:bg-violet-500/20 p-3 text-2xl transition"
                                title={s.label}
                                data-testid={`sticker-${s.id}`}
                              >
                                {s.emoji}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    )}

                    <button type="submit" className="btn-primary !py-3 !px-4" data-testid="chat-send">
                      <Send size={16} />
                    </button>
                  </form>
                  </>
                ) : (
                  <div className="flex-1 overflow-y-auto space-y-2">
                    {isHost && (
                      <div
                        className="text-[11px] tracking-wider uppercase text-[var(--violet-soft)] bg-violet-500/10 border border-violet-500/20 rounded-lg px-3 py-2 mb-2 flex items-center gap-2"
                        data-testid="host-banner"
                      >
                        <Crown size={12} className="text-yellow-400" />
                        You're the host — click <MoreVertical size={11} /> on any guest to grant control, mute, transfer host or kick.
                      </div>
                    )}

                    {participants.length === 1 ? (
                      <button
                        onClick={() => setInviteOpen(true)}
                        className="w-full text-left text-xs p-3 rounded-xl border border-violet-500/20 bg-violet-500/5 hover:bg-violet-500/10 transition"
                        data-testid="invite-friends-cta"
                      >
                        <div className="font-semibold text-[var(--text-primary)] mb-0.5 inline-flex items-center gap-1.5">
                          <UserMinus size={12} className="rotate-180" /> Invite friends
                        </div>
                        <div className="text-[var(--text-muted)]">
                          Pick from your friends list or share room code{" "}
                          <code className="text-[var(--violet-soft)] font-mono">{code}</code>.
                        </div>
                      </button>
                    ) : (
                      <button
                        onClick={() => setInviteOpen(true)}
                        className="w-full text-center text-xs py-2 rounded-xl border border-violet-500/20 bg-violet-500/5 hover:bg-violet-500/10 transition font-semibold inline-flex items-center justify-center gap-1.5 mb-1"
                        data-testid="invite-friends-btn"
                      >
                        <UserMinus size={12} className="rotate-180" /> Invite more friends
                      </button>
                    )}

                    {participants.map((p) => {
                      const isMe = isSameUser(p);

                      const showMenu = isHost && !isMe && moderationFor === p.userId;

                      return (
                        <div
                          key={p.userId}
                          className="relative flex items-center gap-3 p-2 rounded-xl bg-violet-500/5"
                          data-testid={`participant-${p.userId}`}
                        >
                          {p.avatarUrl ? (
                            <img
                              src={resolveAvatarUrl(p.avatarUrl)}
                              alt=""
                              className="avatar object-cover border border-violet-500/30 bg-violet-500/10"
                            />
                          ) : (
                            <span className="avatar">
                              {(p.displayName || p.username || "?")[0]?.toUpperCase()}
                            </span>
                          )}

                          <div className="flex-1 min-w-0">
                            <div className="text-sm font-semibold truncate flex items-center gap-1.5">
                              {p.displayName || p.username}
                              {p.role === "HOST" && (
                                <Crown size={12} className="text-yellow-400" />
                              )}
                              {p.muted && <VolumeX size={12} className="text-pink-300" />}
                            </div>

                            <div className="text-xs text-[var(--text-muted)] truncate">
                              @{p.username}
                              {p.canControlPlayback && p.role !== "HOST" && (
                                <span className="ml-1.5 text-[var(--violet-soft)]">
                                  · can control
                                </span>
                              )}
                            </div>
                          </div>

                          {!isMe && (
                            <span className="text-[10px] px-2 py-1 rounded-full bg-violet-500/15 text-[var(--violet-soft)]">
                              {p.role}
                            </span>
                          )}

                          {isHost && !isMe && (
                            <button
                              onClick={() => setModerationFor(showMenu ? null : p.userId)}
                              className="p-1.5 rounded hover:bg-violet-500/20 text-[var(--text-secondary)]"
                              data-testid={`moderate-${p.userId}`}
                              title="Moderate"
                            >
                              <MoreVertical size={14} />
                            </button>
                          )}

                          {showMenu && (
                            <div
                              className="absolute right-0 top-[calc(100%+4px)] z-20 min-w-[200px] glass-card py-1.5"
                              data-testid={`mod-menu-${p.userId}`}
                            >
                              {p.canControlPlayback ? (
                                <button
                                  onClick={() => moderate("revoke", p)}
                                  className="w-full text-left px-4 py-2 text-sm hover:bg-violet-500/10"
                                  data-testid={`mod-revoke-${p.userId}`}
                                >
                                  Revoke playback control
                                </button>
                              ) : (
                                <button
                                  onClick={() => moderate("grant", p)}
                                  className="w-full text-left px-4 py-2 text-sm hover:bg-violet-500/10"
                                  data-testid={`mod-grant-${p.userId}`}
                                >
                                  Grant playback control
                                </button>
                              )}

                              {p.muted ? (
                                <button
                                  onClick={() => moderate("unmute", p)}
                                  className="w-full text-left px-4 py-2 text-sm hover:bg-violet-500/10 inline-flex items-center gap-2"
                                  data-testid={`mod-unmute-${p.userId}`}
                                >
                                  <Volume2 size={13} /> Unmute
                                </button>
                              ) : (
                                <button
                                  onClick={() => moderate("mute", p)}
                                  className="w-full text-left px-4 py-2 text-sm hover:bg-violet-500/10 inline-flex items-center gap-2"
                                  data-testid={`mod-mute-${p.userId}`}
                                >
                                  <VolumeX size={13} /> Mute
                                </button>
                              )}

                              <button
                                onClick={() => moderate("transfer", p)}
                                className="w-full text-left px-4 py-2 text-sm hover:bg-violet-500/10 inline-flex items-center gap-2 text-yellow-300"
                                data-testid={`mod-transfer-${p.userId}`}
                              >
                                <Crown size={13} /> Transfer host
                              </button>

                              <button
                                onClick={() => moderate("kick", p)}
                                className="w-full text-left px-4 py-2 text-sm hover:bg-pink-500/10 text-pink-300 inline-flex items-center gap-2"
                                data-testid={`mod-kick-${p.userId}`}
                              >
                                <UserX size={13} /> Kick from room
                              </button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {addMediaOpen && (
        <AddMediaDialog
            roomCode={code}
            onClose={() => setAddMediaOpen(false)}
            onStartScreenShare={() => {
            setScreenShareStartSignal((value) => value + 1);
            setAddMediaOpen(false);
          }}
            onAdded={(playedItem) => {
              if (playedItem) {
                const nextPlayback = {
                  roomCode: code,
                  mediaId: playedItem.mediaId,
                  title: playedItem.mediaTitle,
                  sourceUrl: playedItem.sourceUrl,
                  playbackStatus: "PLAYING",
                  currentPositionSeconds: 0,
                  playbackSpeed: 1.0,
                  lastActionByUserId: playedItem.addedByUserId,
                  lastActionByUsername: playedItem.addedByUsername,
                  lastSyncedAt: new Date().toISOString(),
                };

            setPlayback(nextPlayback);

            sendPlaybackCommand({
              mediaId: playedItem.mediaId,
              action: "PLAY",
              positionSeconds: 0,
              playbackSpeed: 1.0,
            });
          }

          loadQueue();
          setAddMediaOpen(false);
        }}
/>
      )}

      {settingsOpen && room && (
        <RoomSettingsDialog
          room={room}
          billing={billing}
          onClose={() => setSettingsOpen(false)}
          onUpdated={(updated) => setRoom(updated)}
          onClosed={() => {
            setSettingsOpen(false);
            nav("/rooms");
          }}
          onCodeRegenerated={(newCode) => {
            if (!newCode) return;

            setRoom((cur) => ({
              ...cur,
              code: newCode,
              roomCode: newCode,
            }));

            setSettingsOpen(false);
            nav(`/rooms/${newCode}`, { replace: true });
          }}
        />
      )}

      {inviteOpen && room && (
        <InviteFriendsDialog
          roomCode={code}
          roomName={room.name}
          onClose={() => setInviteOpen(false)}
        />
      )}
    </div>
  );
}

function AddMediaDialog({ roomCode, onClose, onAdded, onStartScreenShare }) {
  const [tab, setTab] = useState("catalog");
  const [catalog, setCatalog] = useState([]);
  const [category, setCategory] = useState("");
  const [url, setUrl] = useState("");
  const [title, setTitle] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const { data } = await client.get("/media");
        setCatalog(data);
      } catch {
        // ignore
      }
    })();
  }, []);

  const categories = Array.from(new Set(catalog.map((m) => m.category).filter(Boolean)));
  const filtered = category ? catalog.filter((m) => m.category === category) : catalog;

  const addFromCatalog = async (m) => {
  setError("");

  try {
    const added = await client.post(`/rooms/${roomCode}/queue`, {
      mediaId: m.id,
    });

    const queueItemId = added.data?.queueItemId;

    if (!queueItemId) {
      onAdded();
      return;
    }

    const played = await client.post(
      `/rooms/${roomCode}/queue/${queueItemId}/play`,
    );

    onAdded(played.data);
  } catch (err) {
    setError(formatApiError(err));
  }
};

  const addExternal = async (e) => {
  e.preventDefault();

  const cleanUrl = url.trim();
  const cleanTitle = title.trim();

  if (!cleanUrl) return;

  setLoading(true);
  setError("");

  try {
    const isYoutube =
      cleanUrl.includes("youtube.com") ||
      cleanUrl.includes("youtu.be");

    const payload = {
      title: cleanTitle || "YouTube video",
      description: "External video",
      mediaType: isYoutube ? "YOUTUBE" : "MOVIE",
      sourceType: isYoutube ? "YOUTUBE" : "EXTERNAL_URL",
      sourceUrl: cleanUrl,
      thumbnailUrl: null,
      durationSeconds: 600,
    };

    console.log("ADD EXTERNAL PAYLOAD:", payload);

    const added = await client.post(
      `/rooms/${roomCode}/queue/external`,
      payload,
    );

    const queueItemId = added.data?.queueItemId;

    if (!queueItemId) {
      onAdded();
      return;
    }

    const played = await client.post(
      `/rooms/${roomCode}/queue/${queueItemId}/play`,
    );

    onAdded(played.data);
  } catch (err) {
    console.error("ADD EXTERNAL ERROR:", err?.response?.data || err);
    setError(formatApiError(err));
  } finally {
    setLoading(false);
  }
};
const searchExternalMedia = async () => {
  const query = searchQuery.trim();

  console.log("SEARCH CLICKED:", query);

  if (!query) return;

  setSearching(true);
  setError("");
  setSearchResults([]);

  try {
    const { data } = await client.get("/media/search", {
      params: {
        query,
      },
    });

    console.log("SEARCH RESPONSE:", data);

    setSearchResults(Array.isArray(data) ? data : []);
  } catch (err) {
    console.error("SEARCH ERROR:", err?.response?.status, err?.response?.data || err);
    setError(formatApiError(err));
  } finally {
    setSearching(false);
  }
};

const importAndAddToQueue = async (item) => {
  setError("");

  try {
    let added;

    const provider = String(item.provider || "").toUpperCase();

    if (item.localMediaId) {
      added = await client.post(`/rooms/${roomCode}/queue`, {
        mediaId: item.localMediaId,
      });
    } else if (provider === "YOUTUBE") {
      added = await client.post(`/rooms/${roomCode}/queue/external`, {
        title: item.title,
        description: item.description || "YouTube video",
        mediaType: "YOUTUBE",
        sourceType: "YOUTUBE",
        sourceUrl: item.sourceUrl,
        thumbnailUrl: item.thumbnailUrl,
        durationSeconds: item.durationSeconds || 600,
      });
    } else {
  const importPayload = {
    externalId: item.externalId,
    title: item.title || "Partner media",
    description: item.description || "Partner media item",
    sourceType: item.sourceType || "EXTERNAL_URL",
    sourceUrl: item.sourceUrl,
    thumbnailUrl: item.thumbnailUrl || null,
    releaseYear: item.releaseYear || null,
    durationSeconds: item.durationSeconds || 600,
    provider: item.provider || "PARTNER_MEDIA",
  };

  console.log("PARTNER IMPORT PAYLOAD:", importPayload);

  const { data: imported } = await client.post("/media/import", importPayload);

  console.log("IMPORTED MEDIA:", imported);

  added = await client.post(`/rooms/${roomCode}/queue`, {
    mediaId: imported.id,
  });
}

    const queueItemId = added.data?.queueItemId;

    if (!queueItemId) {
      onAdded();
      return;
    }

    const played = await client.post(
      `/rooms/${roomCode}/queue/${queueItemId}/play`
    );

    onAdded(played.data);
  } catch (err) {
  console.error("IMPORT AND ADD ERROR STATUS:", err?.response?.status);
  console.error("IMPORT AND ADD ERROR URL:", err?.config?.url);
  console.error("IMPORT AND ADD ERROR DATA:", err?.response?.data);
  console.error("IMPORT AND ADD ERROR FULL:", err);

  setError(formatApiError(err));
}
};
  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4" onClick={onClose}>
      <div
        className="glass-card w-full max-w-3xl max-h-[85vh] overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
        data-testid="add-media-dialog"
      >
        <div className="flex items-center justify-between p-5 border-b border-violet-500/15">
          <h2 className="font-serif text-xl tracking-wide">ADD TO QUEUE</h2>
          <button onClick={onClose} className="text-[var(--text-secondary)] hover:text-white" data-testid="close-add-media">
            <X size={20} />
          </button>
        </div>
        <div className="flex p-1 mx-5 mt-4 bg-violet-500/10 rounded-full">
          {[
            { id: "catalog", label: "Catalog" },
            { id: "url", label: "YouTube / URL" },
            { id: "search", label: "Search" },
            { id: "screen", label: "Screen share" },
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex-1 py-2 rounded-full text-sm font-semibold transition ${
                tab === t.id ? "bg-gradient-to-r from-violet-500 to-purple-500 text-white" : "text-[var(--text-secondary)]"
              }`}
              data-testid={`add-media-tab-${t.id}`}
            >
              {t.label}
            </button>
          ))}
        </div>
        <div className="flex-1 overflow-y-auto p-5">
          {tab === "catalog" ? (
            <>
              <div className="flex flex-wrap gap-2 mb-4">
                <button
                  onClick={() => setCategory("")}
                  className={`px-3 py-1.5 text-xs rounded-full transition ${
                    !category ? "bg-violet-500 text-white" : "bg-violet-500/15 text-[var(--violet-soft)]"
                  }`}
                  data-testid="cat-all"
                >
                  All
                </button>
                {categories.map((c) => (
                  <button
                    key={c}
                    onClick={() => setCategory(c)}
                    className={`px-3 py-1.5 text-xs rounded-full transition ${
                      category === c ? "bg-violet-500 text-white" : "bg-violet-500/15 text-[var(--violet-soft)]"
                    }`}
                    data-testid={`cat-${c}`}
                  >
                    {c}
                  </button>
                ))}
              </div>
              <div className="grid sm:grid-cols-2 gap-3">
                {filtered.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => addFromCatalog(m)}
                    className="flex items-center gap-3 p-2 rounded-xl bg-violet-500/5 border border-violet-500/10 hover:border-violet-500/40 transition text-left"
                    data-testid={`catalog-${m.id}`}
                  >
                    {m.thumbnailUrl ? (
                      <img src={m.thumbnailUrl} alt="" className="w-24 h-14 object-cover rounded-md flex-shrink-0" />
                    ) : (
                      <div className="w-24 h-14 rounded-md bg-violet-500/20 flex-shrink-0 flex items-center justify-center">
                        <Youtube size={18} className="text-[var(--violet-soft)]" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold truncate">{m.title}</div>
                      <div className="text-xs text-[var(--text-muted)] truncate">{m.category} · {m.releaseYear || "—"}</div>
                    </div>
                  </button>
                ))}
              </div>
            </>
          ) : tab === "url" ?(
            <form onSubmit={addExternal} className="space-y-4">
              <div>
                <label className="label">Video URL (YouTube or direct .mp4)</label>
                <input
                  className="input-field-dark"
                  placeholder="https://www.youtube.com/watch?v=..."
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  required
                  data-testid="add-url-input"
                />
              </div>
              <div>
                <label className="label">Title (optional)</label>
                <input
                  className="input-field-dark"
                  placeholder="What are we watching?"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  data-testid="add-title-input"
                />
              </div>
              <button type="submit" className="btn-primary w-full" disabled={loading} data-testid="add-url-submit">
                {loading ? "Adding..." : "Add to queue"}
              </button>
            </form>
                      ) : tab === "screen" ? (
            <div className="py-10 text-center">
              <div className="mx-auto w-16 h-16 rounded-2xl bg-violet-500/10 border border-violet-500/20 flex items-center justify-center mb-4">
                <MonitorUp size={28} className="text-[var(--violet-soft)]" />
              </div>

              <h3 className="font-serif text-2xl text-white mb-2">
                Share your screen
              </h3>

              <p className="text-sm text-[var(--text-secondary)] max-w-md mx-auto mb-6">
                Start a live screen sharing session as the current room media.
                Other participants will be able to watch your screen, but only
                you can stop the stream.
              </p>

              <button
                type="button"
                onClick={onStartScreenShare}
                className="btn-primary inline-flex items-center gap-2"
                data-testid="start-screen-share"
              >
                <MonitorUp size={16} />
                Start screen sharing
              </button>
            </div>
          )  :   (
            <div className="space-y-4">
              <div className="flex gap-2">
            <input
              className="input-field-dark flex-1"
              placeholder="Search movie, trailer, public video..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  searchExternalMedia();
                }
              }}
            />

            <button
              type="button"
              className="btn-primary"
              disabled={searching}
              onClick={searchExternalMedia}
            >
              {searching ? "Searching..." : "Search"}
            </button>
</div>

    {error && (
      <div className="text-sm text-pink-300 bg-pink-500/10 border border-pink-500/30 rounded-xl px-3 py-2">
        {error}
      </div>
    )}

    {searchResults.length === 0 ? (
      <div className="text-sm text-[var(--text-secondary)] text-center py-8">
        Search for a movie or video. If it is not in the local catalog,
        WatchTogether will check external sources.
      </div>
    ) : (
      <div className="grid sm:grid-cols-2 gap-3">
        {searchResults.map((item) => (
          <button
            key={`${item.provider}-${item.externalId}`}
            type="button"
            onClick={() => importAndAddToQueue(item)}
            className="flex items-center gap-3 p-2 rounded-xl bg-violet-500/5 border border-violet-500/10 hover:border-violet-500/40 transition text-left"
          >
            {item.thumbnailUrl ? (
              <img
                src={item.thumbnailUrl}
                alt=""
                className="w-24 h-14 object-cover rounded-md flex-shrink-0"
              />
            ) : (
              <div className="w-24 h-14 rounded-md bg-violet-500/20 flex-shrink-0 flex items-center justify-center text-xs text-[var(--violet-soft)]">
                {item.provider}
              </div>
            )}

            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold truncate">
                {item.title}
              </div>

              <div className="text-xs text-[var(--text-muted)] truncate">
                {item.provider}
                {item.releaseYear ? ` · ${item.releaseYear}` : ""}
                {item.alreadyInCatalog ? " · in catalog" : " · external"}
              </div>
            </div>
          </button>
        ))}
      </div>
    )}
  </div>
)}
          {error && <div className="mt-4 text-sm text-pink-300">{error}</div>}
        </div>
      </div>
    </div>
  );
}
