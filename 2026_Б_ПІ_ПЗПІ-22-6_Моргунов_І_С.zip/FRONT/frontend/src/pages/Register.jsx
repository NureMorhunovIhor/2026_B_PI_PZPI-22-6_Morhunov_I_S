import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Eye, EyeOff } from "lucide-react";
import Logo from "../components/Logo";
import { useAuth } from "../AuthContext";
import { formatApiError } from "../api";

export default function Register() {
  const { register } = useAuth();
  const nav = useNavigate();
  const [form, setForm] = useState({ email: "", username: "", displayName: "", password: "" });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handle = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await register(form);
      nav("/");
    } catch (err) {
      setError(formatApiError(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center px-6 py-12">
      <div className="starfield" />
      <div className="relative z-10 w-full max-w-lg fade-up">
        <div className="flex flex-col items-center mb-8">
          <div className="mb-5">
            <Logo size={88} />
          </div>
          <h1 className="font-serif text-4xl md:text-5xl tracking-wider text-white mb-2">
            WATCHTOGETHER
          </h1>
          <p className="text-[var(--text-secondary)] text-sm">Watch with friends in real time</p>
        </div>

        <div className="glass-card p-8 md:p-10 fade-up delay-1">
          <h2 className="font-serif text-2xl md:text-3xl text-center tracking-widest text-white mb-8">
            JOIN THE SHOW
          </h2>

          <form onSubmit={submit} className="space-y-4">
            <div>
              <label className="label">Email</label>
              <input
                className="input-field"
                type="email"
                placeholder="you@example.com"
                value={form.email}
                onChange={handle("email")}
                required
                data-testid="register-email"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label">Username</label>
                <input
                  className="input-field"
                  placeholder="johndoe"
                  value={form.username}
                  onChange={handle("username")}
                  required
                  minLength={3}
                  data-testid="register-username"
                />
              </div>
              <div>
                <label className="label">Display Name</label>
                <input
                  className="input-field"
                  placeholder="John"
                  value={form.displayName}
                  onChange={handle("displayName")}
                  required
                  data-testid="register-display-name"
                />
              </div>
            </div>
            <div>
              <label className="label">Password</label>
              <div className="relative">
                <input
                  className="input-field pr-12"
                  type={showPassword ? "text" : "password"}
                  placeholder="At least 6 characters"
                  value={form.password}
                  onChange={handle("password")}
                  required
                  minLength={6}
                  data-testid="register-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-[#6b628a] hover:text-violet-600"
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            {error && (
              <div
                className="text-sm text-pink-300 bg-pink-500/10 border border-pink-500/30 rounded-xl px-4 py-3"
                data-testid="register-error"
              >
                {error}
              </div>
            )}

            <button
              type="submit"
              className="btn-primary w-full text-base py-4"
              disabled={loading}
              data-testid="register-submit"
            >
              {loading ? "Creating account..." : "Create Account"}
            </button>
          </form>

          <div className="text-center mt-6 text-sm text-[var(--text-secondary)]">
            Already have an account?{" "}
            <Link
              to="/login"
              className="text-[var(--violet-bright)] font-semibold hover:text-pink-400 transition-colors"
              data-testid="go-to-login"
            >
              Sign in
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
