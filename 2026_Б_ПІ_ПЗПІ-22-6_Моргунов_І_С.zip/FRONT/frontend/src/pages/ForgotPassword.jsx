import React, { useState } from "react";
import { Link } from "react-router-dom";
import Logo from "../components/Logo";
import client, { formatApiError } from "../api";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState("idle");
  const [message, setMessage] = useState("");
  const [resetToken, setResetToken] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    setStatus("loading");
    try {
      const { data } = await client.post("/auth/forgot-password", { email });
      setStatus("sent");
      setMessage(data.message || "If that email exists, a reset link was sent.");
      if (data.resetToken) setResetToken(data.resetToken);
    } catch (err) {
      setStatus("error");
      setMessage(formatApiError(err));
    }
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center px-6 py-12">
      <div className="starfield" />
      <div className="relative z-10 w-full max-w-lg fade-up">
        <div className="flex flex-col items-center mb-8">
          <Logo size={72} />
          <h1 className="font-serif text-3xl tracking-wider text-white mt-4">FORGOT PASSWORD</h1>
          <p className="text-[var(--text-secondary)] text-sm mt-2">
            Enter your email and we'll send you a reset link.
          </p>
        </div>

        <div className="glass-card p-8">
          <form onSubmit={submit} className="space-y-5">
            <div>
              <label className="label">Email</label>
              <input
                className="input-field"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                data-testid="forgot-email"
              />
            </div>
            {message && (
              <div
                className={`text-sm rounded-xl px-4 py-3 ${
                  status === "error"
                    ? "text-pink-300 bg-pink-500/10 border border-pink-500/30"
                    : "text-emerald-300 bg-emerald-500/10 border border-emerald-500/30"
                }`}
                data-testid="forgot-message"
              >
                {message}
                {resetToken && (
                  <div className="mt-2 text-xs text-[var(--violet-soft)] break-all">
                    Dev token: <code>{resetToken}</code> — use on{" "}
                    <Link className="underline" to={`/reset-password?token=${resetToken}`}>
                      reset page
                    </Link>
                  </div>
                )}
              </div>
            )}
            <button
              type="submit"
              className="btn-primary w-full py-4"
              disabled={status === "loading"}
              data-testid="forgot-submit"
            >
              {status === "loading" ? "Sending..." : "Send reset link"}
            </button>
          </form>
          <div className="text-center mt-6 text-sm">
            <Link to="/login" className="text-[var(--violet-bright)] font-semibold hover:text-pink-400">
              Back to sign in
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
