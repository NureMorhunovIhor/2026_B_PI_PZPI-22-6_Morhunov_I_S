import React, { useEffect, useRef, useState } from "react";
import QRCode from "qrcode";
import {
  Camera,
  Check,
  Crown,
  Shield,
  ShieldCheck,
  ShieldOff,
  Sparkles,
  X,
} from "lucide-react";
import Navbar from "../components/Navbar";
import client, { formatApiError } from "../api";
import { useAuth } from "../AuthContext";
import { Link } from "react-router-dom";

const API_ORIGIN = "http://localhost:8080";

const resolveAvatarUrl = (url) => {
  if (!url) return "";

  if (url.startsWith("http")) {
    return url;
  }

  return `${API_ORIGIN}${url}`;
};

function Avatar({ url, fallback, size = 96 }) {
  const [broken, setBroken] = useState(false);

  if (url && !broken) {
    return (
      <img
        src={resolveAvatarUrl(url)}
        alt=""
        className="rounded-full object-cover"
        style={{ width: size, height: size }}
        onError={() => setBroken(true)}
      />
    );
  }

  return (
    <span
      className="avatar"
      style={{ width: size, height: size, fontSize: size * 0.35 }}
    >
      {fallback}
    </span>
  );
}


export default function Settings() {
  const { user, updateUser, refresh } = useAuth();
  const [displayName, setDisplayName] = useState(user?.displayName || "");
  const [username, setUsername] = useState(user?.username || "");
  const [email, setEmail] = useState(user?.email || "");
  const [avatarUrl, setAvatarUrl] = useState(user?.avatarUrl || "");
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileMsg, setProfileMsg] = useState("");
  const [profileErr, setProfileErr] = useState("");
  const fileRef = useRef(null);

  // 2FA state
  const [twoFA, setTwoFA] = useState({ enabled: false });
  const [setupData, setSetupData] = useState(null);
  const [qrImage, setQrImage] = useState("");
  const [code, setCode] = useState("");
  const [twoFAErr, setTwoFAErr] = useState("");
  const [twoFAMsg, setTwoFAMsg] = useState("");
  const [twoFALoading, setTwoFALoading] = useState(false);
  const [billing, setBilling] = useState(null);

  useEffect(() => {
  setDisplayName(user?.displayName || "");
  setUsername(user?.username || "");
  setEmail(user?.email || "");
  setAvatarUrl(user?.avatarUrl || "");
}, [user]);

  useEffect(() => {
  (async () => {
    try {
      const { data } = await client.get("/auth/2fa/status");
      setTwoFA({ enabled: data.enabled });
    } catch {
      // ignore
    }

    try {
      const { data } = await client.get("/billing/me");
      setBilling(data);
    } catch {
      // ignore
    }
  })();
}, []);

  const onPickFile = () => fileRef.current?.click();

  const onFileChange = async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (f.size > 1.5 * 1024 * 1024) {
      setProfileErr("Image must be smaller than 1.5MB.");
      return;
    }
    setProfileErr("");
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const dataUrl = reader.result;
        const { data } = await client.post("/users/me/avatar", { dataUrl });
        setAvatarUrl(data.avatarUrl);
        updateUser({ avatarUrl: data.avatarUrl });
        setProfileMsg("Avatar updated!");
        setTimeout(() => setProfileMsg(""), 2000);
      } catch (err) {
        setProfileErr(formatApiError(err));
      }
    };
    reader.readAsDataURL(f);
  };

  const saveProfile = async (e) => {
  e.preventDefault();
  setSavingProfile(true);
  setProfileErr("");

  try {
    const { data } = await client.patch("/users/me", {
      displayName,
      username,
      email,
    });

    updateUser({
      id: data.id,
      displayName: data.displayName,
      username: data.username,
      email: data.email,
      avatarUrl: data.avatarUrl,
    });

    setDisplayName(data.displayName || "");
    setUsername(data.username || "");
    setEmail(data.email || "");
    setAvatarUrl(data.avatarUrl || "");

    setProfileMsg("Profile saved!");
    setTimeout(() => setProfileMsg(""), 2000);
  } catch (err) {
    setProfileErr(formatApiError(err));
  } finally {
    setSavingProfile(false);
  }
};

  const startSetup = async () => {
  setTwoFAErr("");
  setTwoFAMsg("");
  setTwoFALoading(true);
  setQrImage("");

  try {
    const { data } = await client.post("/auth/2fa/setup");

    setSetupData(data);

    const qrSource =
      data?.qrCodeDataUrl ||
      data?.otpauthUrl ||
      data?.otpAuthUrl ||
      data?.qrCodeUrl;

    if (qrSource) {
      if (String(qrSource).startsWith("data:image")) {
        setQrImage(qrSource);
      } else {
        const qr = await QRCode.toDataURL(qrSource, {
          width: 220,
          margin: 2,
        });

        setQrImage(qr);
      }
    }
  } catch (err) {
    setTwoFAErr(formatApiError(err));
  } finally {
    setTwoFALoading(false);
  }
};

  const enable2fa = async (e) => {
    e.preventDefault();
    setTwoFAErr("");
    setTwoFALoading(true);
    try {
      await client.post("/auth/2fa/enable", { code });
      setTwoFA({ enabled: true });
      setSetupData(null);
      setCode("");
      setTwoFAMsg("Two-factor authentication enabled.");
      setTimeout(() => setTwoFAMsg(""), 3000);
    } catch (err) {
      setTwoFAErr(formatApiError(err));
    } finally {
      setTwoFALoading(false);
    }
  };

  const disable2fa = async (e) => {
    e.preventDefault();
    setTwoFAErr("");
    setTwoFALoading(true);
    try {
      await client.post("/auth/2fa/disable", { code });
      setTwoFA({ enabled: false });
      setCode("");
      setTwoFAMsg("Two-factor authentication disabled.");
      setTimeout(() => setTwoFAMsg(""), 3000);
    } catch (err) {
      setTwoFAErr(formatApiError(err));
    } finally {
      setTwoFALoading(false);
    }
  };

  const fallback = (user?.displayName || user?.username || "?")[0]?.toUpperCase();
  console.log("SETTINGS USER:", user);
  console.log("AVATAR URL:", avatarUrl);

  const cancelRenewal = async () => {
  try {
    const { data } = await client.post("/billing/cancel-renewal");
    setBilling(data);
  } catch (err) {
    setProfileErr(formatApiError(err));
  }
};
  return (
    <div className="relative min-h-screen">
      <div className="starfield" />
      <div className="relative z-10">
        <Navbar />
        <div className="max-w-3xl mx-auto px-6 py-10">
          <div className="fade-up mb-8">
            <h1 className="font-serif text-4xl md:text-5xl tracking-wide text-white mb-2">SETTINGS</h1>
            <p className="text-[var(--text-secondary)]">Manage your profile and security.</p>
          </div>

          {/* Profile */}
          <section className="glass-card p-7 mb-6 fade-up delay-1">
            <h2 className="font-serif text-xl tracking-wide mb-5">PROFILE</h2>
            <div className="flex flex-col sm:flex-row gap-6 items-start">
              <div className="flex flex-col items-center gap-3">
                <Avatar url={avatarUrl} fallback={fallback} size={96} />
                <button
                  onClick={onPickFile}
                  className="btn-ghost !py-2 !px-3 text-xs inline-flex items-center gap-1.5"
                  data-testid="avatar-upload-btn"
                  type="button"
                >
                  <Camera size={14} /> Change
                </button>
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={onFileChange}
                  data-testid="avatar-file-input"
                />
              </div>

              <form onSubmit={saveProfile} className="flex-1 space-y-4 w-full">
                <div>
                  <label className="label">Display name</label>
                  <input
                    className="input-field-dark"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    minLength={2}
                    required
                    data-testid="profile-display-name"
                  />
                </div>
                <div>
                  <label className="label">Username</label>
                  <input
                    className="input-field-dark"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    minLength={3}
                    required
                    data-testid="profile-username"
                  />
                </div>

                <div>
                  <label className="label">Email</label>
                  <input
                    className="input-field-dark"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    data-testid="profile-email"
                  />
                </div>
                {profileErr && (
                  <div className="text-sm text-pink-300 bg-pink-500/10 border border-pink-500/30 rounded-xl px-4 py-3">
                    {profileErr}
                  </div>
                )}
                {profileMsg && (
                  <div className="text-sm text-emerald-300 bg-emerald-500/10 border border-emerald-500/30 rounded-xl px-4 py-3" data-testid="profile-saved-msg">
                    {profileMsg}
                  </div>
                )}
                <button type="submit" className="btn-primary" disabled={savingProfile} data-testid="profile-save-btn">
                  {savingProfile ? "Saving..." : "Save changes"}
                </button>
              </form>
            </div>
          </section>

          {/* 2FA */}
          <section className="glass-card p-7 fade-up delay-2">
            <div className="flex items-start gap-3 mb-5">
              <div className="w-10 h-10 rounded-xl bg-violet-500/15 border border-violet-500/30 flex items-center justify-center flex-shrink-0">
                {twoFA.enabled ? <ShieldCheck size={18} className="text-emerald-400" /> : <Shield size={18} className="text-[var(--violet-soft)]" />}
              </div>
              <div className="flex-1">
                <h2 className="font-serif text-xl tracking-wide">TWO-FACTOR AUTHENTICATION</h2>
                <p className="text-sm text-[var(--text-secondary)] mt-1">
                  Add a TOTP code from your authenticator app on every sign-in.
                </p>
              </div>
              <span className={`badge ${twoFA.enabled ? "badge-public" : "badge-friends"}`} data-testid="2fa-status">
                {twoFA.enabled ? "Enabled" : "Disabled"}
              </span>
            </div>

            {twoFAErr && <div className="text-sm text-pink-300 bg-pink-500/10 border border-pink-500/30 rounded-xl px-4 py-3 mb-4" data-testid="2fa-error">{twoFAErr}</div>}
            {twoFAMsg && <div className="text-sm text-emerald-300 bg-emerald-500/10 border border-emerald-500/30 rounded-xl px-4 py-3 mb-4" data-testid="2fa-success">{twoFAMsg}</div>}

            {!twoFA.enabled && !setupData && (
              <button onClick={startSetup} className="btn-primary inline-flex items-center gap-2" disabled={twoFALoading} data-testid="2fa-setup-btn">
                <Shield size={15} /> {twoFALoading ? "Loading..." : "Set up 2FA"}
              </button>
            )}

            {!twoFA.enabled && setupData && (
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row gap-5 items-start">
                  <div className="bg-white p-3 rounded-xl">
                    {qrImage ? (
                      <img
                        src={qrImage}
                        alt="QR code"
                        className="w-44 h-44"
                        data-testid="2fa-qr-image"
                      />
                    ) : (
                      <div className="w-44 h-44 flex items-center justify-center text-sm text-gray-500">
                        QR loading...
                      </div>
                    )}
                  </div>
                </div>
                <form onSubmit={enable2fa} className="flex flex-col sm:flex-row gap-3 items-start">
                  <input
                    className="input-field-dark sm:w-44 text-center tracking-[0.4em] text-lg font-mono"
                    value={code}
                    onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                    placeholder="123456"
                    maxLength={6}
                    inputMode="numeric"
                    required
                    data-testid="2fa-code-input"
                  />
                  <button type="submit" className="btn-primary inline-flex items-center gap-2" disabled={twoFALoading || code.length !== 6} data-testid="2fa-enable-btn">
                    <Check size={15} /> Enable 2FA
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setSetupData(null);
                      setQrImage("");
                      setCode("");
                      setTwoFAErr("");
                    }}
                    className="btn-ghost inline-flex items-center gap-2"
                    data-testid="2fa-cancel-setup"
                  >
                    <X size={15} /> Cancel
                  </button>
                </form>
              </div>
            )}

            {twoFA.enabled && (
              <form onSubmit={disable2fa} className="flex flex-col sm:flex-row gap-3 items-start">
                <input
                  className="input-field-dark sm:w-44 text-center tracking-[0.4em] text-lg font-mono"
                  value={code}
                  onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                  placeholder="123456"
                  maxLength={6}
                  inputMode="numeric"
                  required
                  data-testid="2fa-disable-code"
                />
                <button type="submit" className="btn-ghost inline-flex items-center gap-2 !text-pink-300" disabled={twoFALoading || code.length !== 6} data-testid="2fa-disable-btn">
                  <ShieldOff size={15} /> Disable 2FA
                </button>
              </form>
            )}
          </section>
          {/* Subscription */}
          <section className="glass-card p-7 mt-6 fade-up delay-3">
            <div className="flex items-start gap-3 mb-5">
              <div className="w-10 h-10 rounded-xl bg-violet-500/15 border border-violet-500/30 flex items-center justify-center flex-shrink-0">
                {billing?.planId === "PRO" ? (
                  <Crown size={18} className="text-amber-300" />
                ) : (
                  <Sparkles size={18} className="text-[var(--violet-soft)]" />
                )}
              </div>

              <div className="flex-1">
                <h2 className="font-serif text-xl tracking-wide">SUBSCRIPTION</h2>
                <p className="text-sm text-[var(--text-secondary)] mt-1">
                  Manage your WatchTogether plan and limits.
                </p>
              </div>

              <span className="badge badge-public">
                {billing?.planName || billing?.planId || "Free"}
              </span>
            </div>

            <div className="grid sm:grid-cols-3 gap-3 mb-5">
              <div className="rounded-2xl bg-violet-500/10 border border-violet-500/20 p-4">
                <div className="text-xs text-[var(--text-muted)] uppercase tracking-widest">
                  Rooms
                </div>
                <div className="text-2xl font-bold text-white mt-1">
                  {billing?.maxRooms === 9999 ? "∞" : billing?.maxRooms ?? 3}
                </div>
              </div>

              <div className="rounded-2xl bg-violet-500/10 border border-violet-500/20 p-4">
                <div className="text-xs text-[var(--text-muted)] uppercase tracking-widest">
                  Participants
                </div>
                <div className="text-2xl font-bold text-white mt-1">
                  {billing?.maxParticipants ?? 5}
                </div>
              </div>

              <div className="rounded-2xl bg-violet-500/10 border border-violet-500/20 p-4">
                <div className="text-xs text-[var(--text-muted)] uppercase tracking-widest">
                  Queue
                </div>
                <div className="text-2xl font-bold text-white mt-1">
                  {billing?.maxQueueItems === 9999 ? "∞" : billing?.maxQueueItems ?? 10}
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <Link to="/pricing" className="btn-primary inline-flex items-center justify-center gap-2">
                <Sparkles size={15} /> Change plan
              </Link>

              {billing?.planId && billing.planId !== "FREE" && billing?.autoRenew && (
                <button
                  type="button"
                  onClick={cancelRenewal}
                  className="btn-ghost inline-flex items-center justify-center gap-2 !text-pink-300"
                >
                  <X size={15} /> Cancel renewal
                </button>
              )}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
