import React, { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import Logo from "../components/Logo";
import client, { formatApiError } from "../api";

export default function ResetPassword() {
  const [params] = useSearchParams();
  const nav = useNavigate();
  const [token, setToken] = useState(params.get("token") || "");
  const [newPassword, setNewPassword] = useState("");
  const [status, setStatus] = useState("idle");
  const [message, setMessage] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    setStatus("loading");
    try {
      await client.post("/auth/reset-password", { token, newPassword });
      setStatus("done");
      setMessage("Password reset successful! You can now sign in.");
      setTimeout(() => nav("/login"), 1500);
    } catch (err) {
      setStatus("error");
      setMessage(formatApiError(err));
    }
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center px-6 py-12">
      <div className="starfield" />
      <div className="relative z-10 w-full max-w-lg fade-up">
        <div className="flex flex-col items-center mb-8">
          <Logo size={72} />
          <h1 className="font-serif text-3xl tracking-wider text-white mt-4">RESET PASSWORD</h1>
        </div>

        <div className="glass-card p-8">
          <form onSubmit={submit} className="space-y-5">
            <div>
              <label className="label">Reset token</label>
              <input
                className="input-field"
                value={token}
                onChange={(e) => setToken(e.target.value)}
                required
                data-testid="reset-token"
              />
            </div>
            <div>
              <label className="label">New password</label>
              <input
                className="input-field"
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
                minLength={6}
                data-testid="reset-new-password"
              />
            </div>
            {message && (
              <div
                className={`text-sm rounded-xl px-4 py-3 ${
                  status === "error"
                    ? "text-pink-300 bg-pink-500/10 border border-pink-500/30"
                    : "text-emerald-300 bg-emerald-500/10 border border-emerald-500/30"
                }`}
              >
                {message}
              </div>
            )}
            <button type="submit" className="btn-primary w-full py-4" disabled={status === "loading"} data-testid="reset-submit">
              {status === "loading" ? "Resetting..." : "Reset password"}
            </button>
          </form>
          <div className="text-center mt-6 text-sm">
            <Link to="/login" className="text-[var(--violet-bright)] font-semibold hover:text-pink-400">
              Back to sign in
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
