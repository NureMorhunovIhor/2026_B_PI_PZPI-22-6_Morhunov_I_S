import React, { useEffect, useState } from "react";
import { Check, Search, UserMinus, UserPlus, X } from "lucide-react";
import Navbar from "../components/Navbar";
import client, { formatApiError } from "../api";

export default function Friends() {
  const [tab, setTab] = useState("friends");
  const [friends, setFriends] = useState([]);
  const [incoming, setIncoming] = useState([]);
  const [outgoing, setOutgoing] = useState([]);
  const [query, setQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [error, setError] = useState("");

  const load = async () => {
    try {
      const [f, i, o] = await Promise.all([
        client.get("/friends"),
        client.get("/friends/requests/incoming"),
        client.get("/friends/requests/outgoing"),
      ]);
      setFriends(f.data);
      setIncoming(i.data);
      setOutgoing(o.data);
    } catch (err) {
      setError(formatApiError(err));
    }
  };

  useEffect(() => {
    load();
  }, []);

  const doSearch = async (e) => {
    e.preventDefault();
    if (!query.trim()) {
      setSearchResults([]);
      return;
    }
    try {
      const { data } = await client.get(`/users/search?query=${encodeURIComponent(query)}`);
      setSearchResults(data);
    } catch (err) {
      setError(formatApiError(err));
    }
  };

  const sendRequest = async (userId) => {
    try {
      await client.post("/friends/request", { userId });
      await load();
      await doSearch({ preventDefault: () => {} });
    } catch (err) {
      setError(formatApiError(err));
    }
  };

  const respond = async (id, action) => {
    try {
      await client.post(`/friends/requests/${id}/${action}`);
      await load();
    } catch (err) {
      setError(formatApiError(err));
    }
  };

  const removeFriend = async (userId) => {
    try {
      await client.delete(`/friends/${userId}`);
      await load();
    } catch (err) {
      setError(formatApiError(err));
    }
  };

  return (
    <div className="relative min-h-screen">
      <div className="starfield" />
      <div className="relative z-10">
        <Navbar />
        <div className="max-w-5xl mx-auto px-6 py-10">
          <div className="fade-up mb-8">
            <h1 className="font-serif text-4xl md:text-5xl tracking-wide text-white mb-2">FRIENDS</h1>
            <p className="text-[var(--text-secondary)]">Find your crew. Invite them to movie nights.</p>
          </div>

          {/* Search */}
          <form onSubmit={doSearch} className="glass-card p-4 flex gap-3 mb-8 fade-up delay-1">
            <div className="relative flex-1">
              <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
              <input
                className="input-field-dark pl-11"
                placeholder="Search by username, display name, or email"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                data-testid="friends-search-input"
              />
            </div>
            <button className="btn-primary whitespace-nowrap" type="submit" data-testid="friends-search-btn">
              Search
            </button>
          </form>

          {searchResults.length > 0 && (
            <div className="mb-8">
              <h3 className="font-serif text-xl tracking-wide mb-3">SEARCH RESULTS</h3>
              <div className="space-y-2">
                {searchResults.map((u) => (
                  <div key={u.id} className="glass-card p-3 flex items-center gap-3" data-testid={`search-user-${u.id}`}>
                    <span className="avatar">{(u.displayName || u.username || "?")[0]?.toUpperCase()}</span>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-sm truncate">{u.displayName || u.username}</div>
                      <div className="text-xs text-[var(--text-muted)] truncate">@{u.username}</div>
                    </div>
                    {u.relationStatus === "ACCEPTED" ? (
                      <span className="badge badge-public">Friends</span>
                    ) : u.relationStatus === "PENDING" ? (
                      <span className="badge badge-friends">Pending</span>
                    ) : (
                      <button
                        onClick={() => sendRequest(u.id)}
                        className="btn-ghost !py-2 text-xs inline-flex items-center gap-1.5"
                        data-testid={`send-request-${u.id}`}
                      >
                        <UserPlus size={14} /> Add Friend
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tabs */}
          <div className="inline-flex p-1 glass-card rounded-full mb-6">
            {[
              { id: "friends", label: `Friends (${friends.length})` },
              { id: "incoming", label: `Incoming (${incoming.length})` },
              { id: "outgoing", label: `Sent (${outgoing.length})` },
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`px-5 py-2 rounded-full text-sm font-semibold transition ${
                  tab === t.id
                    ? "bg-gradient-to-r from-violet-500 to-purple-500 text-white"
                    : "text-[var(--text-secondary)] hover:text-white"
                }`}
                data-testid={`friends-tab-${t.id}`}
              >
                {t.label}
              </button>
            ))}
          </div>

          {error && <div className="text-sm text-pink-300 mb-4">{error}</div>}

          {tab === "friends" && (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {friends.length === 0 ? (
                <div className="col-span-full glass-card p-10 text-center text-[var(--text-secondary)]">
                  No friends yet. Find some above!
                </div>
              ) : (
                friends.map((f) => (
                  <div key={f.userId} className="glass-card glass-card-hover p-4" data-testid={`friend-${f.userId}`}>
                    <div className="flex items-center gap-3 mb-3">
                      <span className="avatar avatar-lg">{(f.displayName || f.username || "?")[0]?.toUpperCase()}</span>
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold truncate">{f.displayName || f.username}</div>
                        <div className="text-xs text-[var(--text-muted)] truncate">@{f.username}</div>
                      </div>
                    </div>
                    <button
                      onClick={() => removeFriend(f.userId)}
                      className="btn-ghost !py-2 text-xs w-full inline-flex items-center justify-center gap-1.5"
                      data-testid={`remove-friend-${f.userId}`}
                    >
                      <UserMinus size={13} /> Remove
                    </button>
                  </div>
                ))
              )}
            </div>
          )}

          {tab === "incoming" && (
            <div className="space-y-3">
              {incoming.length === 0 ? (
                <div className="glass-card p-10 text-center text-[var(--text-secondary)]">No incoming requests.</div>
              ) : (
                incoming.map((r) => (
                  <div key={r.friendshipId} className="glass-card p-4 flex items-center gap-3" data-testid={`incoming-${r.friendshipId}`}>
                    <span className="avatar">{(r.requesterDisplayName || r.requesterUsername)[0]?.toUpperCase()}</span>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold truncate">{r.requesterDisplayName || r.requesterUsername}</div>
                      <div className="text-xs text-[var(--text-muted)] truncate">@{r.requesterUsername}</div>
                    </div>
                    <button onClick={() => respond(r.friendshipId, "accept")} className="btn-primary !py-2 !px-3 text-xs" data-testid={`accept-${r.friendshipId}`}>
                      <Check size={14} />
                    </button>
                    <button onClick={() => respond(r.friendshipId, "decline")} className="btn-ghost !py-2 !px-3 text-xs" data-testid={`decline-${r.friendshipId}`}>
                      <X size={14} />
                    </button>
                  </div>
                ))
              )}
            </div>
          )}

          {tab === "outgoing" && (
            <div className="space-y-3">
              {outgoing.length === 0 ? (
                <div className="glass-card p-10 text-center text-[var(--text-secondary)]">No pending sent requests.</div>
              ) : (
                outgoing.map((r) => (
                  <div key={r.friendshipId} className="glass-card p-4 flex items-center gap-3" data-testid={`outgoing-${r.friendshipId}`}>
                    <span className="avatar">{(r.addresseeDisplayName || r.addresseeUsername)[0]?.toUpperCase()}</span>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold truncate">{r.addresseeDisplayName || r.addresseeUsername}</div>
                      <div className="text-xs text-[var(--text-muted)] truncate">@{r.addresseeUsername}</div>
                    </div>
                    <span className="badge badge-friends">Pending</span>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
