import React, { useEffect, useState } from "react";
import { Bell, Check, Heart, LogIn, UserPlus, Users, X } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import client, { formatApiError } from "../api";

const ICONS = {
  ROOM_INVITE: { Icon: LogIn, color: "text-[var(--violet-soft)]", bg: "bg-violet-500/15 border-violet-500/30" },
  FRIEND_REQUEST: { Icon: UserPlus, color: "text-pink-300", bg: "bg-pink-500/15 border-pink-500/30" },
  FRIEND_ACCEPTED: { Icon: Heart, color: "text-rose-300", bg: "bg-rose-500/15 border-rose-500/30" },
  DEFAULT: { Icon: Bell, color: "text-[var(--violet-soft)]", bg: "bg-violet-500/10 border-violet-500/20" },
};

export default function Notifications() {
  const nav = useNavigate();
  const [items, setItems] = useState([]);
  const [error, setError] = useState("");

  const load = async () => {
    try {
      const { data } = await client.get("/notifications");
      setItems(data);
    } catch (err) {
      setError(formatApiError(err));
    }
  };

  useEffect(() => {
    load();
  }, []);

  const markAll = async () => {
    try {
      await client.post("/notifications/read-all");
      load();
    } catch (err) {
      setError(formatApiError(err));
    }
  };

  const acceptRoomInvite = async (n) => {
  const roomCode = n.roomCode;

  if (!roomCode) {
    setError("Room code is missing in this invitation.");
    return;
  }

  try {
    await client.post(`/rooms/${roomCode}/accept-invite`);

    setItems((cur) => cur.filter((x) => x.id !== n.id));

    try {
      await client.delete(`/notifications/${n.id}`);
    } catch (deleteErr) {
      console.warn("Notification delete failed:", deleteErr?.response?.data || deleteErr);
    }
    nav(`/rooms/${roomCode}`);
  } catch (err) {
    setError(formatApiError(err));
  }
};

  const dismiss = async (n) => {
    try {
      await client.delete(`/notifications/${n.id}`);
      setItems((cur) => cur.filter((x) => x.id !== n.id));
    } catch (err) {
      setError(formatApiError(err));
    }
  };

  const goToFriends = () => nav("/friends");

  return (
    <div className="relative min-h-screen">
      <div className="starfield" />
      <div className="relative z-10">
        <Navbar />
        <div className="max-w-3xl mx-auto px-6 py-10">
          <div className="flex items-center justify-between mb-8 fade-up">
            <div>
              <h1 className="font-serif text-4xl tracking-wide text-white">NOTIFICATIONS</h1>
              <p className="text-[var(--text-secondary)] text-sm mt-1">Stay in the loop.</p>
            </div>
            <button onClick={markAll} className="btn-ghost inline-flex items-center gap-2" data-testid="notifs-mark-all">
              <Check size={14} /> Mark all read
            </button>
          </div>

          {error && <div className="text-sm text-pink-300 mb-4">{error}</div>}

          {items.length === 0 ? (
            <div className="glass-card p-12 text-center" data-testid="notifs-empty">
              <Bell size={28} className="mx-auto mb-3 text-[var(--violet-soft)]" />
              <p className="text-[var(--text-secondary)]">You're all caught up!</p>
            </div>
          ) : (
            <div className="space-y-3">
              {items.map((n) => {
                const meta = ICONS[n.type] || ICONS.DEFAULT;
                const { Icon } = meta;
                const isInvite = n.type === "ROOM_INVITE" && n.roomCode;
                const isFriendReq = n.type === "FRIEND_REQUEST";

                return (
                  <div
                    key={n.id}
                    className={`glass-card p-4 ${n.isRead ? "opacity-70" : ""}`}
                    data-testid={`notif-${n.id}`}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`w-10 h-10 rounded-xl border flex items-center justify-center flex-shrink-0 ${meta.bg}`}>
                        <Icon size={18} className={meta.color} />
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-semibold mb-0.5">{n.title}</div>
                        <div className="text-xs text-[var(--text-secondary)]">
                          {isInvite ? (
                            <>
                              Code: <code className="text-[var(--violet-soft)] font-mono">{n.roomCode}</code>
                            </>
                          ) : (
                            n.content
                          )}
                        </div>
                        <div className="text-[10px] text-[var(--text-muted)] mt-1">
                          {n.createdAt ? new Date(n.createdAt).toLocaleString() : ""}
                        </div>

                        {(isInvite || isFriendReq) && (
                          <div className="flex gap-2 mt-3">
                            {isInvite && (
                              <>
                                <button
                                  onClick={() => acceptRoomInvite(n)}
                                  className="btn-primary !py-2 !px-4 text-xs inline-flex items-center gap-1.5"
                                  data-testid={`notif-accept-${n.id}`}
                                >
                                  <Check size={13} /> Accept & join
                                </button>
                                <button
                                  onClick={() => dismiss(n)}
                                  className="btn-ghost !py-2 !px-4 text-xs inline-flex items-center gap-1.5"
                                  data-testid={`notif-decline-${n.id}`}
                                >
                                  <X size={13} /> Decline
                                </button>
                              </>
                            )}
                            {isFriendReq && (
                              <button
                                onClick={goToFriends}
                                className="btn-ghost !py-2 !px-4 text-xs inline-flex items-center gap-1.5"
                                data-testid={`notif-view-friend-${n.id}`}
                              >
                                <Users size={13} /> Open friend requests
                              </button>
                            )}
                          </div>
                        )}
                      </div>

                      {!isInvite && !isFriendReq && (
                        <button
                          onClick={() => dismiss(n)}
                          className="text-[var(--text-muted)] hover:text-pink-300 flex-shrink-0"
                          data-testid={`notif-dismiss-${n.id}`}
                          title="Dismiss"
                        >
                          <X size={16} />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
