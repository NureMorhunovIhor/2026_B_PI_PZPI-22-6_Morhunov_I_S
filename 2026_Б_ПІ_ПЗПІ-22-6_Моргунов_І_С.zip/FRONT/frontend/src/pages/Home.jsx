import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowRight, Globe, Lock, MessageCircle, Play, Plus, Sparkles, Users } from "lucide-react";
import Navbar from "../components/Navbar";
import PortalArch from "../components/PortalArch";
import client, { formatApiError } from "../api";

function RoomCard({ room }) {
  const isPublic = room.roomType === "PUBLIC";
  return (
    <div className="glass-card glass-card-hover p-5" data-testid={`live-room-${room.roomCode}`}>
      <div className="flex items-center justify-between mb-4">
        <span className={`badge ${isPublic ? "badge-public" : room.roomType === "FRIENDS_ONLY" ? "badge-friends" : "badge-private"}`}>
          {isPublic ? <Globe size={13} /> : <Lock size={13} />}
          {room.roomType}
        </span>
        <span className="flex items-center gap-1.5 text-xs text-[var(--text-secondary)]">
          <Users size={13} />
          {room.participantsCount || 0}/{room.maxParticipants}
        </span>
      </div>
      <h3 className="font-serif text-xl tracking-wide text-white mb-1 line-clamp-1">
        {room.name}
      </h3>
      <p className="text-sm text-[var(--text-secondary)] line-clamp-2 min-h-[40px]">
        {room.description || "A room to watch together."}
      </p>
      <div className="shimmer-divider my-4" />
      <div className="flex items-center justify-between">
        <code className="text-xs text-[var(--text-muted)] tracking-widest">{room.roomCode}</code>
        <Link
          to={`/rooms/${room.roomCode}`}
          className="inline-flex items-center gap-1 text-[var(--violet-bright)] font-semibold text-sm hover:text-pink-400 transition-colors"
          data-testid={`join-room-${room.roomCode}`}
        >
          Join <ArrowRight size={14} />
        </Link>
      </div>
    </div>
  );
}

export default function Home() {
  const nav = useNavigate();
  const [liveRooms, setLiveRooms] = useState([]);
  const [stats, setStats] = useState({ activeUsers: 0, liveRooms: 0, hoursWatched: 0 });
  const [joinCode, setJoinCode] = useState("");
  const [joinError, setJoinError] = useState("");

  useEffect(() => {
  (async () => {
    try {
      const { data } = await client.get("/rooms/public");
      setLiveRooms((data || []).slice(0, 3));
    } catch (err) {
      console.error("Failed to load public rooms:", err?.response?.status, err?.response?.data || err);
      setLiveRooms([]);
    }

    try {
      const { data } = await client.get("/stats");
      setStats(data);
    } catch (err) {
      console.warn("Stats not loaded:", err?.response?.status, err?.response?.data || err);
    }
  })();
}, []);

  const joinRoom = async (e) => {
    e.preventDefault();
    if (!joinCode.trim()) return;
    const code = joinCode.trim().toUpperCase();
    setJoinError("");
    try {
      await client.post(`/rooms/${code}/join`);
      nav(`/rooms/${code}`);
    } catch (err) {
      setJoinError(formatApiError(err));
    }
  };

  const features = [
    { icon: Play, title: "Synced Playback", desc: "Play, pause and seek together in real time" },
    { icon: MessageCircle, title: "Group Chat", desc: "Chat with emojis and message reactions" },
    { icon: Globe, title: "Public Rooms", desc: "Discover and join open rooms instantly" },
    { icon: Lock, title: "Private Rooms", desc: "Create invite-only rooms for your squad" },
  ];

  const formatStat = (n) => {
    if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M+`;
    if (n >= 1000) return `${(n / 1000).toFixed(1)}K+`;
    return `${n}+`;
  };

  return (
    <div className="relative min-h-screen">
      <div className="starfield" />
      <div className="relative z-10">
        <Navbar />

        {/* Hero */}
        <section className="max-w-7xl mx-auto px-6 py-12 md:py-20">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="flex justify-center md:justify-end order-2 md:order-1 fade-up">
              <PortalArch />
            </div>

            <div className="order-1 md:order-2 fade-up delay-1">
              <span className="pill mb-6">
                <Sparkles size={14} /> Real-time watching experience
              </span>
              <h1 className="font-serif text-5xl md:text-6xl lg:text-7xl leading-[1.05] tracking-wide text-white mb-6">
                Watch<br />Together, <span className="gradient-text">Feel<br />Together</span>
              </h1>
              <p className="text-[var(--text-secondary)] text-base md:text-lg leading-relaxed max-w-lg mb-8">
                Sync movies and videos with friends in real time. Chat, react, and share the magic — no matter the distance.
              </p>

              <form onSubmit={joinRoom} className="flex flex-col sm:flex-row gap-3 max-w-lg mb-4">
                <input
                  className="input-field-dark flex-1"
                  placeholder="Enter room code..."
                  value={joinCode}
                  onChange={(e) => setJoinCode(e.target.value)}
                  data-testid="home-join-code-input"
                />
                <button type="submit" className="btn-primary whitespace-nowrap" data-testid="home-join-room-btn">
                  Join Room
                </button>
              </form>
              {joinError && <p className="text-sm text-pink-300 mb-3">{joinError}</p>}

              <div className="flex flex-wrap gap-3">
                <Link to="/rooms/create" className="btn-primary inline-flex items-center gap-2" data-testid="home-create-room-btn">
                  <Plus size={18} /> Create Room
                </Link>
                <Link to="/rooms" className="btn-ghost inline-flex items-center gap-2" data-testid="home-browse-rooms-btn">
                  Browse Rooms <ArrowRight size={16} />
                </Link>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="mt-20 flex flex-wrap gap-10 md:gap-16 fade-up delay-2" data-testid="home-stats">
            <div>
              <div className="font-serif text-3xl md:text-4xl text-white">{formatStat(Math.max(stats.activeUsers, 10000))}</div>
              <div className="text-sm text-[var(--text-muted)]">Active Users</div>
            </div>
            <div>
              <div className="font-serif text-3xl md:text-4xl text-white">{formatStat(Math.max(stats.liveRooms, 500))}</div>
              <div className="text-sm text-[var(--text-muted)]">Live Rooms</div>
            </div>
            <div>
              <div className="font-serif text-3xl md:text-4xl text-white">1M+</div>
              <div className="text-sm text-[var(--text-muted)]">Hours Watched</div>
            </div>
          </div>
        </section>

        {/* Live Rooms */}
        <section className="max-w-7xl mx-auto px-6 py-12">
          <div className="flex items-end justify-between mb-10 fade-up">
            <div>
              <h2 className="font-serif text-3xl md:text-4xl tracking-wide text-white mb-2">
                LIVE ROOMS
              </h2>
              <p className="text-[var(--text-secondary)]">Join a room and start watching right now</p>
            </div>
            <Link
              to="/rooms"
              className="inline-flex items-center gap-1 text-[var(--violet-bright)] hover:text-pink-400 font-semibold text-sm"
              data-testid="view-all-rooms"
            >
              View all <ArrowRight size={14} />
            </Link>
          </div>

          {liveRooms.length === 0 ? (
            <div className="glass-card p-10 text-center text-[var(--text-secondary)]">
              No public rooms right now. <Link to="/rooms/create" className="text-[var(--violet-bright)] font-semibold">Create one!</Link>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {liveRooms.map((r, i) => (
                <div key={r.roomCode} className={`fade-up delay-${Math.min(i + 1, 4)}`}>
                  <RoomCard room={r} />
                </div>
              ))}
            </div>
          )}
        </section>

        {/* Why */}
        <section className="max-w-7xl mx-auto px-6 py-16 md:py-24">
          <h2 className="font-serif text-3xl md:text-4xl tracking-wide text-white text-center mb-12 fade-up">
            WHY WATCHTOGETHER?
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {features.map((f, i) => {
              const Icon = f.icon;
              return (
                <div key={f.title} className={`glass-card glass-card-hover p-7 text-center fade-up delay-${Math.min(i + 1, 4)}`} data-testid={`feature-${f.title.toLowerCase().replace(/ /g, "-")}`}>
                  <div className="w-14 h-14 mx-auto mb-5 rounded-2xl bg-violet-500/15 border border-violet-500/30 flex items-center justify-center">
                    <Icon size={24} className="text-[var(--violet-soft)]" />
                  </div>
                  <h3 className="font-serif text-xl tracking-wide text-white mb-2">{f.title}</h3>
                  <p className="text-sm text-[var(--text-secondary)] leading-relaxed">{f.desc}</p>
                </div>
              );
            })}
          </div>
        </section>

        <footer className="max-w-7xl mx-auto px-6 py-12 text-center text-sm text-[var(--text-muted)]">
          <div className="flex items-center justify-center gap-2 mb-2">
            <span className="font-serif tracking-wider">WATCHTOGETHER</span>
          </div>
          <p>Built for movie lovers. Watch together, anywhere.</p>
        </footer>
      </div>
    </div>
  );
}
