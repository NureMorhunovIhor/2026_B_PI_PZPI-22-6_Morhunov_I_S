import React, { useEffect, useRef, useState } from "react";
import Navbar from "../components/Navbar";
import client, { formatApiError } from "../api";
import { useAuth } from "../AuthContext";
import { Client } from "@stomp/stompjs";
import SockJS from "sockjs-client";
import { Send } from "lucide-react";


const FREE_STICKERS = [
  { id: "free_smile", emoji: "😊", label: "Smile" },
  { id: "free_laugh", emoji: "😂", label: "Laugh" },
  { id: "free_sad", emoji: "😢", label: "Sad" },
  { id: "free_angry", emoji: "😡", label: "Angry" },
  { id: "free_thumbsup", emoji: "👍", label: "Thumbs up" },
  { id: "free_heart", emoji: "❤️", label: "Heart" },
];

const PREMIUM_STICKERS = [
  { id: "premium_fire", emoji: "🔥", label: "Fire" },
  { id: "premium_popcorn", emoji: "🍿", label: "Popcorn" },
  { id: "premium_crown", emoji: "👑", label: "Crown" },
  { id: "premium_star", emoji: "⭐", label: "Star" },
  { id: "premium_rocket", emoji: "🚀", label: "Rocket" },
  { id: "premium_heart", emoji: "💖", label: "Premium Heart" },
];

const STICKER_EMOJI_BY_ID = {
  ...Object.fromEntries(FREE_STICKERS.map((s) => [s.id, s.emoji])),
  ...Object.fromEntries(PREMIUM_STICKERS.map((s) => [s.id, s.emoji])),
};

export default function Messages() {
  const { user } = useAuth();

  const [friends, setFriends] = useState([]);
  const [activeFriend, setActiveFriend] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [error, setError] = useState("");
  const [billing, setBilling] = useState(null);
  const [stickerPickerOpen, setStickerPickerOpen] = useState(false);
  const stompRef = useRef(null);


  const currentPlanId = String(
  billing?.currentPlan?.id ||
  billing?.plan?.id ||
  billing?.planId ||
  billing?.currentPlanId ||
  billing?.id ||
  user?.planId ||
  "FREE"
).toUpperCase();

  const hasPremium = currentPlanId !== "FREE";
  useEffect(() => {
    loadFriends();
    loadBilling();
  }, []);

  useEffect(() => {
    if (!activeFriend) return;
    loadMessages(activeFriend.id || activeFriend.userId);
  }, [activeFriend]);

  useEffect(() => {
    if (!user?.username) return;

    const socket = new SockJS("http://localhost:8080/ws");

    const stomp = new Client({
      webSocketFactory: () => socket,
      reconnectDelay: 3000,
      connectHeaders: {
        Authorization: `Bearer ${localStorage.getItem("accessToken")}`,
      },
      onConnect: () => {
        stomp.subscribe(`/topic/users/${user.username}/direct-messages`, (frame) => {
          const payload = JSON.parse(frame.body);

          if (payload.type === "direct.message") {
            const msg = payload.data;

            setMessages((current) => {
                if (!activeFriend) return current;

                const activeFriendId = activeFriend.id || activeFriend.userId;

                const belongsToCurrentChat =
                msg.senderId === activeFriendId ||
                msg.receiverId === activeFriendId;

                if (!belongsToCurrentChat) return current;

                const exists = current.some((m) => m.id === msg.id);
                return exists ? current : [...current, msg];
            });
            }
        });
      },
    });

    stomp.activate();
    stompRef.current = stomp;

    return () => stomp.deactivate();
  }, [user?.username, activeFriend]);

  const loadFriends = async () => {
    try {
      const { data } = await client.get("/friends");
      setFriends(data);
    } catch (err) {
      setError(formatApiError(err));
    }
  };

  const loadBilling = async () => {
  try {
    const { data } = await client.get("/billing/me");
    setBilling(data);
  } catch (err) {
    console.warn("Billing not loaded:", err?.response?.data || err);
    setBilling(null);
  }
};
  const loadMessages = async (friendId) => {
    try {
      const { data } = await client.get(`/direct-messages/${friendId}`);
      setMessages(data);
    } catch (err) {
      setError(formatApiError(err));
    }
  };

  const sendMessage = async (e) => {
    e.preventDefault();

    if (!activeFriend || !input.trim()) return;

    const friendId = activeFriend.id || activeFriend.userId;
    const content = input.trim();

    setInput("");

    try {
      const { data } = await client.post(`/direct-messages/${friendId}`, {
        content,
      });

      setMessages((current) => {
        const exists = current.some((m) => m.id === data.id);
        return exists ? current : [...current, data];
      });
    } catch (err) {
      setInput(content);
      setError(formatApiError(err));
    }
  };

  const sendSticker = async (stickerId) => {
  if (!activeFriend) return;

  const friendId = activeFriend.id || activeFriend.userId;

  try {
    const { data } = await client.post(`/direct-messages/${friendId}`, {
      content: stickerId,
      messageType: "STICKER",
    });

    setMessages((current) => {
      const exists = current.some((m) => m.id === data.id);
      return exists ? current : [...current, data];
    });

    setStickerPickerOpen(false);
  } catch (err) {
    setError(formatApiError(err));
  }
};
  return (
    <div className="relative min-h-screen">
      <div className="starfield" />
      <div className="relative z-10">
        <Navbar />

        <div className="max-w-7xl mx-auto px-6 py-8">
          <h1 className="font-serif text-3xl text-white mb-6">
            Messages
          </h1>

          {error && (
            <div className="mb-4 text-sm text-pink-300 bg-pink-500/10 border border-pink-500/30 rounded-xl px-4 py-3">
              {error}
            </div>
          )}

          <div className="grid md:grid-cols-[320px_1fr] gap-5">
            <div className="glass-card p-4 h-[650px] overflow-y-auto">
              <h2 className="font-serif text-lg mb-3">Friends</h2>

              {friends.length === 0 ? (
                <p className="text-sm text-[var(--text-secondary)]">
                  No friends yet.
                </p>
              ) : (
                <div className="space-y-2">
                  {friends.map((f) => {
                    const id = f.id || f.userId;
                    const active = (activeFriend?.id || activeFriend?.userId) === id;

                    return (
                      <button
                        key={id}
                        onClick={() => setActiveFriend(f)}
                        className={`w-full text-left p-3 rounded-xl border transition ${
                          active
                            ? "bg-violet-500/20 border-violet-400/60"
                            : "bg-violet-500/5 border-violet-500/10 hover:border-violet-500/40"
                        }`}
                      >
                        <div className="font-semibold text-white">
                          {f.displayName || f.username}
                        </div>
                        <div className="text-xs text-[var(--text-muted)]">
                          @{f.username}
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="glass-card h-[650px] flex flex-col">
              {!activeFriend ? (
                <div className="flex-1 flex items-center justify-center text-[var(--text-secondary)]">
                  Select a friend to start chatting.
                </div>
              ) : (
                <>
                  <div className="p-4 border-b border-violet-500/15">
                    <div className="font-serif text-xl text-white">
                      {activeFriend.displayName || activeFriend.username}
                    </div>
                    <div className="text-xs text-[var(--text-muted)]">
                      @{activeFriend.username}
                    </div>
                  </div>

                  <div className="flex-1 overflow-y-auto p-4 space-y-3">
                    {messages.map((m) => {
                        const mine = m.senderId === user?.id;
                        const isSticker = m.messageType === "STICKER";
                        const stickerEmoji = STICKER_EMOJI_BY_ID[m.content] || "❓";

                        return (
                        <div
                            key={m.id}
                            className={`max-w-[75%] rounded-2xl text-sm ${
                            mine ? "ml-auto" : ""
                            } ${
                            isSticker
                                ? "bg-transparent px-1 py-1"
                                : mine
                                ? "bg-violet-500 text-white px-4 py-2"
                                : "bg-violet-500/10 text-white px-4 py-2"
                            }`}
                        >
                            {isSticker ? (
                            <div
                                className={`text-5xl leading-none ${
                                mine ? "text-right" : "text-left"
                                }`}
                                title={m.content}
                            >
                                {stickerEmoji}
                            </div>
                            ) : (
                            m.content
                            )}
                        </div>
                        );
                    })}
                    </div>

                  <form
                    onSubmit={sendMessage}
                    className="relative p-4 border-t border-violet-500/15 flex gap-2"
                    >
                    {stickerPickerOpen && (
                        <div className="absolute bottom-[76px] left-4 w-80 max-w-[calc(100%-2rem)] rounded-2xl border border-violet-500/20 bg-[#120b24]/95 backdrop-blur-xl shadow-2xl p-3 z-20">
                        <div className="flex items-center justify-between mb-2">
                            <div className="text-xs uppercase tracking-widest text-[var(--text-muted)]">
                            Stickers
                            </div>

                            <button
                            type="button"
                            onClick={() => setStickerPickerOpen(false)}
                            className="text-xs text-[var(--text-muted)] hover:text-white"
                            >
                            Close
                            </button>
                        </div>

                        <div className="text-[10px] uppercase tracking-widest text-[var(--violet-soft)] mb-2">
                            Free
                        </div>

                        <div className="grid grid-cols-6 gap-2 mb-4">
                            {FREE_STICKERS.map((s) => (
                            <button
                                key={s.id}
                                type="button"
                                title={s.label}
                                onClick={() => sendSticker(s.id)}
                                className="h-10 rounded-xl bg-violet-500/10 hover:bg-violet-500/20 border border-violet-500/10 text-2xl transition"
                            >
                                {s.emoji}
                            </button>
                            ))}
                        </div>

                        <div className="flex items-center justify-between mb-2">
                            <div className="text-[10px] uppercase tracking-widest text-amber-200">
                            Premium
                            </div>

                            {!hasPremium && (
                            <span className="text-[10px] text-[var(--text-muted)]">
                                Premium / Pro only
                            </span>
                            )}
                        </div>

                        <div className="grid grid-cols-6 gap-2">
                            {PREMIUM_STICKERS.map((s) => (
                            <button
                                key={s.id}
                                type="button"
                                title={s.label}
                                onClick={() => {
                                if (!hasPremium) {
                                    setError("Premium stickers are available only for Premium and Pro users");
                                    return;
                                }

                                sendSticker(s.id);
                                }}
                                className={`h-10 rounded-xl border text-2xl transition ${
                                hasPremium
                                    ? "bg-amber-500/10 hover:bg-amber-500/20 border-amber-400/20"
                                    : "bg-zinc-700/20 border-zinc-600/20 opacity-50 cursor-not-allowed"
                                }`}
                            >
                                {s.emoji}
                            </button>
                            ))}
                        </div>
                        </div>
                    )}

                    <button
                        type="button"
                        className="btn-ghost px-4"
                        onClick={() => setStickerPickerOpen((v) => !v)}
                        title="Stickers"
                    >
                        😊
                    </button>

                    <input
                        className="input-field-dark flex-1"
                        placeholder="Write a message..."
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                    />

                    <button type="submit" className="btn-primary px-4">
                        <Send size={16} />
                    </button>
                    </form>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}