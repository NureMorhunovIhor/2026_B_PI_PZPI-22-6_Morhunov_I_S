import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowRight, Check, Crown, Sparkles, Star, X, Zap } from "lucide-react";
import Navbar from "../components/Navbar";
import client, { formatApiError } from "../api";
import { useAuth } from "../AuthContext";

const PLAN_VISUALS = {
  FREE: { Icon: Sparkles, accent: "from-slate-400 to-slate-500", ring: "ring-slate-500/30" },
  PREMIUM: { Icon: Star, accent: "from-violet-500 to-purple-500", ring: "ring-violet-500/60", featured: true },
  PRO: { Icon: Crown, accent: "from-amber-400 to-pink-500", ring: "ring-amber-500/40" },
};


function PayMockDialog({ plan, cycle, amount, onClose, onSuccess }) {
  const [stage, setStage] = useState("review"); 
  const [error, setError] = useState("");

  const pay = async () => {
    setStage("processing");
    try {
      const { data: order } = await client.post("/billing/checkout", { planId: plan.id, cycle });
      // Simulate the PayPal redirect/popup with a small delay
      await new Promise((r) => setTimeout(r, 1100));
      const { data: status } = await client.post("/billing/capture", { orderId: order.orderId });
      setStage("done");
      setTimeout(() => onSuccess(status), 900);
    } catch (err) {
      setStage("review");
      setError(formatApiError(err));
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4" onClick={onClose}>
      <div
        className="glass-card w-full max-w-md overflow-hidden"
        onClick={(e) => e.stopPropagation()}
        data-testid="paypal-mock-dialog"
      >
        <div className="bg-gradient-to-br from-[#0070ba] to-[#003087] p-6 text-white relative">
          <button onClick={onClose} className="absolute top-3 right-3 text-white/70 hover:text-white" data-testid="pay-close">
            <X size={18} />
          </button>
          <div className="text-2xl font-bold italic tracking-tight">PayPal</div>
          <div className="text-xs opacity-80 mt-0.5">Sandbox / Mock checkout</div>
        </div>
        <div className="p-6 space-y-4">
          {stage === "review" && (
            <>
              <div>
                <div className="text-xs uppercase tracking-widest text-[var(--text-muted)] mb-1">Subscribing to</div>
                <div className="font-serif text-2xl tracking-wide">{plan.name}</div>
                <div className="text-sm text-[var(--text-secondary)]">
                  {cycle === "YEARLY" ? "Billed yearly" : "Billed monthly"}
                </div>
              </div>
              <div className="flex items-baseline gap-2 border-y border-violet-500/15 py-4">
                <div className="text-4xl font-bold gradient-text">${amount.toFixed(2)}</div>
                <div className="text-sm text-[var(--text-muted)]">USD / {cycle === "YEARLY" ? "year" : "month"}</div>
              </div>
              <p className="text-xs text-[var(--text-muted)]">
                This is a <strong className="text-[var(--violet-soft)]">mock</strong> checkout — no real card will be charged.
                Wire real PayPal sandbox by setting <code>PAYPAL_MODE=sandbox</code> + credentials in backend <code>.env</code>.
              </p>
              {error && (
                <div className="text-sm text-pink-300 bg-pink-500/10 border border-pink-500/30 rounded-xl px-3 py-2">
                  {error}
                </div>
              )}
              <button onClick={pay} className="btn-primary w-full !bg-gradient-to-r !from-[#ffc439] !to-[#f4a000] !text-[#0f1437]" data-testid="pay-confirm">
                Pay with PayPal
              </button>
              <button onClick={onClose} className="w-full text-xs text-[var(--text-muted)] hover:text-white">
                Cancel
              </button>
            </>
          )}
          {stage === "processing" && (
            <div className="py-10 text-center">
              <div className="w-12 h-12 rounded-full border-4 border-violet-500 border-t-transparent mx-auto mb-4 animate-spin" />
              <div className="font-semibold">Confirming payment...</div>
            </div>
          )}
          {stage === "done" && (
            <div className="py-10 text-center" data-testid="pay-success">
              <div className="w-14 h-14 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center mx-auto mb-4">
                <Check size={28} className="text-emerald-400" />
              </div>
              <div className="font-serif text-xl tracking-wide mb-1">Welcome to {plan.name}!</div>
              <div className="text-sm text-[var(--text-secondary)]">Enjoy your upgraded watch parties.</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function Pricing() {
  const nav = useNavigate();
  const { user, refresh } = useAuth();
  const [plans, setPlans] = useState([]);
  const [billing, setBilling] = useState(null);
  const [cycle, setCycle] = useState("MONTHLY");
  const [payFor, setPayFor] = useState(null);

  const startPaypalCheckout = async (plan) => {
  try {
    const { data } = await client.post("/billing/checkout", {
      planId: plan.id,
      cycle: cycle,
    });

    if (data.approveUrl) {
      window.location.href = data.approveUrl;
      return;
    }

    throw new Error("PayPal approve URL was not returned");
  } catch (err) {
    console.error("PayPal checkout failed:", err);
    alert(formatApiError(err));
  }
};
  useEffect(() => {
    (async () => {
      try {
        const [p, b] = await Promise.all([
          client.get("/billing/plans"),
          user ? client.get("/billing/me") : Promise.resolve({ data: null }),
        ]);
        setPlans(p.data);
        setBilling(b.data);
      } catch {
        // ignore
      }
    })();
  }, [user]);

  const yearlySavingsPct = 20;

  return (
    <div className="relative min-h-screen">
      <div className="starfield" />
      <div className="relative z-10">
        <Navbar />
        <div className="max-w-6xl mx-auto px-6 py-12">
          <div className="text-center mb-10 fade-up">
            <span className="pill mb-5"><Sparkles size={14} /> Watch together, in style</span>
            <h1 className="font-serif text-4xl md:text-6xl tracking-wide text-white mb-4">
              CHOOSE YOUR <span className="gradient-text">CINEMA</span>
            </h1>
            <p className="text-[var(--text-secondary)] max-w-xl mx-auto">
              Free forever for casual movie nights. Upgrade when your crew gets bigger.
            </p>
          </div>

          {/* Cycle toggle */}
          <div className="flex justify-center mb-10 fade-up delay-1">
            <div className="inline-flex p-1 glass-card rounded-full">
              <button
                onClick={() => setCycle("MONTHLY")}
                className={`px-6 py-2 rounded-full text-sm font-semibold transition ${
                  cycle === "MONTHLY"
                    ? "bg-gradient-to-r from-violet-500 to-purple-500 text-white shadow-lg shadow-violet-500/30"
                    : "text-[var(--text-secondary)] hover:text-white"
                }`}
                data-testid="cycle-monthly"
              >
                Monthly
              </button>
              <button
                onClick={() => setCycle("YEARLY")}
                className={`px-6 py-2 rounded-full text-sm font-semibold transition inline-flex items-center gap-2 ${
                  cycle === "YEARLY"
                    ? "bg-gradient-to-r from-violet-500 to-purple-500 text-white shadow-lg shadow-violet-500/30"
                    : "text-[var(--text-secondary)] hover:text-white"
                }`}
                data-testid="cycle-yearly"
              >
                Yearly
                <span className="text-[10px] bg-emerald-500/30 text-emerald-200 px-2 py-0.5 rounded-full font-bold">
                  −{yearlySavingsPct}%
                </span>
              </button>
            </div>
          </div>

          {/* Cards */}
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            {plans.map((plan, i) => {
              const visual = PLAN_VISUALS[plan.id] || PLAN_VISUALS.FREE;
              const Icon = visual.Icon;
              const price = cycle === "YEARLY" ? plan.priceYearly : plan.priceMonthly;
              const monthlyEquivalent = cycle === "YEARLY" && plan.priceYearly > 0 ? plan.priceYearly / 12 : null;
              const isCurrent = billing?.planId === plan.id;
              const isPaidPlan = plan.id !== "FREE";
              return (
                <div
                  key={plan.id}
                  className={`relative glass-card p-7 flex flex-col fade-up delay-${Math.min(i + 1, 3)} ${
                    visual.featured ? `ring-2 ${visual.ring} scale-[1.02]` : ""
                  }`}
                  data-testid={`plan-card-${plan.id}`}
                >
                  {visual.featured && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-violet-500 to-purple-500 text-white text-[10px] font-bold tracking-widest uppercase px-3 py-1 rounded-full">
                      Most popular
                    </div>
                  )}
                  <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${visual.accent} flex items-center justify-center mb-5 shadow-lg`}>
                    <Icon size={22} className="text-white" />
                  </div>
                  <h3 className="font-serif text-2xl tracking-wide text-white">{plan.name}</h3>
                  <p className="text-sm text-[var(--text-secondary)] mb-5 min-h-[40px]">{plan.tagline}</p>

                  <div className="flex items-baseline gap-2 mb-1">
                    <span className="text-5xl font-bold gradient-text">${price.toFixed(price % 1 === 0 ? 0 : 2)}</span>
                    {isPaidPlan && (
                      <span className="text-sm text-[var(--text-muted)]">/ {cycle === "YEARLY" ? "year" : "month"}</span>
                    )}
                  </div>
                  {monthlyEquivalent != null && (
                    <p className="text-xs text-emerald-300 mb-5">
                      ≈ ${monthlyEquivalent.toFixed(2)}/mo · saves ${(plan.priceMonthly * 12 - plan.priceYearly).toFixed(2)}
                    </p>
                  )}
                  {!monthlyEquivalent && <div className="mb-5" />}

                  <ul className="space-y-2 mb-7 flex-1">
                    {plan.perks.map((p) => (
                      <li key={p} className="flex items-start gap-2 text-sm text-[var(--text-secondary)]">
                        <Check size={14} className="text-[var(--violet-soft)] mt-0.5 flex-shrink-0" />
                        <span>{p}</span>
                      </li>
                    ))}
                  </ul>

                  {isCurrent ? (
                    <button className="btn-ghost w-full inline-flex items-center justify-center gap-2 cursor-default" disabled data-testid={`plan-current-${plan.id}`}>
                      <Check size={15} /> Your current plan
                    </button>
                  ) : !isPaidPlan ? (
                    <button
                      onClick={() => user ? null : nav("/register")}
                      disabled={!!user}
                      className="btn-ghost w-full inline-flex items-center justify-center gap-2"
                      data-testid={`plan-cta-${plan.id}`}
                    >
                      {user ? "Default plan" : (<><ArrowRight size={15} /> Get started</>)}
                    </button>
                  ) : (
                    <button
                      onClick={() => user ? startPaypalCheckout(plan) : nav("/login")}
                      className={`btn-primary w-full inline-flex items-center justify-center gap-2 ${visual.featured ? "" : ""}`}
                      data-testid={`plan-cta-${plan.id}`}
                    >
                      <Zap size={15} /> {user ? `Upgrade to ${plan.name}` : "Sign in to upgrade"}
                    </button>
                  )}
                </div>
              );
            })}
          </div>

          {billing && billing.planId !== "FREE" && (
            <div className="glass-card p-5 max-w-xl mx-auto fade-up delay-3 flex items-center gap-4">
              <Crown size={20} className="text-yellow-400" />
              <div className="flex-1">
                <div className="text-sm font-semibold">You're on {billing.planName}</div>
                <div className="text-xs text-[var(--text-muted)]">
                  Renews {billing.expiresAt ? new Date(billing.expiresAt).toLocaleDateString() : "—"} ·{" "}
                  {billing.autoRenew ? "Auto-renew on" : "Auto-renew off"}
                </div>
              </div>
              <button
                onClick={async () => {
                  try {
                    const { data } = await client.post("/billing/cancel-renewal");
                    setBilling(data);
                  } catch {
                    // ignore
                  }
                }}
                className="btn-ghost !py-2 text-xs"
                data-testid="cancel-renew"
              >
                {billing.autoRenew ? "Cancel renewal" : "Renewal cancelled"}
              </button>
            </div>
          )}
        </div>
      </div>

      {payFor && (
        <PayMockDialog
          plan={payFor}
          cycle={cycle}
          amount={cycle === "YEARLY" ? payFor.priceYearly : payFor.priceMonthly}
          onClose={() => setPayFor(null)}
          onSuccess={async (status) => {
            setBilling(status);
            setPayFor(null);
            await refresh();
          }}
        />
      )}
    </div>
  );
}
