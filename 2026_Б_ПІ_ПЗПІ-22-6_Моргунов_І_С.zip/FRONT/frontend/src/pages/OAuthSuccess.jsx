import React, { useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useAuth } from "../AuthContext";

export default function OAuthSuccess() {
  const [params] = useSearchParams();
  const nav = useNavigate();
  const { refresh } = useAuth();

  useEffect(() => {
    const accessToken = params.get("accessToken");
    const refreshToken = params.get("refreshToken");

    if (!accessToken || !refreshToken) {
      nav("/login", { replace: true });
      return;
    }

    localStorage.setItem("wt_access_token", accessToken);
    localStorage.setItem("wt_refresh_token", refreshToken);

    (async () => {
      await refresh();
      nav("/", { replace: true });
    })();
  }, [params, refresh, nav]);

  return (
    <div className="relative min-h-screen flex items-center justify-center">
      <div className="starfield" />
      <div className="relative z-10 glass-card p-8 text-center">
        <h1 className="font-serif text-2xl text-white mb-2">Signing you in...</h1>
        <p className="text-[var(--text-secondary)]">Please wait.</p>
      </div>
    </div>
  );
}