import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Eye, EyeOff } from "lucide-react";
import Logo from "../components/Logo";
import { useAuth } from "../AuthContext";
import { formatApiError } from "../api";

export default function Login() {
  const { login, verifyTwoFactor } = useAuth();
  const nav = useNavigate();
  const [loginId, setLoginId] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [tempToken, setTempToken] = useState(null);
  const [code2fa, setCode2fa] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await login(loginId, password);
      if (res?.requiresTwoFactor) {
        setTempToken(res.tempToken);
      } else {
        nav("/");
      }
    } catch (err) {
      setError(formatApiError(err));
    } finally {
      setLoading(false);
    }
  };

  const submit2fa = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await verifyTwoFactor(tempToken, code2fa, loginId);
      nav("/", { replace: true });
    } catch (err) {
      setError(formatApiError(err));
    } finally {
      setLoading(false);
    }
  };

  const API_BASE_URL =
  process.env.REACT_APP_API_URL || "http://localhost:8080/api";

const BACKEND_BASE_URL = API_BASE_URL.replace("/api", "");

const loginWithGoogle = () => {
  window.location.href = `${BACKEND_BASE_URL}/oauth2/authorization/google`;
};

const loginWithFacebook = () => {
  window.location.href = `${BACKEND_BASE_URL}/oauth2/authorization/facebook`;
};
  return (
    <div className="relative min-h-screen flex items-center justify-center px-6 py-12">
      <div className="starfield" />
      <div className="relative z-10 w-full max-w-lg fade-up">
        <div className="flex flex-col items-center mb-8">
          <div className="mb-5">
            <Logo size={88} />
          </div>
          <h1 className="font-serif text-4xl md:text-5xl tracking-wider text-white mb-2">
            WATCHTOGETHER
          </h1>
          <p className="text-[var(--text-secondary)] text-sm">Watch with friends in real time</p>
        </div>

        <div className="glass-card p-8 md:p-10 fade-up delay-1">
          <h2 className="font-serif text-2xl md:text-3xl text-center tracking-widest text-white mb-8">
            {tempToken ? "TWO-FACTOR CHECK" : "WELCOME BACK"}
          </h2>

          {tempToken ? (
            <form onSubmit={submit2fa} className="space-y-5">
              <p className="text-sm text-[var(--text-secondary)] text-center">
                Enter the 6-digit code from your authenticator app.
              </p>
              <div>
                <label className="label">Authentication code</label>
                <input
                  className="input-field text-center tracking-[0.5em] text-xl font-mono"
                  value={code2fa}
                  onChange={(e) => setCode2fa(e.target.value.replace(/\D/g, "").slice(0, 6))}
                  required
                  maxLength={6}
                  inputMode="numeric"
                  autoFocus
                  data-testid="login-2fa-code"
                />
              </div>
              {error && (
                <div className="text-sm text-pink-300 bg-pink-500/10 border border-pink-500/30 rounded-xl px-4 py-3" data-testid="login-2fa-error">
                  {error}
                </div>
              )}
              <button type="submit" className="btn-primary w-full text-base py-4" disabled={loading || code2fa.length !== 6} data-testid="login-2fa-submit">
                {loading ? "Verifying..." : "Verify code"}
              </button>
              <button type="button" onClick={() => { setTempToken(null); setCode2fa(""); setError(""); }} className="w-full text-sm text-[var(--violet-bright)] hover:text-pink-400 mt-2" data-testid="login-2fa-back">
                Use different account
              </button>
            </form>
          ) : (
            <form onSubmit={submit} className="space-y-5">
            <div>
              <label className="label">Email or Username</label>
              <input
                className="input-field"
                placeholder="you@example.com"
                value={loginId}
                onChange={(e) => setLoginId(e.target.value)}
                required
                data-testid="login-identifier"
              />
            </div>
            <div>
              <label className="label">Password</label>
              <div className="relative">
                <input
                  className="input-field pr-12"
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  data-testid="login-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-[#6b628a] hover:text-violet-600"
                  data-testid="toggle-password"
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <div className="text-right">
              <Link
                to="/forgot-password"
                className="text-sm text-[var(--violet-bright)] font-semibold hover:text-pink-400 transition-colors"
                data-testid="forgot-password-link"
              >
                Forgot password?
              </Link>
            </div>

            {error && (
              <div
                className="text-sm text-pink-300 bg-pink-500/10 border border-pink-500/30 rounded-xl px-4 py-3"
                data-testid="login-error"
              >
                {error}
              </div>
            )}

            <button
              type="submit"
              className="btn-primary w-full text-base py-4"
              disabled={loading}
              data-testid="login-submit"
            >
              {loading ? "Signing in..." : "Sign In"}
            </button>
              <div className="flex items-center gap-3 my-5">
              <div className="h-px flex-1 bg-violet-500/20" />
              <span className="text-xs text-[var(--text-muted)]">OR</span>
              <div className="h-px flex-1 bg-violet-500/20" />
            </div>

            <div className="space-y-3">
              <button
                type="button"
                onClick={loginWithGoogle}
                className="btn-ghost w-full"
              >
                Continue with Google
              </button>

              <button
                type="button"
                onClick={loginWithFacebook}
                className="btn-ghost w-full"
              >
                Continue with Facebook
              </button>
            </div>
          </form>
          )}

          {!tempToken && (
          <div className="text-center mt-6 text-sm text-[var(--text-secondary)]">
            Don't have an account?{" "}
            <Link
              to="/register"
              className="text-[var(--violet-bright)] font-semibold hover:text-pink-400 transition-colors"
              data-testid="go-to-register"
            >
              Create one
            </Link>
          </div>
          )}
        </div>

        <p className="text-center text-xs text-[var(--text-muted)] mt-6">
          Demo: <code className="text-[var(--violet-soft)]">demo</code> / <code className="text-[var(--violet-soft)]">demo1234</code>
        </p>
      </div>
    </div>
  );
}
