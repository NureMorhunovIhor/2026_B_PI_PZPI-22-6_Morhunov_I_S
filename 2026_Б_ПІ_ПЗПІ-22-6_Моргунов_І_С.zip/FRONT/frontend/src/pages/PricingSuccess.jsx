import React, { useEffect, useState } from "react";
import { Check } from "lucide-react";
import { Link, useSearchParams } from "react-router-dom";
import Navbar from "../components/Navbar";
import client, { formatApiError } from "../api";
import { useAuth } from "../AuthContext";

export default function PricingSuccess() {
  const [params] = useSearchParams();
  const { refresh } = useAuth();
  const [status, setStatus] = useState("processing");
  const [error, setError] = useState("");

  useEffect(() => {
    const orderId = params.get("token");

    if (!orderId) {
      setStatus("error");
      setError("PayPal order token was not returned.");
      return;
    }

    (async () => {
      try {
        await client.post("/billing/capture", { orderId });
        await refresh?.();
        setStatus("done");
      } catch (err) {
        setStatus("error");
        setError(formatApiError(err));
      }
    })();
  }, [params, refresh]);

  return (
    <div className="relative min-h-screen">
      <div className="starfield" />
      <div className="relative z-10">
        <Navbar />

        <div className="max-w-2xl mx-auto px-6 py-20 text-center">
          <div className="glass-card p-10">
            {status === "processing" && (
              <>
                <div className="w-12 h-12 rounded-full border-4 border-violet-500 border-t-transparent mx-auto mb-4 animate-spin" />
                <h1 className="font-serif text-3xl mb-2">Confirming payment...</h1>
                <p className="text-[var(--text-secondary)]">
                  Please wait while PayPal confirms your subscription.
                </p>
              </>
            )}

            {status === "done" && (
              <>
                <div className="w-14 h-14 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center mx-auto mb-4">
                  <Check size={28} className="text-emerald-400" />
                </div>
                <h1 className="font-serif text-3xl mb-2">Payment successful!</h1>
                <p className="text-[var(--text-secondary)] mb-6">
                  Your WatchTogether plan has been updated.
                </p>
                <Link to="/pricing" className="btn-primary">
                  Back to pricing
                </Link>
              </>
            )}

            {status === "error" && (
              <>
                <h1 className="font-serif text-3xl mb-2 text-pink-300">Payment failed</h1>
                <p className="text-[var(--text-secondary)] mb-6">{error}</p>
                <Link to="/pricing" className="btn-primary">
                  Try again
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}