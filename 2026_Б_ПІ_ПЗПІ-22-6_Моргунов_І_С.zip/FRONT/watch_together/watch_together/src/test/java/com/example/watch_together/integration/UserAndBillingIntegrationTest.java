package com.example.watch_together.integration;

import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;

import java.util.Map;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class UserAndBillingIntegrationTest extends AbstractIntegrationTest {

    @Test
    void authMeReturnsCurrentUserProfileAndFreePlan() throws Exception {
        TestAccount account = registerAccount("profileuser", "profile@example.com");

        mockMvc.perform(get("/api/auth/me")
                        .header("Authorization", bearer(account.accessToken())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(account.id()))
                .andExpect(jsonPath("$.username").value(account.username()))
                .andExpect(jsonPath("$.email").value(account.email()));

        mockMvc.perform(get("/api/billing/me")
                        .header("Authorization", bearer(account.accessToken())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.planId").value("FREE"));
    }

    @Test
    void updateMeChangesDisplayNameUsernameAndEmail() throws Exception {
        TestAccount account = registerAccount("oldname", "old@example.com");

        String newUsername = "freshname_" + account.id();
        String newEmail = "fresh+" + account.id() + "@example.com";

        mockMvc.perform(patch("/api/users/me")
                        .header("Authorization", bearer(account.accessToken()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of(
                                "displayName", "Fresh Name",
                                "username", newUsername,
                                "email", newEmail
                        ))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.displayName").value("Fresh Name"))
                .andExpect(jsonPath("$.username").value(newUsername))
                .andExpect(jsonPath("$.email").value(newEmail));
    }

    @Test
    void updateMeRejectsDuplicateUsername() throws Exception {
        TestAccount busy = registerAccount("busyname", "busyname@example.com");
        TestAccount account = registerAccount("freeprofile", "freeprofile@example.com");

        mockMvc.perform(patch("/api/users/me")
                        .header("Authorization", bearer(account.accessToken()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("username", busy.username()))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message", anyOf(containsString("Username"), containsString("username"))));
    }

    @Test
    void userSearchDoesNotReturnCurrentUser() throws Exception {
        TestAccount main = registerAccount("searchmain", "searchmain@example.com");
        TestAccount friend = registerAccount("searchfriend", "searchfriend@example.com");

        mockMvc.perform(get("/api/users/search")
                        .param("query", "search")
                        .header("Authorization", bearer(main.accessToken())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[*].username", not(hasItem(main.username()))))
                .andExpect(jsonPath("$[*].username", hasItem(friend.username())));
    }

    @Test
    void avatarUrlCanBeUpdated() throws Exception {
        TestAccount account = registerAccount("avataruser", "avatar@example.com");

        mockMvc.perform(post("/api/users/me/avatar")
                        .header("Authorization", bearer(account.accessToken()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("dataUrl", "data:image/png;base64,iVBORw0KGgo="))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.avatarUrl", startsWith("/uploads/avatars/avatar_")));

        mockMvc.perform(get("/api/auth/me")
                        .header("Authorization", bearer(account.accessToken())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.avatarUrl", startsWith("/uploads/avatars/avatar_")));
    }

    @Test
    void billingMeReturnsCurrentFreePlanLimits() throws Exception {
        TestAccount account = registerAccount("billinguser", "billing@example.com");

        mockMvc.perform(get("/api/billing/me")
                        .header("Authorization", bearer(account.accessToken())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.planId").value("FREE"))
                .andExpect(jsonPath("$.maxRooms").value(3))
                .andExpect(jsonPath("$.maxParticipants").value(5))
                .andExpect(jsonPath("$.allowInviteOnly").value(false));
    }

    @Test
    void billingPlansExposeFreePremiumAndPro() throws Exception {
        TestAccount account = registerAccount("plansuser", "plans@example.com");

        mockMvc.perform(get("/api/billing/plans")
                        .header("Authorization", bearer(account.accessToken())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(3)))
                .andExpect(jsonPath("$[*].id", contains("FREE", "PREMIUM", "PRO")));
    }
}
