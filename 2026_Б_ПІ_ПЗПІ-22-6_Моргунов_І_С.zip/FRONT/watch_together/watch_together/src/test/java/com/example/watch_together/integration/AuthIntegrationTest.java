package com.example.watch_together.integration;

import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class AuthIntegrationTest extends AbstractIntegrationTest {

    @Test
    void registerCreatesUserAndReturnsJwtPair() throws Exception {
        TestAccount account = registerAccount("newuser", "newuser@example.com");

        assertThat(account.accessToken()).isNotBlank();
        assertThat(account.refreshToken()).isNotBlank();
        assertThat(userRepository.existsByEmail(account.email())).isTrue();
    }

    @Test
    void registerRejectsDuplicateEmail() throws Exception {
        TestAccount owner = registerAccount("owner", "owner@example.com");

        mockMvc.perform(post("/api/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of(
                                "username", "other",
                                "email", owner.email(),
                                "password", "password123",
                                "displayName", "Other"
                        ))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message", containsString("Email already in use")));
    }

    @Test
    void loginWorksByEmailAndByUsername() throws Exception {
        TestAccount account = registerAccount("lapaspalma", "lapa@example.com");

        mockMvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("login", account.email(), "password", account.password()))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.accessToken", not(blankOrNullString())))
                .andExpect(jsonPath("$.requiresTwoFactor").value(false));

        mockMvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("login", account.username(), "password", account.password()))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.accessToken", not(blankOrNullString())));
    }

    @Test
    void loginRejectsWrongPassword() throws Exception {
        TestAccount account = registerAccount("wrongpass", "wrongpass@example.com");

        mockMvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("login", account.email(), "password", "bad-password"))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message", containsString("Invalid credentials")));
    }

    @Test
    void refreshReturnsNewAccessTokenAndLogoutRevokesRefreshToken() throws Exception {
        TestAccount account = registerAccount("refreshuser", "refresh@example.com");

        MvcResult refreshed = mockMvc.perform(post("/api/auth/refresh")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("refreshToken", account.refreshToken()))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.accessToken", not(blankOrNullString())))
                .andExpect(jsonPath("$.refreshToken").value(account.refreshToken()))
                .andReturn();

        assertThat(readJson(refreshed).get("accessToken").asText()).isNotBlank();

        mockMvc.perform(post("/api/auth/logout")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("refreshToken", account.refreshToken()))))
                .andExpect(status().isOk());

        mockMvc.perform(post("/api/auth/refresh")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("refreshToken", account.refreshToken()))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message", containsString("Refresh token revoked")));
    }

    @Test
    void protectedEndpointRequiresAuthorization() throws Exception {
        mockMvc.perform(get("/api/auth/me"))
                .andExpect(status().isUnauthorized());
    }
}
