package com.example.watch_together;

import com.example.watch_together.billing.service.BillingService;
import com.example.watch_together.notification.service.NotificationService;
import com.example.watch_together.room.dto.CreateRoomRequest;
import com.example.watch_together.room.dto.RoomResponse;
import com.example.watch_together.room.dto.UpdateRoomRequest;
import com.example.watch_together.room.entity.*;
import com.example.watch_together.room.repository.RoomParticipantRepository;
import com.example.watch_together.room.repository.RoomSettingsRepository;
import com.example.watch_together.room.repository.WatchRoomRepository;
import com.example.watch_together.room.service.RoomService;
import com.example.watch_together.user.entity.User;
import com.example.watch_together.user.repository.UserRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RoomServiceUnitTest {

    @Mock WatchRoomRepository watchRoomRepository;
    @Mock RoomSettingsRepository roomSettingsRepository;
    @Mock RoomParticipantRepository roomParticipantRepository;
    @Mock UserRepository userRepository;
    @Mock NotificationService notificationService;
    @Mock SimpMessagingTemplate messagingTemplate;
    @Mock BillingService billingService;

    @InjectMocks RoomService roomService;

    User owner;
    User viewer;
    WatchRoom room;

    @BeforeEach
    void setUp() {
        owner = TestFixtures.user(1L, "host", "host@example.com");
        viewer = TestFixtures.user(2L, "viewer", "viewer@example.com");
        room = TestFixtures.room(1L, owner);
        TestFixtures.authenticate(owner);
        lenient().when(userRepository.findById(1L)).thenReturn(Optional.of(owner));
        lenient().when(roomParticipantRepository.countByRoomAndJoinStatus(any(), eq(JoinStatus.JOINED))).thenReturn(1L);
    }

    @AfterEach
    void tearDown() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void createRoomSavesRoomSettingsAndHostParticipant() {
        CreateRoomRequest request = new CreateRoomRequest();
        request.setName("New room");
        request.setDescription("Desc");
        request.setRoomType(RoomType.PUBLIC);
        request.setAccessMode(AccessMode.OPEN);
        request.setMaxParticipants(5);
        when(billingService.getCurrentPlan(owner)).thenReturn(TestFixtures.freePlan());
        when(watchRoomRepository.countByOwnerAndIsActive(owner, true)).thenReturn(0L);
        when(watchRoomRepository.existsByRoomCode(anyString())).thenReturn(false);
        when(watchRoomRepository.save(any(WatchRoom.class))).thenAnswer(inv -> {
            WatchRoom saved = inv.getArgument(0);
            saved.setId(10L);
            return saved;
        });
        when(roomParticipantRepository.countByRoomAndJoinStatus(any(), eq(JoinStatus.JOINED))).thenReturn(1L);

        RoomResponse response = roomService.createRoom(request);

        assertThat(response.getName()).isEqualTo("New room");
        assertThat(response.getRoomCode()).hasSize(8);
        verify(roomSettingsRepository).save(any(RoomSettings.class));
        verify(roomParticipantRepository).save(argThat(p -> p.getParticipantRole() == ParticipantRole.HOST));
    }

    @Test
    void createRoomRejectsWhenPlanRoomLimitExceeded() {
        CreateRoomRequest request = new CreateRoomRequest();
        request.setName("Room");
        request.setAccessMode(AccessMode.OPEN);
        request.setRoomType(RoomType.PUBLIC);
        request.setMaxParticipants(5);
        when(billingService.getCurrentPlan(owner)).thenReturn(TestFixtures.freePlan());
        when(watchRoomRepository.countByOwnerAndIsActive(owner, true)).thenReturn(3L);

        assertThatThrownBy(() -> roomService.createRoom(request))
                .isInstanceOf(ResponseStatusException.class)
                .hasMessageContaining("current plan allows only");
    }

    @Test
    void createRoomRejectsInviteOnlyOnFreePlan() {
        CreateRoomRequest request = new CreateRoomRequest();
        request.setName("Room");
        request.setAccessMode(AccessMode.INVITE_ONLY);
        request.setRoomType(RoomType.PUBLIC);
        request.setMaxParticipants(5);
        when(billingService.getCurrentPlan(owner)).thenReturn(TestFixtures.freePlan());
        when(watchRoomRepository.countByOwnerAndIsActive(owner, true)).thenReturn(0L);

        assertThatThrownBy(() -> roomService.createRoom(request))
                .isInstanceOf(ResponseStatusException.class)
                .hasMessageContaining("Invite-only rooms");
    }

    @Test
    void updateRoomRejectsCustomizationOnFreePlan() {
        UpdateRoomRequest request = new UpdateRoomRequest();
        request.setThemeColor("#ff0000");
        when(watchRoomRepository.findByRoomCode("ROOM1234")).thenReturn(Optional.of(room));
        when(roomParticipantRepository.findByRoomAndUser(room, owner))
                .thenReturn(Optional.of(TestFixtures.participant(room, owner, ParticipantRole.HOST, JoinStatus.JOINED, true)));
        when(billingService.getCurrentPlan(owner)).thenReturn(TestFixtures.freePlan());

        assertThatThrownBy(() -> roomService.updateRoom("ROOM1234", request))
                .isInstanceOf(ResponseStatusException.class)
                .hasMessageContaining("Room customization");
    }

    @Test
    void updateRoomAllowsCustomizationOnPremiumPlan() {
        UpdateRoomRequest request = new UpdateRoomRequest();
        request.setThemeColor(" #00ff00 ");
        request.setCoverImageUrl(" https://cdn.test/cover.jpg ");
        when(watchRoomRepository.findByRoomCode("ROOM1234")).thenReturn(Optional.of(room));
        when(roomParticipantRepository.findByRoomAndUser(room, owner))
                .thenReturn(Optional.of(TestFixtures.participant(room, owner, ParticipantRole.HOST, JoinStatus.JOINED, true)));
        when(billingService.getCurrentPlan(owner)).thenReturn(TestFixtures.premiumPlan());

        roomService.updateRoom("ROOM1234", request);

        assertThat(room.getThemeColor()).isEqualTo("#00ff00");
        assertThat(room.getCoverImageUrl()).isEqualTo("https://cdn.test/cover.jpg");
    }

    @Test
    void joinRoomCreatesNewParticipantAndBroadcastsChange() {
        TestFixtures.authenticate(viewer);
        when(userRepository.findById(2L)).thenReturn(Optional.of(viewer));
        when(watchRoomRepository.findByRoomCode("ROOM1234")).thenReturn(Optional.of(room));
        when(roomParticipantRepository.findByRoomAndUser(room, viewer)).thenReturn(Optional.empty());
        when(roomParticipantRepository.countByRoomAndJoinStatus(room, JoinStatus.JOINED)).thenReturn(1L);

        roomService.joinRoom("ROOM1234");

        verify(roomParticipantRepository).save(argThat(p -> p.getUser().equals(viewer) && p.getJoinStatus() == JoinStatus.JOINED));
        verify(messagingTemplate).convertAndSend(eq("/topic/rooms/ROOM1234/events"), any(Object.class));
    }

    @Test
    void joinRoomRejectsKickedParticipant() {
        TestFixtures.authenticate(viewer);
        when(userRepository.findById(2L)).thenReturn(Optional.of(viewer));
        when(watchRoomRepository.findByRoomCode("ROOM1234")).thenReturn(Optional.of(room));
        when(roomParticipantRepository.findByRoomAndUser(room, viewer))
                .thenReturn(Optional.of(TestFixtures.participant(room, viewer, ParticipantRole.VIEWER, JoinStatus.KICKED, false)));

        assertThatThrownBy(() -> roomService.joinRoom("ROOM1234"))
                .hasMessageContaining("kicked");
    }

    @Test
    void joinRoomRejectsWhenRoomIsFull() {
        TestFixtures.authenticate(viewer);
        when(userRepository.findById(2L)).thenReturn(Optional.of(viewer));
        when(watchRoomRepository.findByRoomCode("ROOM1234")).thenReturn(Optional.of(room));
        when(roomParticipantRepository.findByRoomAndUser(room, viewer)).thenReturn(Optional.empty());
        when(roomParticipantRepository.countByRoomAndJoinStatus(room, JoinStatus.JOINED)).thenReturn(5L);

        assertThatThrownBy(() -> roomService.joinRoom("ROOM1234"))
                .hasMessageContaining("Room is full");
    }

    @Test
    void leaveRoomClosesRoomWhenHostLeavesAndNoParticipantsRemain() {
        when(watchRoomRepository.findByRoomCode("ROOM1234")).thenReturn(Optional.of(room));
        when(roomParticipantRepository.findByRoomAndUser(room, owner))
                .thenReturn(Optional.of(TestFixtures.participant(room, owner, ParticipantRole.HOST, JoinStatus.JOINED, true)));
        when(roomParticipantRepository.findAllByRoomAndJoinStatus(room, JoinStatus.JOINED)).thenReturn(List.of());

        roomService.leaveRoom("ROOM1234");

        assertThat(room.getIsActive()).isFalse();
        assertThat(room.getEndedAt()).isNotNull();
    }

    @Test
    void transferHostChangesRolesAndBroadcasts() {
        RoomParticipant oldHost = TestFixtures.participant(room, owner, ParticipantRole.HOST, JoinStatus.JOINED, true);
        RoomParticipant newHost = TestFixtures.participant(room, viewer, ParticipantRole.VIEWER, JoinStatus.JOINED, false);
        when(watchRoomRepository.findByRoomCode("ROOM1234")).thenReturn(Optional.of(room));
        when(userRepository.findById(2L)).thenReturn(Optional.of(viewer));
        when(roomParticipantRepository.findByRoomAndUser(room, owner)).thenReturn(Optional.of(oldHost));
        when(roomParticipantRepository.findByRoomAndUser(room, viewer)).thenReturn(Optional.of(newHost));

        roomService.transferHost("ROOM1234", 2L);

        assertThat(oldHost.getParticipantRole()).isEqualTo(ParticipantRole.VIEWER);
        assertThat(newHost.getParticipantRole()).isEqualTo(ParticipantRole.HOST);
        verify(messagingTemplate, atLeastOnce()).convertAndSend(eq("/topic/rooms/ROOM1234/events"), any(Object.class));
    }
}
