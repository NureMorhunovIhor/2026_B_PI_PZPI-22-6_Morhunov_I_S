package com.example.watch_together;

import com.example.watch_together.billing.service.BillingService;
import com.example.watch_together.chat.dto.ChatMessageRequest;
import com.example.watch_together.chat.dto.EditMessageRequest;
import com.example.watch_together.chat.dto.ReactionRequest;
import com.example.watch_together.chat.entity.ChatMessage;
import com.example.watch_together.chat.entity.MessageReaction;
import com.example.watch_together.chat.entity.MessageType;
import com.example.watch_together.chat.repository.ChatMessageRepository;
import com.example.watch_together.chat.repository.MessageReactionRepository;
import com.example.watch_together.chat.service.ChatService;
import com.example.watch_together.room.entity.*;
import com.example.watch_together.room.repository.RoomParticipantRepository;
import com.example.watch_together.room.repository.RoomSettingsRepository;
import com.example.watch_together.room.repository.WatchRoomRepository;
import com.example.watch_together.user.entity.User;
import com.example.watch_together.user.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ChatServiceUnitTest {

    @Mock WatchRoomRepository watchRoomRepository;
    @Mock RoomParticipantRepository roomParticipantRepository;
    @Mock RoomSettingsRepository roomSettingsRepository;
    @Mock UserRepository userRepository;
    @Mock ChatMessageRepository chatMessageRepository;
    @Mock MessageReactionRepository messageReactionRepository;
    @Mock SimpMessagingTemplate messagingTemplate;
    @Mock BillingService billingService;

    @InjectMocks ChatService chatService;

    User user;
    User other;
    WatchRoom room;
    Principal principal;

    @BeforeEach
    void setUp() {
        user = TestFixtures.user(1L, "sender", "sender@example.com");
        other = TestFixtures.user(2L, "other", "other@example.com");
        room = TestFixtures.room(1L, user);
        principal = () -> "sender@example.com";
        lenient().when(watchRoomRepository.findByRoomCode("ROOM1234")).thenReturn(Optional.of(room));
        lenient().when(userRepository.findByEmail("sender@example.com")).thenReturn(Optional.of(user));
        lenient().when(roomParticipantRepository.findByRoomAndUser(room, user))
                .thenReturn(Optional.of(TestFixtures.participant(room, user, ParticipantRole.VIEWER, JoinStatus.JOINED, true)));
        lenient().when(roomSettingsRepository.findByRoom(room)).thenReturn(Optional.of(TestFixtures.roomSettings(room, true)));
        lenient().when(messageReactionRepository.findAllByMessage(any())).thenReturn(List.of());
        lenient().when(chatMessageRepository.save(any(ChatMessage.class))).thenAnswer(inv -> {
            ChatMessage msg = inv.getArgument(0);
            msg.setId(10L);
            return msg;
        });
    }

    @Test
    void sendTextMessageSavesAndBroadcasts() {
        ChatMessageRequest request = new ChatMessageRequest();
        request.setRoomCode("ROOM1234");
        request.setContent("Hello");

        var response = chatService.sendMessage(request, principal);

        assertThat(response.getContent()).isEqualTo("Hello");
        assertThat(response.getMessageType()).isEqualTo(MessageType.TEXT);
        verify(chatMessageRepository).save(any(ChatMessage.class));
        verify(messagingTemplate).convertAndSend(eq("/topic/rooms/ROOM1234/chat"), any(Object.class));
    }

    @Test
    void sendMessageRejectsMissingRoom() {
        ChatMessageRequest request = new ChatMessageRequest();
        request.setRoomCode("BADROOM");
        request.setContent("Hello");
        when(watchRoomRepository.findByRoomCode("BADROOM")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> chatService.sendMessage(request, principal))
                .hasMessageContaining("Room not found");
    }

    @Test
    void sendMessageRejectsClosedRoom() {
        room.setIsActive(false);
        ChatMessageRequest request = new ChatMessageRequest();
        request.setRoomCode("ROOM1234");
        request.setContent("Hello");

        assertThatThrownBy(() -> chatService.sendMessage(request, principal))
                .hasMessageContaining("Room is closed");
    }

    @Test
    void sendMessageRejectsUserOutsideRoom() {
        when(roomParticipantRepository.findByRoomAndUser(room, user)).thenReturn(Optional.empty());
        ChatMessageRequest request = new ChatMessageRequest();
        request.setRoomCode("ROOM1234");
        request.setContent("Hello");

        assertThatThrownBy(() -> chatService.sendMessage(request, principal))
                .hasMessageContaining("not in this room");
    }

    @Test
    void sendMessageRejectsWhenChatDisabled() {
        when(roomSettingsRepository.findByRoom(room)).thenReturn(Optional.of(TestFixtures.roomSettings(room, false)));
        ChatMessageRequest request = new ChatMessageRequest();
        request.setRoomCode("ROOM1234");
        request.setContent("Hello");

        assertThatThrownBy(() -> chatService.sendMessage(request, principal))
                .hasMessageContaining("Chat is disabled");
    }

    @Test
    void premiumStickerRejectedForFreePlan() {
        ChatMessageRequest request = new ChatMessageRequest();
        request.setRoomCode("ROOM1234");
        request.setMessageType(MessageType.STICKER);
        request.setContent("premium_fire");
        when(billingService.getCurrentPlan(user)).thenReturn(TestFixtures.freePlan());

        assertThatThrownBy(() -> chatService.sendMessage(request, principal))
                .isInstanceOf(ResponseStatusException.class)
                .hasMessageContaining("Premium stickers");
    }

    @Test
    void premiumStickerAllowedForPremiumPlan() {
        ChatMessageRequest request = new ChatMessageRequest();
        request.setRoomCode("ROOM1234");
        request.setMessageType(MessageType.STICKER);
        request.setContent("premium_fire");
        when(billingService.getCurrentPlan(user)).thenReturn(TestFixtures.premiumPlan());

        var response = chatService.sendMessage(request, principal);

        assertThat(response.getMessageType()).isEqualTo(MessageType.STICKER);
        assertThat(response.getContent()).isEqualTo("premium_fire");
    }

    @Test
    void editOwnMessageUpdatesContent() {
        ChatMessage message = ChatMessage.builder()
                .id(5L).room(room).sender(user).messageType(MessageType.TEXT)
                .content("old").isEdited(false).isDeleted(false).build();
        when(chatMessageRepository.findById(5L)).thenReturn(Optional.of(message));
        EditMessageRequest request = new EditMessageRequest();
        request.setContent("new");

        var response = chatService.editMessage(5L, request, principal);

        assertThat(response.getContent()).isEqualTo("new");
        assertThat(message.getIsEdited()).isTrue();
    }

    @Test
    void editOtherUserMessageIsRejected() {
        ChatMessage message = ChatMessage.builder()
                .id(5L).room(room).sender(other).messageType(MessageType.TEXT)
                .content("old").isEdited(false).isDeleted(false).build();
        when(chatMessageRepository.findById(5L)).thenReturn(Optional.of(message));
        EditMessageRequest request = new EditMessageRequest();
        request.setContent("new");

        assertThatThrownBy(() -> chatService.editMessage(5L, request, principal))
                .hasMessageContaining("edit only your own");
    }

    @Test
    void deleteOwnMessageMarksDeleted() {
        ChatMessage message = ChatMessage.builder()
                .id(5L).room(room).sender(user).messageType(MessageType.TEXT)
                .content("text").isEdited(false).isDeleted(false).build();
        when(chatMessageRepository.findById(5L)).thenReturn(Optional.of(message));

        chatService.deleteMessage(5L, principal);

        assertThat(message.getIsDeleted()).isTrue();
        assertThat(message.getContent()).isEqualTo("[deleted]");
    }

    @Test
    void addReactionCreatesReactionOnlyIfNotExists() {
        ChatMessage message = ChatMessage.builder()
                .id(5L).room(room).sender(other).messageType(MessageType.TEXT)
                .content("text").isEdited(false).isDeleted(false).build();
        when(chatMessageRepository.findById(5L)).thenReturn(Optional.of(message));
        when(messageReactionRepository.findByMessageAndUserAndReactionType(message, user, "LIKE"))
                .thenReturn(Optional.empty());
        ReactionRequest request = new ReactionRequest();
        request.setReactionType("LIKE");

        chatService.addReaction(5L, request, principal);

        verify(messageReactionRepository).save(any(MessageReaction.class));
    }
}
