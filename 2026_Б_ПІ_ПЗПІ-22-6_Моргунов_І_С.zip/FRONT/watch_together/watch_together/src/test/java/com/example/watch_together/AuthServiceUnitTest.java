package com.example.watch_together;

import com.example.watch_together.auth.dto.*;
import com.example.watch_together.auth.repository.PasswordResetTokenRepository;
import com.example.watch_together.auth.service.AuthService;
import com.example.watch_together.auth.service.EmailService;
import com.example.watch_together.config.MailProperties;
import com.example.watch_together.role.entity.Role;
import com.example.watch_together.role.repository.RoleRepository;
import com.example.watch_together.security.JwtService;
import com.example.watch_together.security.TotpService;
import com.example.watch_together.session.entity.UserSession;
import com.example.watch_together.session.repository.UserSessionRepository;
import com.example.watch_together.user.entity.User;
import com.example.watch_together.user.repository.UserRepository;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuthServiceUnitTest {

    @Mock UserRepository userRepository;
    @Mock RoleRepository roleRepository;
    @Mock UserSessionRepository userSessionRepository;
    @Mock PasswordEncoder passwordEncoder;
    @Mock JwtService jwtService;
    @Mock TotpService totpService;
    @Mock PasswordResetTokenRepository passwordResetTokenRepository;
    @Mock EmailService emailService;
    @Mock MailProperties mailProperties;
    @Mock HttpServletRequest httpRequest;

    @InjectMocks AuthService authService;

    User user;

    @BeforeEach
    void setUp() {
        user = TestFixtures.user(1L, "lapaspalma", "lapaspalma@gmail.com");
        lenient().when(httpRequest.getHeader("User-Agent")).thenReturn("JUnit");
        lenient().when(httpRequest.getRemoteAddr()).thenReturn("127.0.0.1");
        lenient().when(jwtService.generateAccessToken(any())).thenReturn("access-token");
        lenient().when(jwtService.generateRefreshToken(any())).thenReturn("refresh-token");
        lenient().when(jwtService.getRefreshExpiration()).thenReturn(604800000L);
        lenient().when(userSessionRepository.save(any(UserSession.class))).thenAnswer(i -> i.getArgument(0));
    }

    @Test
    void registerCreatesUserAndReturnsTokens() {
        RegisterRequest request = new RegisterRequest();
        request.setUsername("newuser");
        request.setEmail("new@example.com");
        request.setPassword("password123");
        request.setDisplayName("New User");

        when(userRepository.existsByEmail("new@example.com")).thenReturn(false);
        when(userRepository.existsByUsername("newuser")).thenReturn(false);
        when(roleRepository.findByName("ROLE_USER")).thenReturn(Optional.of(Role.builder().id(1L).name("ROLE_USER").build()));
        when(passwordEncoder.encode("password123")).thenReturn("encoded");
        when(userRepository.save(any(User.class))).thenAnswer(inv -> {
            User saved = inv.getArgument(0);
            saved.setId(10L);
            return saved;
        });

        AuthResponse response = authService.register(request, httpRequest);

        assertThat(response.getAccessToken()).isEqualTo("access-token");
        assertThat(response.getRefreshToken()).isEqualTo("refresh-token");
        assertThat(response.getRequiresTwoFactor()).isFalse();
        verify(userRepository).save(any(User.class));
        verify(userSessionRepository).save(any(UserSession.class));
    }

    @Test
    void registerRejectsDuplicateEmail() {
        RegisterRequest request = new RegisterRequest();
        request.setUsername("user");
        request.setEmail("busy@example.com");
        request.setPassword("password123");
        request.setDisplayName("Busy");
        when(userRepository.existsByEmail("busy@example.com")).thenReturn(true);

        assertThatThrownBy(() -> authService.register(request, httpRequest))
                .hasMessageContaining("Email already in use");
    }

    @Test
    void registerRejectsDuplicateUsername() {
        RegisterRequest request = new RegisterRequest();
        request.setUsername("busy");
        request.setEmail("free@example.com");
        request.setPassword("password123");
        request.setDisplayName("Busy");
        when(userRepository.existsByEmail("free@example.com")).thenReturn(false);
        when(userRepository.existsByUsername("busy")).thenReturn(true);

        assertThatThrownBy(() -> authService.register(request, httpRequest))
                .hasMessageContaining("Username already in use");
    }

    @Test
    void loginWithEmailReturnsTokens() {
        LoginRequest request = new LoginRequest();
        request.setLogin("lapaspalma@gmail.com");
        request.setPassword("password123");
        when(userRepository.findByEmail("lapaspalma@gmail.com")).thenReturn(Optional.of(user));
        when(passwordEncoder.matches("password123", "encodedPassword")).thenReturn(true);

        AuthResponse response = authService.login(request, httpRequest);

        assertThat(response.getAccessToken()).isEqualTo("access-token");
        assertThat(response.getRequiresTwoFactor()).isFalse();
    }

    @Test
    void loginRejectsUnknownUser() {
        LoginRequest request = new LoginRequest();
        request.setLogin("unknown@example.com");
        request.setPassword("password123");
        when(userRepository.findByEmail("unknown@example.com")).thenReturn(Optional.empty());
        when(userRepository.findByUsername("unknown@example.com")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> authService.login(request, httpRequest))
                .hasMessageContaining("Invalid credentials");
    }

    @Test
    void loginRejectsWrongPassword() {
        LoginRequest request = new LoginRequest();
        request.setLogin("lapaspalma@gmail.com");
        request.setPassword("wrong");
        when(userRepository.findByEmail("lapaspalma@gmail.com")).thenReturn(Optional.of(user));
        when(passwordEncoder.matches("wrong", "encodedPassword")).thenReturn(false);

        assertThatThrownBy(() -> authService.login(request, httpRequest))
                .hasMessageContaining("Invalid credentials");
    }

    @Test
    void loginWithTwoFactorEnabledReturnsTemporaryToken() {
        user.setTwoFactorEnabled(true);
        LoginRequest request = new LoginRequest();
        request.setLogin("lapaspalma@gmail.com");
        request.setPassword("password123");
        when(userRepository.findByEmail("lapaspalma@gmail.com")).thenReturn(Optional.of(user));
        when(passwordEncoder.matches("password123", "encodedPassword")).thenReturn(true);
        when(jwtService.generateTempTwoFactorToken(any())).thenReturn("temp-token");

        AuthResponse response = authService.login(request, httpRequest);

        assertThat(response.getRequiresTwoFactor()).isTrue();
        assertThat(response.getTempToken()).isEqualTo("temp-token");
        verify(userSessionRepository, never()).save(any());
    }

    @Test
    void refreshWithValidSessionReturnsNewAccessToken() {
        RefreshTokenRequest request = new RefreshTokenRequest();
        request.setRefreshToken("refresh-token");
        UserSession session = UserSession.builder()
                .user(user)
                .refreshToken("refresh-token")
                .isRevoked(false)
                .expiresAt(LocalDateTime.now().plusDays(1))
                .build();
        when(userSessionRepository.findByRefreshToken("refresh-token")).thenReturn(Optional.of(session));
        when(jwtService.isTokenValid("refresh-token")).thenReturn(true);
        when(jwtService.generateAccessToken(any())).thenReturn("new-access");

        AuthResponse response = authService.refresh(request);

        assertThat(response.getAccessToken()).isEqualTo("new-access");
        assertThat(response.getRefreshToken()).isEqualTo("refresh-token");
    }

    @Test
    void refreshRejectsRevokedToken() {
        RefreshTokenRequest request = new RefreshTokenRequest();
        request.setRefreshToken("revoked");
        UserSession session = UserSession.builder()
                .user(user)
                .refreshToken("revoked")
                .isRevoked(true)
                .expiresAt(LocalDateTime.now().plusDays(1))
                .build();
        when(userSessionRepository.findByRefreshToken("revoked")).thenReturn(Optional.of(session));

        assertThatThrownBy(() -> authService.refresh(request))
                .hasMessageContaining("Refresh token revoked");
    }

    @Test
    void logoutRevokesSession() {
        RefreshTokenRequest request = new RefreshTokenRequest();
        request.setRefreshToken("refresh-token");
        UserSession session = UserSession.builder()
                .user(user)
                .refreshToken("refresh-token")
                .isRevoked(false)
                .expiresAt(LocalDateTime.now().plusDays(1))
                .build();
        when(userSessionRepository.findByRefreshToken("refresh-token")).thenReturn(Optional.of(session));

        authService.logout(request);

        assertThat(session.getIsRevoked()).isTrue();
        assertThat(session.getRevokedAt()).isNotNull();
        verify(userSessionRepository).save(session);
    }
}
