package com.example.watch_together;

import com.example.watch_together.billing.dto.*;
import com.example.watch_together.billing.entity.Payment;
import com.example.watch_together.billing.entity.UserSubscription;
import com.example.watch_together.billing.repository.PaymentRepository;
import com.example.watch_together.billing.repository.UserSubscriptionRepository;
import com.example.watch_together.billing.service.BillingService;
import com.example.watch_together.billing.service.PayPalService;
import com.example.watch_together.user.entity.User;
import com.example.watch_together.user.repository.UserRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.context.SecurityContextHolder;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BillingServiceUnitTest {

    @Mock UserRepository userRepository;
    @Mock UserSubscriptionRepository subscriptionRepository;
    @Mock PaymentRepository paymentRepository;
    @Mock PayPalService payPalService;

    @InjectMocks BillingService billingService;

    User user;

    @BeforeEach
    void setUp() {
        user = TestFixtures.user(1L, "lapaspalma", "lapaspalma@gmail.com");
        TestFixtures.authenticate(user);
        lenient().when(userRepository.findById(1L)).thenReturn(Optional.of(user));
    }

    @AfterEach
    void tearDown() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void getPlansReturnsFreePremiumAndPro() {
        var plans = billingService.getPlans();
        assertThat(plans).extracting(BillingPlanResponse::getId)
                .containsExactly("FREE", "PREMIUM", "PRO");
    }

    @Test
    void getCurrentPlanIdReturnsFreeWhenNoSubscription() {
        when(subscriptionRepository.findTopByUserOrderByStartedAtDesc(user)).thenReturn(Optional.empty());
        assertThat(billingService.getCurrentPlanId(user)).isEqualTo("FREE");
    }

    @Test
    void getCurrentPlanIdReturnsActiveSubscriptionPlan() {
        UserSubscription subscription = UserSubscription.builder()
                .user(user).planId("PREMIUM").status("ACTIVE").billingCycle("MONTHLY")
                .startedAt(LocalDateTime.now()).autoRenew(true).build();
        when(subscriptionRepository.findTopByUserOrderByStartedAtDesc(user)).thenReturn(Optional.of(subscription));
        assertThat(billingService.getCurrentPlanId(user)).isEqualTo("PREMIUM");
    }

    @Test
    void getCurrentPlanReturnsFreeFeaturesForInactiveSubscription() {
        UserSubscription subscription = UserSubscription.builder()
                .user(user).planId("PRO").status("CANCELED").billingCycle("MONTHLY")
                .startedAt(LocalDateTime.now()).autoRenew(false).build();
        when(subscriptionRepository.findTopByUserOrderByStartedAtDesc(user)).thenReturn(Optional.of(subscription));

        BillingPlanResponse plan = billingService.getCurrentPlan(user);

        assertThat(plan.getId()).isEqualTo("FREE");
        assertThat(plan.getAllowRoomStatistics()).isFalse();
    }

    @Test
    void getMeBuildsBillingResponseFromPlan() {
        UserSubscription subscription = UserSubscription.builder()
                .user(user).planId("PRO").status("ACTIVE").billingCycle("YEARLY")
                .startedAt(LocalDateTime.now().minusDays(1))
                .currentPeriodEnd(LocalDateTime.now().plusYears(1))
                .autoRenew(true).build();
        when(subscriptionRepository.findTopByUserOrderByStartedAtDesc(user)).thenReturn(Optional.of(subscription));

        BillingMeResponse response = billingService.getMe();

        assertThat(response.getPlanId()).isEqualTo("PRO");
        assertThat(response.getAllowRoomStatistics()).isTrue();
        assertThat(response.getMaxParticipants()).isEqualTo(50);
    }

    @Test
    void checkoutRejectsFreePlan() {
        CheckoutRequest request = new CheckoutRequest();
        request.setPlanId("FREE");
        request.setCycle(BillingCycle.MONTHLY);

        assertThatThrownBy(() -> billingService.checkout(request))
                .hasMessageContaining("Free plan does not require checkout");
    }

    @Test
    void checkoutCreatesPayPalOrderAndPendingPayment() {
        CheckoutRequest request = new CheckoutRequest();
        request.setPlanId("PRO");
        request.setCycle(BillingCycle.YEARLY);
        when(payPalService.createOrder(eq("PRO"), eq(BillingCycle.YEARLY), any()))
                .thenReturn(new PayPalService.PayPalOrder("ORDER-1", "https://paypal.test/approve"));
        when(paymentRepository.save(any(Payment.class))).thenAnswer(i -> i.getArgument(0));

        CheckoutResponse response = billingService.checkout(request);

        assertThat(response.getOrderId()).isEqualTo("ORDER-1");
        assertThat(response.getApproveUrl()).contains("paypal.test");
        verify(paymentRepository).save(argThat(p -> "PENDING".equals(p.getStatus()) && "PRO".equals(p.getPlanId())));
    }

    @Test
    void captureRejectsUnknownOrder() {
        CaptureRequest request = new CaptureRequest();
        request.setOrderId("UNKNOWN");
        when(paymentRepository.findByOrderId("UNKNOWN")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> billingService.capture(request))
                .hasMessageContaining("Payment order not found");
    }

    @Test
    void cancelRenewalRejectsWhenNoActiveSubscription() {
        when(subscriptionRepository.findTopByUserOrderByStartedAtDesc(user)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> billingService.cancelRenewal())
                .hasMessageContaining("No active subscription");
    }

    @Test
    void cancelRenewalTurnsOffAutoRenew() {
        UserSubscription subscription = UserSubscription.builder()
                .user(user).planId("PREMIUM").status("ACTIVE").billingCycle("MONTHLY")
                .startedAt(LocalDateTime.now()).autoRenew(true).build();
        when(subscriptionRepository.findTopByUserOrderByStartedAtDesc(user)).thenReturn(Optional.of(subscription));
        when(subscriptionRepository.save(subscription)).thenReturn(subscription);

        BillingMeResponse response = billingService.cancelRenewal();

        assertThat(subscription.getAutoRenew()).isFalse();
        assertThat(response.getAutoRenew()).isFalse();
    }
}
