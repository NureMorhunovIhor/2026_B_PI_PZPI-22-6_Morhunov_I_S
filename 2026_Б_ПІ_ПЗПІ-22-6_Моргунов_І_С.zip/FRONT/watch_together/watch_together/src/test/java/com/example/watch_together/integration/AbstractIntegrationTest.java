package com.example.watch_together.integration;

import com.example.watch_together.role.repository.RoleRepository;
import com.example.watch_together.user.entity.User;
import com.example.watch_together.user.repository.UserRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.context.WebApplicationContext;

import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import org.springframework.test.web.servlet.MvcResult;

import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@ActiveProfiles("test")
abstract class AbstractIntegrationTest {

    protected MockMvc mockMvc;

    @Autowired private WebApplicationContext webApplicationContext;
    @Autowired protected ObjectMapper objectMapper;
    @Autowired protected UserRepository userRepository;
    @Autowired private RoleRepository roleRepository;
    @Autowired private JdbcTemplate jdbcTemplate;

    private static final AtomicLong UNIQUE = new AtomicLong(System.currentTimeMillis());

    @BeforeEach
    void setUpIntegrationTest() {
        org.springframework.security.core.context.SecurityContextHolder.clearContext();

        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext)
                .apply(springSecurity())
                .build();

        cleanDatabase();
        applyH2TimestampDefaults();
        ensureDefaultRole();
    }

    private void cleanDatabase() {
        try {
            jdbcTemplate.execute("SET REFERENTIAL_INTEGRITY FALSE");

            jdbcTemplate.queryForList("SHOW TABLES", String.class).forEach(table -> {
                try {
                    jdbcTemplate.execute("TRUNCATE TABLE " + table + " RESTART IDENTITY");
                } catch (Exception ignored) {
                    // Ignore Flyway/Hibernate auxiliary tables if they appear in future versions.
                }
            });
        } finally {
            try {
                jdbcTemplate.execute("SET REFERENTIAL_INTEGRITY TRUE");
            } catch (Exception ignored) {
            }
        }
    }

    private void ensureDefaultRole() {
        if (roleRepository.findByName("ROLE_USER").isEmpty()) {
            roleRepository.save(com.example.watch_together.role.entity.Role.builder()
                    .name("ROLE_USER")
                    .description("Default test user role")
                    .build());
        }
    }

    private void applyH2TimestampDefaults() {
        // Hibernate creates insertable=false timestamp columns without DB defaults in H2.
        // MySQL normally has these defaults in the real schema, so we add them for integration tests.
        String[] statements = {
                "ALTER TABLE watch_queue ALTER COLUMN added_at SET DEFAULT CURRENT_TIMESTAMP",
                "ALTER TABLE chat_messages ALTER COLUMN sent_at SET DEFAULT CURRENT_TIMESTAMP",
                "ALTER TABLE message_reactions ALTER COLUMN created_at SET DEFAULT CURRENT_TIMESTAMP",
                "ALTER TABLE playback_events ALTER COLUMN created_at SET DEFAULT CURRENT_TIMESTAMP",
                "ALTER TABLE notifications ALTER COLUMN created_at SET DEFAULT CURRENT_TIMESTAMP",
                "ALTER TABLE users ALTER COLUMN created_at SET DEFAULT CURRENT_TIMESTAMP",
                "ALTER TABLE users ALTER COLUMN updated_at SET DEFAULT CURRENT_TIMESTAMP",
                "ALTER TABLE watch_rooms ALTER COLUMN created_at SET DEFAULT CURRENT_TIMESTAMP",
                "ALTER TABLE watch_rooms ALTER COLUMN updated_at SET DEFAULT CURRENT_TIMESTAMP",
                "ALTER TABLE room_settings ALTER COLUMN created_at SET DEFAULT CURRENT_TIMESTAMP",
                "ALTER TABLE room_settings ALTER COLUMN updated_at SET DEFAULT CURRENT_TIMESTAMP",
                "ALTER TABLE friendships ALTER COLUMN created_at SET DEFAULT CURRENT_TIMESTAMP",
                "ALTER TABLE user_sessions ALTER COLUMN created_at SET DEFAULT CURRENT_TIMESTAMP",
                "ALTER TABLE password_reset_tokens ALTER COLUMN created_at SET DEFAULT CURRENT_TIMESTAMP"
        };

        for (String statement : statements) {
            try {
                jdbcTemplate.execute(statement);
            } catch (Exception ignored) {
                // Some tables/columns may be absent depending on the current project version.
            }
        }
    }

    protected TestAccount registerAccount(String username, String email) throws Exception {
        String password = "password123";
        String unique = String.valueOf(UNIQUE.incrementAndGet());
        String actualUsername = username + "_" + unique;
        String actualEmail = uniqueEmail(email, unique);

        MvcResult result = mockMvc.perform(post("/api/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of(
                                "username", actualUsername,
                                "email", actualEmail,
                                "password", password,
                                "displayName", actualUsername + " display"
                        ))))
                .andExpect(status().isOk())
                .andReturn();

        JsonNode body = readJson(result);
        User user = userRepository.findByEmail(actualEmail).orElseThrow();
        return new TestAccount(user.getId(), actualUsername, actualEmail, password,
                body.get("accessToken").asText(),
                body.get("refreshToken").asText());
    }

    private String uniqueEmail(String email, String unique) {
        int at = email.indexOf('@');
        if (at <= 0) {
            return email + "." + unique + "@example.com";
        }
        return email.substring(0, at) + "+" + unique + email.substring(at);
    }

    protected String createRoom(String token, String name, int maxParticipants) throws Exception {
        MvcResult result = mockMvc.perform(post("/api/rooms")
                        .header("Authorization", bearer(token))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of(
                                "name", name,
                                "description", "Integration test room",
                                "roomType", "PUBLIC",
                                "accessMode", "OPEN",
                                "maxParticipants", maxParticipants
                        ))))
                .andExpect(status().isOk())
                .andReturn();

        return readJson(result).get("roomCode").asText();
    }

    protected JsonNode readJson(MvcResult result) throws Exception {
        return objectMapper.readTree(result.getResponse().getContentAsString(StandardCharsets.UTF_8));
    }

    protected String json(Object value) throws Exception {
        return objectMapper.writeValueAsString(value);
    }

    protected String bearer(String token) {
        return "Bearer " + token;
    }

    protected record TestAccount(Long id, String username, String email, String password,
                                 String accessToken, String refreshToken) {}
}
