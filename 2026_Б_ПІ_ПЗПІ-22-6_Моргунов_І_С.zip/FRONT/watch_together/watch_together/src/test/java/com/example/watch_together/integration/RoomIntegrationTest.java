package com.example.watch_together.integration;

import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;

import java.util.Map;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class RoomIntegrationTest extends AbstractIntegrationTest {

    @Test
    void createRoomAddsOwnerAsHostParticipant() throws Exception {
        TestAccount owner = registerAccount("owner", "owner@example.com");
        String roomCode = createRoom(owner.accessToken(), "Movie Night", 5);

        mockMvc.perform(get("/api/rooms/{code}", roomCode)
                        .header("Authorization", bearer(owner.accessToken())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.roomCode").value(roomCode))
                .andExpect(jsonPath("$.name").value("Movie Night"))
                .andExpect(jsonPath("$.ownerUsername").value(owner.username()))
                .andExpect(jsonPath("$.participantsCount").value(1));

        mockMvc.perform(get("/api/rooms/{code}/participants", roomCode)
                        .header("Authorization", bearer(owner.accessToken())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].username").value(owner.username()))
                .andExpect(jsonPath("$[0].role").value("HOST"))
                .andExpect(jsonPath("$[0].canControlPlayback").value(true));
    }

    @Test
    void secondUserCanJoinOpenRoom() throws Exception {
        TestAccount owner = registerAccount("host", "host@example.com");
        TestAccount viewer = registerAccount("viewer", "viewer@example.com");
        String roomCode = createRoom(owner.accessToken(), "Open Room", 5);

        mockMvc.perform(post("/api/rooms/{code}/join", roomCode)
                        .header("Authorization", bearer(viewer.accessToken())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.participantsCount").value(2));

        mockMvc.perform(get("/api/rooms/{code}/participants", roomCode)
                        .header("Authorization", bearer(owner.accessToken())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[*].username", containsInAnyOrder(owner.username(), viewer.username())));
    }

    @Test
    void roomCapacityIsEnforced() throws Exception {
        TestAccount owner = registerAccount("capowner", "capowner@example.com");
        TestAccount first = registerAccount("firstviewer", "firstviewer@example.com");
        TestAccount second = registerAccount("secondviewer", "secondviewer@example.com");
        String roomCode = createRoom(owner.accessToken(), "Small Room", 2);

        mockMvc.perform(post("/api/rooms/{code}/join", roomCode)
                        .header("Authorization", bearer(first.accessToken())))
                .andExpect(status().isOk());

        mockMvc.perform(post("/api/rooms/{code}/join", roomCode)
                        .header("Authorization", bearer(second.accessToken())))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message", containsString("Room is full")));
    }

    @Test
    void hostCanKickViewerAndViewerCannotRejoin() throws Exception {
        TestAccount owner = registerAccount("kickhost", "kickhost@example.com");
        TestAccount viewer = registerAccount("kickviewer", "kickviewer@example.com");
        String roomCode = createRoom(owner.accessToken(), "Kick Room", 5);

        mockMvc.perform(post("/api/rooms/{code}/join", roomCode)
                        .header("Authorization", bearer(viewer.accessToken())))
                .andExpect(status().isOk());

        mockMvc.perform(post("/api/rooms/{code}/kick/{userId}", roomCode, viewer.id())
                        .header("Authorization", bearer(owner.accessToken())))
                .andExpect(status().isNoContent());

        mockMvc.perform(post("/api/rooms/{code}/join", roomCode)
                        .header("Authorization", bearer(viewer.accessToken())))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message", containsString("kicked")));
    }

    @Test
    void nonHostCannotKickAnotherParticipant() throws Exception {
        TestAccount owner = registerAccount("realhost", "realhost@example.com");
        TestAccount viewer = registerAccount("weakviewer", "weakviewer@example.com");
        String roomCode = createRoom(owner.accessToken(), "Protected Room", 5);

        mockMvc.perform(post("/api/rooms/{code}/join", roomCode)
                        .header("Authorization", bearer(viewer.accessToken())))
                .andExpect(status().isOk());

        mockMvc.perform(post("/api/rooms/{code}/kick/{userId}", roomCode, owner.id())
                        .header("Authorization", bearer(viewer.accessToken())))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message", containsString("Only host")));
    }

    @Test
    void hostCanRegenerateRoomCodeAndOldCodeStopsWorking() throws Exception {
        TestAccount owner = registerAccount("codehost", "codehost@example.com");
        String oldCode = createRoom(owner.accessToken(), "Code Room", 5);

        String newCode = mockMvc.perform(post("/api/rooms/{code}/regenerate-code", oldCode)
                        .header("Authorization", bearer(owner.accessToken())))
                .andExpect(status().isOk())
                .andExpect(content().string(not(oldCode)))
                .andReturn()
                .getResponse()
                .getContentAsString();

        mockMvc.perform(get("/api/rooms/{code}", newCode)
                        .header("Authorization", bearer(owner.accessToken())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.roomCode").value(newCode));

        mockMvc.perform(get("/api/rooms/{code}", oldCode)
                        .header("Authorization", bearer(owner.accessToken())))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message", containsString("Room not found")));
    }

    @Test
    void updateRoomRejectsInviteOnlyForFreePlan() throws Exception {
        TestAccount owner = registerAccount("freehost", "freehost@example.com");
        String roomCode = createRoom(owner.accessToken(), "Free Room", 5);

        mockMvc.perform(put("/api/rooms/{code}", roomCode)
                        .header("Authorization", bearer(owner.accessToken()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("accessMode", "INVITE_ONLY"))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message", containsString("Invite-only rooms")));
    }
}
