package com.example.watch_together.integration;

import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

import java.util.Map;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class ChatIntegrationTest extends AbstractIntegrationTest {

    @Test
    void participantCanSendAndReadRoomMessages() throws Exception {
        TestAccount owner = registerAccount("chatowner", "chatowner@example.com");
        TestAccount viewer = registerAccount("chatviewer", "chatviewer@example.com");
        String roomCode = createRoom(owner.accessToken(), "Chat Room", 5);
        join(roomCode, viewer);

        mockMvc.perform(post("/api/chat/rooms/{roomCode}/messages", roomCode)
                        .header("Authorization", bearer(viewer.accessToken()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("content", "Hello from integration test", "messageType", "TEXT"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.roomCode").value(roomCode))
                .andExpect(jsonPath("$.senderUsername").value(viewer.username()))
                .andExpect(jsonPath("$.content").value("Hello from integration test"))
                .andExpect(jsonPath("$.deleted").value(false));

        mockMvc.perform(get("/api/chat/rooms/{roomCode}/messages", roomCode)
                        .header("Authorization", bearer(owner.accessToken())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].content").value("Hello from integration test"));
    }

    @Test
    void nonParticipantCannotReadMessages() throws Exception {
        TestAccount owner = registerAccount("ownerchat2", "ownerchat2@example.com");
        TestAccount outsider = registerAccount("outsider", "outsider@example.com");
        String roomCode = createRoom(owner.accessToken(), "Private Chat", 5);

        mockMvc.perform(get("/api/chat/rooms/{roomCode}/messages", roomCode)
                        .header("Authorization", bearer(outsider.accessToken())))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message", containsString("not in this room")));
    }

    @Test
    void senderCanEditAndDeleteOwnMessage() throws Exception {
        TestAccount owner = registerAccount("editor", "editor@example.com");
        String roomCode = createRoom(owner.accessToken(), "Edit Chat", 5);

        Long messageId = sendMessage(roomCode, owner, "Before edit");

        mockMvc.perform(patch("/api/chat/messages/{messageId}", messageId)
                        .header("Authorization", bearer(owner.accessToken()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("content", "After edit"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").value("After edit"))
                .andExpect(jsonPath("$.edited").value(true));

        mockMvc.perform(delete("/api/chat/messages/{messageId}", messageId)
                        .header("Authorization", bearer(owner.accessToken())))
                .andExpect(status().isNoContent());

        mockMvc.perform(get("/api/chat/rooms/{roomCode}/messages", roomCode)
                        .header("Authorization", bearer(owner.accessToken())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].content").value("[deleted]"))
                .andExpect(jsonPath("$[0].deleted").value(true));
    }

    @Test
    void userCannotEditSomeoneElsesMessage() throws Exception {
        TestAccount owner = registerAccount("author", "author@example.com");
        TestAccount viewer = registerAccount("notauthor", "notauthor@example.com");
        String roomCode = createRoom(owner.accessToken(), "No Edit", 5);
        join(roomCode, viewer);
        Long messageId = sendMessage(roomCode, owner, "Host message");

        mockMvc.perform(patch("/api/chat/messages/{messageId}", messageId)
                        .header("Authorization", bearer(viewer.accessToken()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("content", "Hacked"))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message", containsString("own messages")));
    }

    @Test
    void reactionCanBeAddedAndRemoved() throws Exception {
        TestAccount owner = registerAccount("reacthost", "reacthost@example.com");
        TestAccount viewer = registerAccount("reactviewer", "reactviewer@example.com");
        String roomCode = createRoom(owner.accessToken(), "Reactions", 5);
        join(roomCode, viewer);
        Long messageId = sendMessage(roomCode, owner, "React to me");

        mockMvc.perform(post("/api/chat/messages/{messageId}/reactions", messageId)
                        .header("Authorization", bearer(viewer.accessToken()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("reactionType", "❤️"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.reactions", hasSize(1)))
                .andExpect(jsonPath("$.reactions[0].username").value(viewer.username()));

        mockMvc.perform(delete("/api/chat/messages/{messageId}/reactions", messageId)
                        .header("Authorization", bearer(viewer.accessToken()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("reactionType", "❤️"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.reactions", hasSize(0)));
    }

    private void join(String roomCode, TestAccount account) throws Exception {
        mockMvc.perform(post("/api/rooms/{code}/join", roomCode)
                        .header("Authorization", bearer(account.accessToken())))
                .andExpect(status().isOk());
    }

    private Long sendMessage(String roomCode, TestAccount account, String content) throws Exception {
        MvcResult result = mockMvc.perform(post("/api/chat/rooms/{roomCode}/messages", roomCode)
                        .header("Authorization", bearer(account.accessToken()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("content", content, "messageType", "TEXT"))))
                .andExpect(status().isOk())
                .andReturn();

        return readJson(result).get("id").asLong();
    }
}
