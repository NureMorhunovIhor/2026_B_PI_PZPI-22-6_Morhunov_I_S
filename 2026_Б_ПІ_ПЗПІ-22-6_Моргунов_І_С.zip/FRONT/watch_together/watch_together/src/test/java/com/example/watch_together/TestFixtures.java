package com.example.watch_together;

import com.example.watch_together.billing.dto.BillingPlanResponse;
import com.example.watch_together.room.entity.*;
import com.example.watch_together.security.CustomUserDetails;
import com.example.watch_together.user.entity.User;
import com.example.watch_together.user.entity.UserStatus;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;

final class TestFixtures {
    private TestFixtures() {}

    static User user(Long id, String username, String email) {
        return User.builder()
                .id(id)
                .username(username)
                .email(email)
                .passwordHash("encodedPassword")
                .displayName(username)
                .avatarUrl("/uploads/avatar" + id + ".jpg")
                .twoFactorEnabled(false)
                .status(UserStatus.OFFLINE)
                .isActive(true)
                .isEmailVerified(false)
                .roles(new HashSet<>())
                .build();
    }

    static void authenticate(User user) {
        var auth = new UsernamePasswordAuthenticationToken(
                new CustomUserDetails(user), null, List.of()
        );
        SecurityContextHolder.getContext().setAuthentication(auth);
    }

    static WatchRoom room(Long id, User owner) {
        return WatchRoom.builder()
                .id(id)
                .roomCode("ROOM1234")
                .name("Movie night")
                .description("Test room")
                .owner(owner)
                .roomType(RoomType.PUBLIC)
                .accessMode(AccessMode.OPEN)
                .maxParticipants(5)
                .isActive(true)
                .currentMediaId(100L)
                .build();
    }

    static RoomParticipant participant(WatchRoom room, User user, ParticipantRole role, JoinStatus status, boolean canControl) {
        return RoomParticipant.builder()
                .id(user.getId() + 100)
                .room(room)
                .user(user)
                .participantRole(role)
                .joinStatus(status)
                .joinedAt(LocalDateTime.now().minusMinutes(5))
                .isMuted(false)
                .canControlPlayback(canControl)
                .build();
    }

    static RoomSettings roomSettings(WatchRoom room, boolean allowChat) {
        return RoomSettings.builder()
                .room(room)
                .allowParticipantControl(false)
                .allowChat(allowChat)
                .allowReactions(true)
                .allowVoiceChat(false)
                .allowVideoChat(false)
                .autoPauseOnBuffer(true)
                .showSubtitles(true)
                .subtitlesLanguage("en")
                .playbackSpeed(BigDecimal.valueOf(1.00))
                .build();
    }

    static BillingPlanResponse freePlan() {
        return BillingPlanResponse.builder()
                .id("FREE")
                .maxRooms(3)
                .maxParticipants(5)
                .maxQueueItems(10)
                .allowInviteOnly(false)
                .allowRoomCustomization(false)
                .allowAdvancedModeration(false)
                .allowRoomStatistics(false)
                .build();
    }

    static BillingPlanResponse premiumPlan() {
        return BillingPlanResponse.builder()
                .id("PREMIUM")
                .maxRooms(15)
                .maxParticipants(20)
                .maxQueueItems(100)
                .allowInviteOnly(true)
                .allowRoomCustomization(true)
                .allowAdvancedModeration(true)
                .allowRoomStatistics(false)
                .build();
    }

    static BillingPlanResponse proPlan() {
        return BillingPlanResponse.builder()
                .id("PRO")
                .maxRooms(9999)
                .maxParticipants(50)
                .maxQueueItems(9999)
                .allowInviteOnly(true)
                .allowRoomCustomization(true)
                .allowAdvancedModeration(true)
                .allowRoomStatistics(true)
                .build();
    }
}
