package com.example.watch_together.integration;

import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

import java.util.Map;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class QueueIntegrationTest extends AbstractIntegrationTest {

    @Test
    void participantCanAddExternalMediaAndReadQueue() throws Exception {
        TestAccount owner = registerAccount("queuehost", "queuehost@example.com");
        String roomCode = createRoom(owner.accessToken(), "Queue Room", 5);

        mockMvc.perform(post("/api/rooms/{roomCode}/queue/external", roomCode)
                        .header("Authorization", bearer(owner.accessToken()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of(
                                "title", "Big Buck Bunny",
                                "description", "Test video",
                                "mediaType", "VIDEO",
                                "sourceType", "EXTERNAL_URL",
                                "sourceUrl", "https://example.com/video.mp4",
                                "durationSeconds", 596
                        ))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.mediaTitle").value("Big Buck Bunny"))
                .andExpect(jsonPath("$.queueOrder").value(1))
                .andExpect(jsonPath("$.status").value("QUEUED"));

        mockMvc.perform(get("/api/rooms/{roomCode}/queue", roomCode)
                        .header("Authorization", bearer(owner.accessToken())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].sourceUrl").value("https://example.com/video.mp4"));
    }

    @Test
    void hostCanMoveQueueItems() throws Exception {
        TestAccount owner = registerAccount("movehost", "movehost@example.com");
        String roomCode = createRoom(owner.accessToken(), "Move Queue", 5);
        Long firstId = addExternal(roomCode, owner, "First video");
        Long secondId = addExternal(roomCode, owner, "Second video");

        mockMvc.perform(patch("/api/rooms/{roomCode}/queue/{queueItemId}/move", roomCode, secondId)
                        .header("Authorization", bearer(owner.accessToken()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("newOrder", 1))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].queueItemId").value(secondId))
                .andExpect(jsonPath("$[1].queueItemId").value(firstId));
    }

    @Test
    void viewerCannotManageQueueWhenPlaybackControlIsNotGranted() throws Exception {
        TestAccount owner = registerAccount("queueowner2", "queueowner2@example.com");
        TestAccount viewer = registerAccount("queueviewer2", "queueviewer2@example.com");
        String roomCode = createRoom(owner.accessToken(), "Restricted Queue", 5);
        join(roomCode, viewer);
        Long queueItemId = addExternal(roomCode, owner, "Host video");

        mockMvc.perform(delete("/api/rooms/{roomCode}/queue/{queueItemId}", roomCode, queueItemId)
                        .header("Authorization", bearer(viewer.accessToken())))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message", containsString("cannot manage queue")));
    }

    @Test
    void hostCanPlayQueueItemAndPlaybackStateBecomesReadable() throws Exception {
        TestAccount owner = registerAccount("playhost", "playhost@example.com");
        String roomCode = createRoom(owner.accessToken(), "Playback Queue", 5);
        Long queueItemId = addExternal(roomCode, owner, "Playable video");

        mockMvc.perform(post("/api/rooms/{roomCode}/queue/{queueItemId}/play", roomCode, queueItemId)
                        .header("Authorization", bearer(owner.accessToken())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("PLAYING"));

        mockMvc.perform(get("/api/playback/rooms/{roomCode}/state", roomCode)
                        .header("Authorization", bearer(owner.accessToken())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.roomCode").value(roomCode))
                .andExpect(jsonPath("$.playbackStatus").value("PAUSED"))
                .andExpect(jsonPath("$.currentPositionSeconds").value(0));
    }

    @Test
    void missingExternalMediaTitleReturnsBadRequest() throws Exception {
        TestAccount owner = registerAccount("badmediahost", "badmediahost@example.com");
        String roomCode = createRoom(owner.accessToken(), "Bad Media", 5);

        mockMvc.perform(post("/api/rooms/{roomCode}/queue/external", roomCode)
                        .header("Authorization", bearer(owner.accessToken()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of(
                                "mediaType", "VIDEO",
                                "sourceType", "EXTERNAL_URL",
                                "sourceUrl", "https://example.com/video.mp4"
                        ))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message", containsString("Title is required")));
    }

    private void join(String roomCode, TestAccount account) throws Exception {
        mockMvc.perform(post("/api/rooms/{code}/join", roomCode)
                        .header("Authorization", bearer(account.accessToken())))
                .andExpect(status().isOk());
    }

    private Long addExternal(String roomCode, TestAccount account, String title) throws Exception {
        MvcResult result = mockMvc.perform(post("/api/rooms/{roomCode}/queue/external", roomCode)
                        .header("Authorization", bearer(account.accessToken()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of(
                                "title", title,
                                "description", "Integration video",
                                "mediaType", "VIDEO",
                                "sourceType", "EXTERNAL_URL",
                                "sourceUrl", "https://example.com/" + title.toLowerCase().replace(' ', '-') + ".mp4",
                                "durationSeconds", 120
                        ))))
                .andExpect(status().isOk())
                .andReturn();

        return readJson(result).get("queueItemId").asLong();
    }
}
