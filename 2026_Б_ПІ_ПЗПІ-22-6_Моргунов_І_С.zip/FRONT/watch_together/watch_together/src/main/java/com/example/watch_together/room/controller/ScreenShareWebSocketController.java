package com.example.watch_together.room.controller;

import com.example.watch_together.room.dto.ScreenSignalRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Controller
@RequiredArgsConstructor
public class ScreenShareWebSocketController {

    private final SimpMessagingTemplate messagingTemplate;

    private final Map<String, Long> activeScreenShares = new ConcurrentHashMap<>();

    @MessageMapping("/screen.signal")
    public void screenSignal(@Payload ScreenSignalRequest request) {
        if (request.getRoomCode() == null || request.getRoomCode().isBlank()) {
            return;
        }

        if (request.getSenderUserId() == null) {
            return;
        }

        String roomCode = request.getRoomCode();
        Long senderUserId = request.getSenderUserId();
        String type = request.getType();

        System.out.println("SCREEN SIGNAL RECEIVED:");
        System.out.println("roomCode = " + roomCode);
        System.out.println("senderUserId = " + senderUserId);
        System.out.println("targetUserId = " + request.getTargetUserId());
        System.out.println("type = " + type);

        if ("screen.share-started".equals(type)) {
            Long currentOwner = activeScreenShares.get(roomCode);

            if (currentOwner != null && !currentOwner.equals(senderUserId)) {
                System.out.println("Screen share already active in room: " + roomCode);
                return;
            }

            activeScreenShares.put(roomCode, senderUserId);
        }

        if ("screen.share-stopped".equals(type)) {
            Long ownerId = activeScreenShares.get(roomCode);

            if (ownerId == null) {
                return;
            }

            if (!ownerId.equals(senderUserId)) {
                System.out.println("User tried to stop another user's screen share");
                return;
            }

            activeScreenShares.remove(roomCode);
        }

        Map<String, Object> payload = new HashMap<>();
        payload.put("type", type);
        payload.put("roomCode", roomCode);
        payload.put("senderUserId", senderUserId);
        payload.put("targetUserId", request.getTargetUserId());
        payload.put("data", request.getData());

        messagingTemplate.convertAndSend(
                "/topic/rooms/" + roomCode + "/screen",
                (Object) payload
        );
    }
}