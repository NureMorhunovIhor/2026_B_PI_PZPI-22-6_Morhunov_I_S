package com.example.watch_together.room.dto;

import lombok.Data;

@Data
public class ScreenSignalRequest {
    private String roomCode;
    private Long senderUserId;
    private Long targetUserId;
    private String type;
    private Object data;
}