package com.example.watch_together.room.controller;

import com.example.watch_together.room.dto.VoiceSignalRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

import java.util.HashMap;
import java.util.Map;

@Controller
@RequiredArgsConstructor
public class VoiceWebSocketController {

    private final SimpMessagingTemplate messagingTemplate;

    @MessageMapping("/voice.signal")
    public void voiceSignal(@Payload VoiceSignalRequest request) {
        System.out.println("VOICE SIGNAL RECEIVED:");
        System.out.println("roomCode = " + request.getRoomCode());
        System.out.println("senderUserId = " + request.getSenderUserId());
        System.out.println("targetUserId = " + request.getTargetUserId());
        System.out.println("type = " + request.getType());

        if (request.getRoomCode() == null || request.getRoomCode().isBlank()) {
            return;
        }

        if (request.getSenderUserId() == null) {
            return;
        }

        Map<String, Object> payload = new HashMap<>();
        payload.put("type", request.getType());
        payload.put("roomCode", request.getRoomCode());
        payload.put("senderUserId", request.getSenderUserId());
        payload.put("targetUserId", request.getTargetUserId());
        payload.put("data", request.getData());

        messagingTemplate.convertAndSend(
                "/topic/rooms/" + request.getRoomCode() + "/voice",
                (Object) payload
        );
    }
}